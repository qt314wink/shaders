# Calcium+Company Application Kit — Jennipher Troup

Target role: **AI Art Specialist — Motion**

## Recommended submission order

1. `Jennipher_Troup_Calcium_AI_Art_Specialist_Resume.pdf`
2. `Jennipher_Troup_Calcium_Cover_Letter.pdf`
3. `Nourish_the_Signal_Creative_System.pdf`
4. Optional process attachments: `nourish_the_signal_prompt_pack.md` and `nourish_the_signal_tokens.json`

## Positioning

Lead with **AI Creative Technologist / Generative Art + Motion Systems**. The application is designed to demonstrate that the candidate can direct generative visual work, engineer prompts across platforms, design reusable motion workflows, evaluate outputs rigorously, and contribute to internal AI tooling—not merely produce isolated AI images.

## Evidence boundary

Adobe Creative Suite is intentionally described as **working knowledge**. The kit does not claim advanced After Effects, Premiere, Final Cut, CapCut or DaVinci proficiency without stronger confirmed evidence. Motion proof instead centers on ComfyUI/Wan workflows, structured motion prompts, multi-keyframe/camera choreography, generative campaign systems, and interactive/procedural motion work.

# Nourish the Signal — Generation Prompt Pack

**Status:** Speculative application artifact for Calcium+Company — AI Art Specialist (Motion). Not commissioned client work.

## Canonical scene prompt

Create a sophisticated speculative motion campaign for a health communications agency. Begin inside an abstract-but-biologically-credible microscopic environment: a tiny point of warm white light activates and propagates through translucent membrane-like structures. Follow the signal continuously as cellular geometry becomes branching neural and vascular forms. The biological network gradually transforms into recognizable human-scale visual language: breath moving fabric, sunlight crossing skin, an eye focusing, a hand reaching toward another hand. The transition must feel causally connected rather than like random AI morphing. Editorial healthcare cinematography, intelligent and human, restrained color, mineral white and carbon with botanical green and subtle bioelectric cyan accents. Macro optical depth initially, transitioning naturally into documentary 35–50 mm cinematography. Preserve anatomical plausibility without depicting disease. Emotion moves from curiosity to recognition to reassurance. No futuristic HUD, no chrome biotech cliché, no oversaturated neon, no plastic skin, no text baked into the generated image. End with clean negative space for typography.

## Canonical motion instruction

One directional signal travels through every shot and motivates every transition. Slow anticipation for the first second, progressive acceleration through biological transformation, then gentle deceleration as the human subject appears. Organic micro-motion only: pulse, diffusion, branching, breathing, eye focus, subtle hand movement. Stable camera geometry; no uncontrolled warping.

## Grok — keyframe prompt

Editorial healthcare image at the threshold between microscopic biology and human experience. A warm white signal travels through translucent branching membrane structures and seamlessly becomes light crossing a real human face and hand. Mineral white, carbon, botanical green, restrained bioelectric cyan. Intelligent, intimate, biologically suggestive, natural skin, clean negative space, no text, no sci-fi interface, no neon biotech cliché.

### Grok — image-to-video motion prompt

Keep the composition and identity stable. Animate one warm signal moving through the biological network; let the network transition causally into breath, eye focus and a subtle hand movement. Begin slow, accelerate through the transformation, then settle. Stable camera, gentle forward travel, no random morphing, flicker, duplicate anatomy or aggressive motion.

## ChatGPT / OpenAI — hero keyframe prompt

Create a refined editorial campaign keyframe for a speculative health-communications concept called “Nourish the Signal.” Show a single luminous biological signal crossing a translucent organic network and becoming a recognizable human gesture without a hard cut. The image should feel observational rather than futuristic: mineral white, carbon, botanical green and restrained cyan; tactile optical depth; natural skin; macro-to-documentary visual language; clear negative space for separately composited typography. Do not render words or logos. Avoid plastic skin, medical-device UI, neon sci-fi styling, impossible anatomy or generic corporate-stock expressions.

## ComfyUI / Wan — positive semantic fields

- subject: warm luminous biological signal, translucent membrane network, subtle human face/hand reveal
- transformation: continuous causal transition from microscopic branching biology into human breath, eye focus and gesture
- camera: macro optical depth moving toward 35–50mm editorial documentary perspective
- light: directional biological luminosity, soft mineral highlights, restrained falloff
- palette: mineral white, carbon, warm neutral, botanical green, subtle bioelectric cyan
- material: membrane, tissue, mineral, glass, atmospheric particulate
- motion: pulse, propagate, branch, breathe; slow push → acceleration → soft settle
- mood: curiosity → recognition → reassurance → possibility

## ComfyUI / Wan — negative node

random morphing, anatomy errors, duplicate hands, extra fingers, deformed eyes, plastic skin, oversaturated neon, chrome biotech, sci-fi HUD, medical interface, illegible text, logos, flicker, unstable geometry, aggressive camera shake, generic corporate smile, excessive particles

## Graph contract

`reference / seed → semantic prompt fields → negative constraints → conditioning/control → sampler → candidate compare → selected keyframe → Wan image-to-video → frame QA → external type/CTA composite → channel crops`

## Channel copy

### Social / Reel
**Hook:** EVERY STORY BEGINS AS A SIGNAL.  
**Middle:** THE DIFFERENCE IS WHAT WE MAKE OF IT.  
**Resolve:** FROM SIGNAL. TO STORY. TO MOVEMENT.  
**End:** NOURISH THE SIGNAL.

Caption: Science gives us the signal. Creative gives it meaning. The most useful generative systems do more than make images: they preserve intent as a concept moves from evidence → idea → emotion → action. Nourish the Signal is a speculative AI-motion study in controlled visual translation.

### Email
**Subject:** What if a health story could be followed from signal to meaning?  
**Preheader:** A speculative AI-motion study in controlled visual storytelling.  
**Headline:** NOURISH THE SIGNAL.  
**Subhead:** From biological information to human meaning.  
**CTA:** WATCH THE STUDY

### Facebook / Google Business
**Headline:** TURN SIGNALS INTO STORIES PEOPLE CAN FEEL.  
**CTA:** Explore the creative study.

## Candidate QA

Score each candidate on narrative causality (20), visual coherence (15), human credibility (15), biological plausibility (10), motion control (15), channel utility (10), brand/type readiness (5), and originality with restraint (10). Keep the selected candidate only when its failure notes and retained decisions are recorded.

# BO-01 Root-Cause and Repair Note

## Finding

**Verified.** The collector considers a repository changed when its GitHub `pushed_at` differs from the previously recorded asset-card value. The collection workflow then commits all files under `portfolio/evidence/` back to the observed repository using the `provenance[bot]` identity. A provenance-only evidence commit consequently advances GitHub's repository-level `pushed_at`, which the next collection cycle may interpret as ordinary repository drift.

**Verified.** Before the repair candidate, the controlled provenance-only commit produced an `asset.discovered` event with `claims.drift_detected=true` in two independent temporary trials. The collector also treats a repository represented only in prior evidence, without a canonical asset card, as newly discovered on every run; that is the path exemplified by the existing Seed Loom evidence record.

| Condition | Baseline classification | Candidate classification | Measured result |
|---|---|---|---|
| Provenance-only self-commit with asset-card state | Ordinary drift | Explicit `Provenance-only` log classification; no evidence write | 2/2 clean trials agree |
| Provenance-only self-commit with prior evidence but no asset card | New discovery | Explicit `Provenance-only` log classification; no evidence write | Pass |
| Substantive source commit | Ordinary drift | Ordinary drift | Pass |
| No state change | No event | No event | Pass |
| Malformed comparison state | Silent fallback and discovery | Visible warning and exit status `2` | Pass |

## Minimal candidate repair

The uncommitted candidate changes only `scripts/collect_repo_provenance.py` and adds an isolated regression fixture.

1. It fails closed when an asset card or prior evidence record cannot be parsed, rather than silently emptying comparison state and reporting spurious discoveries.
2. It reads prior evidence only as a **read-only observed-repository index**. Evidence does not become canonical asset state and does not mutate any card or schema.
3. When `pushed_at` changed, it requests the default-branch head commit and suppresses ordinary drift only if all of the following are verified: the commit message starts with the collector's evidence message, the author name and email exactly match the workflow identity, and every changed file lies under `portfolio/evidence/`.
4. It emits `Provenance-only: owner/repository` and writes no additional evidence file. This explicit non-persisted classification prevents the classifier from producing another repository write that would perpetuate the loop.
5. When the discriminator cannot verify a provenance-only commit, behavior remains conservative: a changed known asset is reported as drift and an unobserved repository is reported as new.

## Boundary and limitation

> The repair candidate does **not** redefine product activity, modify canonical knowledge records, weaken any schema, change the workflow, push a branch, or advance a promotion gate.

The fixture models GitHub repository and commit payloads locally because live GitHub timing is not a deterministic test control. It validates the data fields the repair consumes but does not claim that a live scheduled workflow run has been executed. A human must decide whether to accept the uncommitted patch at **G8**; Genesis remains deferred.

# Gate System

## G0 — Identity & Clean State
PASS when repository, branch, base SHA, remote, working-tree state, and protected surfaces are verified.
FAIL CLOSED otherwise.

## G1 — Fixture Freeze
PASS when every experiment input has a stable ID/hash and the evaluator cannot silently change it mid-run.

## G2 — Executability
PASS when the declared experiment can be run from documented instructions without undocumented manual intervention.

## G3 — Measurement
PASS when required metrics are actually emitted. A qualitative impression is not a substitute for a benchmark.

## G4 — Reproducibility
PASS when repeated clean runs agree within the exact tolerance defined by the order.
Where byte identity is required, tolerance is zero.

## G5 — Adversarial / Negative Test
PASS when at least one expected failure, contradiction, malformed input, or edge condition is correctly detected and does not falsely pass.

## G6 — Protected-Surface Verification
PASS when `git diff --name-only`, generated-file inventory, and independent inspection show only allowed surfaces changed.

## G7 — Independent Verification
PASS when a verifier independently checks the evidence and either agrees or emits a disagreement record.

## G8 — Promotion Review
HUMAN ONLY. Determines whether the result becomes a strategy candidate, implementation change, consolidation decision, or archive recommendation.

## G9 — Genesis
DEFERRED. Not granted by this package.

No workstream may infer G8/G9 from success at G0–G7.

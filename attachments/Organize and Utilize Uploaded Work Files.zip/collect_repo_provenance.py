#!/usr/bin/env python3
"""
Collect git-based asset provenance from GitHub API.
Writes asset.discovered evidence events to portfolio/evidence/.
Requires: GITHUB_TOKEN env var for private repos and higher rate limits.
"""

from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from urllib import request, error as url_error

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE_DIR = ROOT / "portfolio" / "evidence"
ASSETS_DIR = ROOT / "portfolio" / "assets"
GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "")
OWNERS = ["qt314wink", "MelodicBloom"]

HEADERS = {
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
}
if GITHUB_TOKEN:
    HEADERS["Authorization"] = f"Bearer {GITHUB_TOKEN}"


def gh_get(url: str) -> dict | list:
    req = request.Request(url, headers=HEADERS)
    with request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read())


def get_repos(owner: str) -> list[dict]:
    url = f"https://api.github.com/users/{owner}/repos?per_page=100&type=all"
    try:
        return gh_get(url)
    except url_error.URLError as exc:
        print(f"  Warning: could not reach GitHub API for {owner}: {exc}")
        return []


class AssetMetadataError(RuntimeError):
    """Raised when a canonical asset card cannot be parsed safely."""


def load_known_assets() -> dict[str, dict]:
    """Load existing asset cards keyed by GitHub repository ID.

    A malformed card prevents a trustworthy comparison, so collection stops rather
    than silently treating all assets as newly discovered.
    """
    known: dict[str, dict] = {}
    if not ASSETS_DIR.exists():
        return known
    for f in ASSETS_DIR.glob("*.json"):
        try:
            data = json.loads(f.read_text())
        except json.JSONDecodeError as exc:
            raise AssetMetadataError(f"{f}: invalid JSON ({exc.msg})") from exc
        if not isinstance(data, dict):
            raise AssetMetadataError(f"{f}: expected a JSON object")
        github = data.get("github", {})
        if not isinstance(github, dict):
            raise AssetMetadataError(f"{f}: github must be an object")
        repo_id = github.get("repository_id")
        if repo_id:
            known[str(repo_id)] = data
    return known


def load_observed_repo_ids() -> set[str]:
    """Load repository IDs already observed in evidence records.

    Evidence is read only as a loop-prevention index; it never becomes a
    substitute for an asset card or a source-state baseline.
    """
    observed: set[str] = set()
    if not EVIDENCE_DIR.exists():
        return observed
    for f in EVIDENCE_DIR.rglob("*.json"):
        try:
            data = json.loads(f.read_text())
        except json.JSONDecodeError as exc:
            raise AssetMetadataError(f"{f}: invalid provenance evidence ({exc.msg})") from exc
        if not isinstance(data, dict):
            raise AssetMetadataError(f"{f}: provenance evidence must be a JSON object")
        repo_id = data.get("claims", {}).get("github_repo_id")
        if repo_id is not None:
            observed.add(str(repo_id))
    return observed


def get_head_commit(repo: dict) -> dict | None:
    """Return the observed branch head, or None when it cannot be verified."""
    api_url = repo.get("url")
    if not api_url:
        return None
    ref = repo.get("default_branch", "main")
    try:
        payload = gh_get(f"{api_url}/commits/{ref}")
    except url_error.URLError as exc:
        print(f"  Warning: could not inspect head commit for {repo.get('name')}: {exc}")
        return None
    return payload if isinstance(payload, dict) else None


def is_provenance_only_commit(commit: dict | None) -> bool:
    """Recognize a collector-authored commit whose changed files are evidence only."""
    if not commit:
        return False
    commit_data = commit.get("commit", {})
    author = commit_data.get("author", {}) if isinstance(commit_data, dict) else {}
    message = commit_data.get("message", "") if isinstance(commit_data, dict) else ""
    files = commit.get("files")
    if not isinstance(files, list) or not files:
        return False
    file_names = [item.get("filename") for item in files if isinstance(item, dict)]
    return (
        message.startswith("evidence: nightly provenance collection")
        and author.get("name") == "provenance[bot]"
        and author.get("email") == "provenance@users.noreply.github.com"
        and len(file_names) == len(files)
        and all(isinstance(name, str) and name.startswith("portfolio/evidence/") for name in file_names)
    )


def make_event(event_type: str, repo: dict, owner: str) -> dict:
    now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    sha_src = f"{repo['id']}:{repo.get('pushed_at', now)}"
    event_id = f"evt_{hashlib.sha256(sha_src.encode()).hexdigest()[:16]}"
    return {
        "event_id": event_id,
        "schema_version": "v1",
        "event_type": event_type,
        "occurred_at": now,
        "asset": {
            "provider": "github",
            "owner": owner,
            "repo": repo["name"],
            "commit_sha": repo.get("pushed_at", "unknown"),
            "ref": repo.get("default_branch", "main"),
        },
        "actor": {
            "type": "workflow",
            "id": "collect_repo_provenance",
        },
        "confidence": "supported",
        "claims": {
            "github_repo_id": repo["id"],
            "github_node_id": repo.get("node_id"),
            "language": repo.get("language"),
            "archived": repo.get("archived", False),
            "private": repo.get("private", False),
            "fork": repo.get("fork", False),
            "description": repo.get("description"),
            "pushed_at": repo.get("pushed_at"),
            "created_at": repo.get("created_at"),
            "open_issues_count": repo.get("open_issues_count"),
        },
    }


def write_event(event: dict, date_path: str) -> Path:
    out_dir = EVIDENCE_DIR / date_path
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{event['event_id']}.json"
    if not out_path.exists():
        out_path.write_text(json.dumps(event, indent=2))
    return out_path


def main() -> int:
    today = datetime.now(timezone.utc).strftime("%Y-%m")
    try:
        known = load_known_assets()
        observed_repo_ids = load_observed_repo_ids()
    except AssetMetadataError as exc:
        print(f"Warning: could not load provenance comparison state: {exc}")
        return 2
    new_events: list[Path] = []

    for owner in OWNERS:
        print(f"Scanning {owner}...")
        repos = get_repos(owner)
        for repo in repos:
            repo_id = str(repo["id"])
            if repo_id in known:
                existing_push = known[repo_id].get("claims", {}).get("pushed_at")
                if existing_push != repo.get("pushed_at"):
                    head_commit = get_head_commit(repo)
                    if is_provenance_only_commit(head_commit):
                        print(f"  Provenance-only: {owner}/{repo['name']}")
                        continue
                    event = make_event("asset.discovered", repo, owner)
                    event["claims"]["drift_detected"] = True
                    path = write_event(event, today)
                    new_events.append(path)
                    print(f"  Updated: {owner}/{repo['name']}")
            elif repo_id in observed_repo_ids and is_provenance_only_commit(get_head_commit(repo)):
                print(f"  Provenance-only: {owner}/{repo['name']}")
            else:
                event = make_event("asset.discovered", repo, owner)
                path = write_event(event, today)
                new_events.append(path)
                print(f"  New:     {owner}/{repo['name']}")

    print(f"\nWrote {len(new_events)} new evidence events.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# Immediate Build Execution Contract

## Global preflight

Before every order:
- resolve repository identity and exact branch/base SHA;
- record `git remote get-url origin`;
- record `git branch --show-current`;
- record `git status --short`;
- record baseline SHA;
- identify allowed and protected surfaces;
- compute hashes for immutable fixtures;
- declare writer count;
- declare expected outputs;
- declare stop conditions.

If preflight fails, do not edit.

## Builder pattern

Use one primary writer for a shared surface. Independent reviewers may be read-only.

Recommended roles:
- Builder: Codex governed builder or equivalent.
- Research comparator: Manus/ChatGPT for literature, taxonomy, and adversarial comparison.
- Independent verifier: separate Codex/ChatGPT pass that reads receipts and Git state but does not rewrite the implementation.

## Receipt contract

Each run must emit:
- order_id
- run_id
- repository
- base_sha
- branch
- allowed_surfaces
- protected_surfaces
- input_hashes
- commands/tests executed
- measured results
- files changed
- builder conclusion
- independent verification
- disagreements
- unresolved evidence
- next_gate
- prohibited_actions_executed=false

## Commit/push rule

Work may be prepared on isolated branches/worktrees. Do not merge or deploy. If the execution environment's established approval model requires asking before commit/push, stop before that step and present the receipt. A local uncommitted patch plus evidence is sufficient for the gate.

## Shared global benchmarks

- zero unauthorized changed files;
- zero silent test failures;
- zero automatic promotion;
- zero hidden malformed-input residue where atomicity is required;
- deterministic fixtures hash-identically before comparison;
- all exclusions from deterministic digests are enumerated;
- independent receipt must match observed Git/filesystem state;
- unknown remains unknown.

# BO-02 Prior-Art Note — MELD

## Classification

**MELD is relevant prior art and an experimental comparator, not an adopted Seed Loom component.** The paper presents a distributed protocol for reconciling claims across sovereign agent memories. Its stated admission outcomes are **insert, merge, relate, conflict, and reject**; it uses scoped claim identity, embedding similarity, and natural-language-inference signals under context and freshness gates, and confines mutation to an authenticated Patch.[1]

MELD’s authors report a classifier AUC of 0.968 and a 0.013 false-merge rate on their adjudicated candidate-pair set, together with 30/30 partition-heal convergence trials for their status CRDT. Those are **published MELD results**, not Seed Loom results.[1] The present BO-02 control corpus did not run the MELD implementation, reproduce its classifier, install a transport layer, or test a distributed state mechanism.

| Dimension | MELD publication | Seed Loom BO-02 comparison |
|---|---|---|
| Unit of analysis | Incoming distributed claim | Frozen pre-existing local claim or observation |
| Outcome vocabulary | Insert / Merge / Relate / Conflict / Reject | Same terms used only as a comparison rubric |
| Mutation object | Authenticated Patch | None; no canonical mutation |
| Synchronization | Per-claim status CRDT | Not evaluated |
| Classifier | Identity, embedding, and NLI signals | Existing Seed Loom controls plus adjudicated vocabulary mapping |
| Evidence outcome | Published distributed benchmark | 20-item internal control corpus |

## Composition insight

The defensible Seed Loom contribution remains its own composition: typed epistemic state, candidate-first governance, deterministic review controls, bounded authority, exact reset and replay, failure receipts, and reproducible QA. MELD sharpens a design question inside that composition—how to name non-identity relationships and admission decisions—but it does not remove the need for independent human promotion authority or for source-specific provenance.

> A related claim is not automatically the same claim. A contradiction is not automatically resolved. A schema comparison is not a schema mutation.

## Required boundary

No element of this note authorizes a schema change, a relationship-predicate change, a canonical ingest change, a status-CRDT deployment, an external publication, an accepted knowledge transition, Strategy approval, or Genesis advancement. The BO-02 recommendation is **experiment-further** only.

## Reference

[1]: [Lovén, Sauvola, Riekki, and Tarkoma, *MELD: A Protocol for Merging Knowledge Across Distributed Agentic Memories*, arXiv:2608.16357](https://arxiv.org/abs/2608.16357)

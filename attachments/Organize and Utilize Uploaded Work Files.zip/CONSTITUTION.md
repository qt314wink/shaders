# Governed Experiment Constitution

## Purpose

Enable fast experimentation without allowing speed to erase provenance, human authority, falsifiability, reproducibility, or project boundaries.

## Constitutional invariants

1. Evidence before assertion.
2. Candidate before accepted.
3. Observation before interpretation.
4. Compare before mutate.
5. Reproduce before repair when a defect is only inferred.
6. Extract before consolidate.
7. Measure before productize.
8. Preserve contradictions rather than forcing false agreement.
9. Human promotion authority remains external to the builder.
10. No agent may bootstrap its own confidence from its own outputs.
11. A receipt is evidence, not authority.
12. A failed or inconclusive experiment is a valid output and must not be cosmetically converted into a pass.
13. Protected surfaces are explicit.
14. Writer count is minimized.
15. Exact reset and clean-state reruns are preferred over manual cleanup.
16. Volatile metadata may be excluded from determinism comparisons only when explicitly enumerated.
17. Repository activity caused only by audit/provenance infrastructure must not silently masquerade as world/product change.
18. Semantic similarity is not identity.
19. Consolidation is a recommendation until approved.
20. Genesis remains deferred unless a separate human-governed eligibility and approval gate is satisfied.

## Epistemic labels

Every material claim in an experiment record must be one of:
- verified
- inferred
- unknown
- contradicted
- failed

## Stop rule

Stop immediately when:
- the branch/repository is not the expected target;
- the working tree is unexpectedly dirty;
- an operation would touch a protected surface;
- the evidence needed to continue is unavailable;
- a benchmark cannot be measured honestly;
- execution would require a prohibited external action;
- a result would require changing the canonical schema before the comparison gate has passed.

Produce a blocked receipt instead of improvising.

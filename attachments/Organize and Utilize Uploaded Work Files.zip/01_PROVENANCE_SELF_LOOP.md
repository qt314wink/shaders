# Build Order BO-01 — Provenance Self-Loop Reproduction v0

Priority: P0
Target: qt314wink/seed-loom
Disposition: CORE repair investigation
Mode: reproduce before repair

## Question

Does the provenance collector report a provenance-only write to Seed Loom as fresh repository drift on the next collection cycle?

## Current evidence

The collector compares GitHub `pushed_at` with known asset metadata, emits drift on difference, writes evidence under `portfolio/evidence`, and its workflow commits those records back into the observed repository.

## Allowed surfaces

Preferred:
- disposable clone/worktree or purpose-built temporary fixture
- new test fixture/helper limited to provenance-loop reproduction if needed
- experiment receipts outside canonical knowledge

No change to main.

## Protected surfaces

- canonical knowledge records
- existing accepted portfolio asset cards
- unrelated workflows
- package manifests unless demonstrably necessary
- Strategy / Genesis records
- production deployments

## Procedure

1. Freeze a baseline repository state.
2. Run the provenance collector once.
3. Commit or emulate only the collector's evidence write inside the disposable test environment.
4. Re-run collection against the resulting repository state.
5. Determine whether the collector classifies its own evidence-only activity as drift.
6. Repeat from clean baseline to prove reproducibility.
7. If and only if reproduced, test the smallest discriminator:
   - provenance-only commit classification, or
   - substantive-content SHA/state comparison, or
   - explicit self-event class.
8. Do not change canonical behavior until the discriminator has a failing test and a passing repair.

## Benchmarks

PASS reproduction when:
- two independent clean trials produce the same classification;
- a provenance-only change is distinguishable from a substantive repository change;
- the experiment captures the exact triggering fields.

PASS repair candidate when:
- provenance-only activity does not become ordinary product drift;
- a real substantive repository change still becomes drift;
- unrelated repositories remain detectable;
- duplicate-event suppression remains intact;
- no new external dependency is introduced.

## Mandatory negative cases

- real source change must still trigger drift;
- no source change must not trigger drift;
- malformed/partial asset metadata must fail/report honestly;
- self-generated audit event must be explicitly classified.

## Stop conditions

Stop before modifying production collector behavior if reproduction is inconclusive.
Stop if testing requires main mutation.
Stop if GitHub API timing makes the test nondeterministic without a controllable fixture; model the API payload locally instead and label the limitation.

## Deliverables

- reproduction fixture/test
- before/after event records
- `provenance-self-loop-receipt.json`
- root-cause note
- smallest repair proposal
- independent verification receipt

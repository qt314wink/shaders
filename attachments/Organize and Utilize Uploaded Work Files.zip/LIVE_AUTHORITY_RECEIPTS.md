# Live Authority Receipts

Captured while preparing this package.

## Seed Loom Issue #34
Purpose: governed-builder determinism trial.
Key contract:
- exactly one governed_builder delegation in that trial;
- bounded change declaration;
- protected surfaces;
- independent final Git-state comparison;
- no commit/push/merge/deploy/publish/external mutation during the trial;
- real two-run output/receipt comparison rather than hashing unchanged bytes.

## Seed Loom PR #36
State when inspected:
- open
- draft
- mergeable
- head: feat/nightly-intake-proof
- head SHA: 9510fee0cfc294ebbb19d4372771985d6a3ad088
- base: codex/repair-seed-loom-reproducibility-boundary
- base SHA: 48685d9532755a2cdd77845d02d8454f57d982d0

Important constraints:
- real delivered bundle in two isolated clean proof environments;
- canonical deterministic proof digest;
- candidate-only observations;
- Genesis deferred;
- malformed-bundle atomic failure;
- no direct main writes or automatic promotion.

## Current schema SHAs
- observation.schema.json blob SHA: 4a651b42c7c2a3d927e812e552ec413424287252
- socratic-assessment.schema.json blob SHA: 20d58193d6277a783f60c469efbbdf8ea862e172
- run.schema.json blob SHA: 9dc9b303cca0768b2c33b767b0b8f3801ae36942
- scripts/collect_repo_provenance.py blob SHA: 695eea334220164664e60cce341b29f35f08a52a

## Schema boundary
Observation schema is closed with additionalProperties=false.
Therefore consultancyImplications and projectDispositionImplications are not canonical Observation properties today.
Do not loosen this as part of these five orders.

## FLORÉ source receipt
README blob SHA: cd899858a2a3d6f111f91cf56579bf407093bb6a
Distinct mechanics explicitly documented:
- procedural MemphisDecor SVG ornament
- botanical forms
- impasto via box-shadow stacking, SVG feTurbulence, gradient layering
- botanical-unfurl and Memphis-snap motion signatures
- tokenized palette/type
- Morphica family relationship

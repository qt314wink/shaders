#!/usr/bin/env python3
"""Normalize BO-03 ledger assets to the supplied closed visual-lineage schema."""

from __future__ import annotations

import json
from pathlib import Path

PATH = Path(__file__).with_name("visual_system_lineage_ledger.json")


def main() -> None:
    ledger = json.loads(PATH.read_text())
    normalized = []
    details = {}
    for item in ledger["assets"]:
        asset_id = item["asset_id"]
        overlap = item["overlap_type"].replace("/", "-").replace(" ", "-")
        if overlap not in {
            "exact-duplicate",
            "shared-primitive-different-grammar",
            "conceptually-adjacent",
            "unique",
            "unknown",
        }:
            raise SystemExit(f"invalid overlap type: {overlap}")
        normalized.append({
            "assetId": asset_id,
            "sourceRepo": item["source_repo"],
            "sourcePath": item["source_path"],
            "sourceSha": item["source_sha"],
            "category": item["category"],
            "mechanism": item["behavioral_mechanical_description"],
            "visualRole": item["visual_role"],
            "dependencies": [item["dependency"]],
            "reusableWithoutIdentityLoss": item["reusable_without_identity_loss"],
            "nearestOverlap": item["nearest_overlapping_asset"],
            "overlapType": overlap,
            "uniqueEvidence": [item["unique_evidence"]],
            "recommendedAuthority": item["recommended_authority"],
            "disposition": item["disposition"],
            "extractBeforeDisposition": [item["extraction_prerequisite"]],
            "revivalCondition": item["revival_condition"],
        })
        details[asset_id] = {
            "identityBoundary": item["unique_evidence"],
            "authorityRationale": item["recommended_authority"],
        }
    ledger["assets"] = normalized
    ledger["assetDetails"] = details
    PATH.write_text(json.dumps(ledger, indent=2) + "\n")
    print(f"PASS: normalized {len(normalized)} lineage assets")


if __name__ == "__main__":
    main()

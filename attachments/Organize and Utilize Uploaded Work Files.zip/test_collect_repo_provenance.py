#!/usr/bin/env python3
"""BO-01 isolated regression fixture for provenance self-loop classification."""

from __future__ import annotations

import contextlib
import importlib.util
import io
import json
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "collect_repo_provenance.py"


def load_collector():
    spec = importlib.util.spec_from_file_location("collect_repo_provenance_bo01", MODULE_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("Could not load provenance collector")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class FixedDateTime(datetime):
    @classmethod
    def now(cls, tz=None):
        value = datetime(2026, 8, 20, 12, 0, 0, tzinfo=timezone.utc)
        return value if tz else value.replace(tzinfo=None)


KNOWN_PUSH = "2026-08-20T00:00:00Z"
SELF_PUSH = "2026-08-20T00:05:00Z"
SOURCE_PUSH = "2026-08-20T01:00:00Z"
REPO_URL = "https://api.github.com/repos/qt314wink/seed-loom"


def repo_payload(pushed_at: str) -> dict:
    return {
        "id": 424242,
        "node_id": "R_kwDOB001",
        "name": "seed-loom",
        "url": REPO_URL,
        "language": "Python",
        "archived": False,
        "private": False,
        "fork": False,
        "description": "fixture",
        "pushed_at": pushed_at,
        "created_at": "2026-08-01T00:00:00Z",
        "open_issues_count": 0,
        "default_branch": "main",
    }


PROVENANCE_COMMIT = {
    "commit": {
        "message": "evidence: nightly provenance collection 2026-08-20",
        "author": {
            "name": "provenance[bot]",
            "email": "provenance@users.noreply.github.com",
        },
    },
    "files": [
        {
            "filename": "portfolio/evidence/2026-08/evt_fixture.json",
        }
    ],
}

SOURCE_COMMIT = {
    "commit": {
        "message": "feat: change collection semantics",
        "author": {
            "name": "maintainer",
            "email": "maintainer@example.test",
        },
    },
    "files": [
        {
            "filename": "scripts/collect_repo_provenance.py",
        }
    ],
}


class ProvenanceCollectorBO01Tests(unittest.TestCase):
    def run_collector(
        self,
        *,
        asset_text: str | None,
        repo: dict,
        commit: dict | None,
        prior_events: list[dict] | None = None,
    ):
        collector = load_collector()
        with tempfile.TemporaryDirectory(prefix="bo01-provenance-") as temp:
            root = Path(temp)
            assets_dir = root / "portfolio" / "assets"
            evidence_dir = root / "portfolio" / "evidence"
            assets_dir.mkdir(parents=True)
            if asset_text is not None:
                (assets_dir / "asset.json").write_text(asset_text)
            for index, event in enumerate(prior_events or []):
                prior_path = evidence_dir / "2026-08" / f"prior-{index}.json"
                prior_path.parent.mkdir(parents=True, exist_ok=True)
                prior_path.write_text(json.dumps(event))
            initial_event_paths = set(evidence_dir.rglob("*.json"))

            original = {
                "ASSETS_DIR": collector.ASSETS_DIR,
                "EVIDENCE_DIR": collector.EVIDENCE_DIR,
                "OWNERS": collector.OWNERS,
                "get_repos": collector.get_repos,
                "gh_get": collector.gh_get,
                "datetime": collector.datetime,
            }
            collector.ASSETS_DIR = assets_dir
            collector.EVIDENCE_DIR = evidence_dir
            collector.OWNERS = ["qt314wink"]
            collector.get_repos = lambda owner: [repo]
            collector.gh_get = lambda url: commit if commit is not None else {}
            collector.datetime = FixedDateTime
            output = io.StringIO()
            try:
                with contextlib.redirect_stdout(output):
                    exit_code = collector.main()
                event_paths = sorted(
                    path for path in evidence_dir.rglob("*.json") if path not in initial_event_paths
                )
                events = [json.loads(path.read_text()) for path in event_paths]
                return exit_code, output.getvalue(), events
            finally:
                collector.ASSETS_DIR = original["ASSETS_DIR"]
                collector.EVIDENCE_DIR = original["EVIDENCE_DIR"]
                collector.OWNERS = original["OWNERS"]
                collector.get_repos = original["get_repos"]
                collector.gh_get = original["gh_get"]
                collector.datetime = original["datetime"]

    @staticmethod
    def known_asset(pushed_at: str = KNOWN_PUSH) -> str:
        return json.dumps(
            {
                "asset_id": "ast_seed_loom_fixture",
                "github": {"repository_id": "424242"},
                "claims": {"pushed_at": pushed_at},
            }
        )

    def test_provenance_only_commit_is_not_ordinary_drift_in_two_clean_trials(self):
        trial_one = self.run_collector(
            asset_text=self.known_asset(),
            repo=repo_payload(SELF_PUSH),
            commit=PROVENANCE_COMMIT,
        )
        trial_two = self.run_collector(
            asset_text=self.known_asset(),
            repo=repo_payload(SELF_PUSH),
            commit=PROVENANCE_COMMIT,
        )

        for exit_code, output, events in (trial_one, trial_two):
            self.assertEqual(exit_code, 0)
            self.assertEqual(events, [], msg=f"ordinary drift emitted: {events}")
            self.assertIn("Provenance-only:", output)
        self.assertEqual(trial_one, trial_two)

    def test_prior_evidence_prevents_a_repeat_self_loop_without_asset_card(self):
        _, output, events = self.run_collector(
            asset_text=None,
            repo=repo_payload(SELF_PUSH),
            commit=PROVENANCE_COMMIT,
            prior_events=[{"claims": {"github_repo_id": 424242}}],
        )

        self.assertEqual(events, [])
        self.assertIn("Provenance-only:", output)

    def test_substantive_source_change_remains_drift(self):
        _, output, events = self.run_collector(
            asset_text=self.known_asset(),
            repo=repo_payload(SOURCE_PUSH),
            commit=SOURCE_COMMIT,
        )

        self.assertIn("Updated: qt314wink/seed-loom", output)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["event_type"], "asset.discovered")
        self.assertTrue(events[0]["claims"]["drift_detected"])
        self.assertEqual(events[0]["claims"]["pushed_at"], SOURCE_PUSH)

    def test_unchanged_repository_emits_no_drift(self):
        _, output, events = self.run_collector(
            asset_text=self.known_asset(),
            repo=repo_payload(KNOWN_PUSH),
            commit=SOURCE_COMMIT,
        )

        self.assertEqual(events, [])
        self.assertIn("Wrote 0 new evidence events.", output)

    def test_malformed_asset_metadata_is_reported_without_silent_failure(self):
        exit_code, output, events = self.run_collector(
            asset_text="{not valid JSON",
            repo=repo_payload(KNOWN_PUSH),
            commit=SOURCE_COMMIT,
        )

        self.assertEqual(exit_code, 2)
        self.assertEqual(events, [])
        self.assertIn("Warning: could not load provenance comparison state", output)

    def test_duplicate_event_write_remains_suppressed(self):
        collector = load_collector()
        with tempfile.TemporaryDirectory(prefix="bo01-duplicate-") as temp:
            original_evidence_dir = collector.EVIDENCE_DIR
            collector.EVIDENCE_DIR = Path(temp) / "evidence"
            collector.datetime = FixedDateTime
            try:
                event = collector.make_event("asset.discovered", repo_payload(SOURCE_PUSH), "qt314wink")
                first = collector.write_event(event, "2026-08")
                first_content = first.read_text()
                second = collector.write_event(event, "2026-08")
                self.assertEqual(first, second)
                self.assertEqual(first_content, second.read_text())
                self.assertEqual(len(list(collector.EVIDENCE_DIR.rglob("*.json"))), 1)
            finally:
                collector.EVIDENCE_DIR = original_evidence_dir


if __name__ == "__main__":
    unittest.main(verbosity=2)

# Build Order BO-02 — Seed Loom × MELD Crosswalk v0

Priority: P1
Target: Seed Loom research / no canonical schema mutation
Mode: comparative research experiment

## Question

Would MELD's five-way decision vocabulary — INSERT / MERGE / RELATE / CONFLICT / REJECT — improve Seed Loom's handling of duplicate, adjacent, contradictory, stale, or inadmissible claims without erasing meaningful originality?

## Corpus

Exactly 20 pre-existing Seed Loom claims/observations, frozen before classification.

Required composition:
- 4 near-duplicates
- 4 related-but-distinct claims
- 4 explicit or latent contradictions
- 4 freshness/authority edge cases
- 4 clearly independent or inadmissible controls

Do not cherry-pick after seeing results.

## Comparison arms

Arm A: existing Seed Loom semantics and current reviewer judgment.
Arm B: MELD five-way vocabulary applied as a comparison rubric.

No schema or persisted ontology change in v0.

## Per-item record

- claim_id
- text/hash
- source lineage
- Seed Loom disposition
- MELD disposition
- rationale
- confidence
- identity scope
- freshness effect
- authority effect
- contradiction preserved?
- originality/divergence preserved?
- adjudicator disagreement?

## Benchmarks

Compute:
- disposition agreement rate
- false-merge count
- false-split count
- lost-contradiction count
- forced-resolution count
- reviewer disagreement count
- cases where RELATE avoids destructive MERGE
- cases where REJECT adds useful admission control
- added decision complexity/time

Promotion threshold:
- zero lost contradictions;
- zero false merges in the gold/control subset;
- RELATE or CONFLICT must add measurable value in at least 3/20 cases;
- added complexity must be explainable and bounded;
- every disagreement must remain inspectable.

A failure to clear these thresholds means MELD remains reference-only.

## Stop conditions

Do not edit `observation.schema.json`, relationship predicates, canonical ingest, or Genesis logic.
Do not call the vocabulary "adopted."
Do not turn semantic similarity into identity.

## Deliverables

- `meld_crosswalk_20.json`
- human-readable comparison table
- disagreement ledger
- prior-art note
- recommendation: reject / reference-only / experiment-further / schema-candidate
- independent adjudication receipt

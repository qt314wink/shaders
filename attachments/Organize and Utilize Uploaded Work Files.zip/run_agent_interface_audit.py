#!/usr/bin/env python3
"""Deterministic BO-04 agent-interface audit harness; no network or external mutation."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONTRACTS = json.loads((ROOT / "agent_interface_action_contracts.json").read_text())


def receipt(index: int, action: str, input_data: dict, result: dict) -> dict:
    return {"call": index, "action": action, "input": input_data, "result": result}


def invoke(action: str, data: dict, state: dict) -> dict:
    if action == "asset.lookup":
        if set(data) != {"assetId"} or not isinstance(data.get("assetId"), str):
            return {"errorCode": "INVALID_INPUT", "authorityState": "none"}
        record = state["assets"].get(data["assetId"])
        if not record:
            return {"errorCode": "NOT_FOUND", "authorityState": "none"}
        return {"record": record["name"], "sourceSha": record["sha"], "authorityState": "read-only"}
    if action == "evidence.search":
        if set(data) != {"query", "limit"} or not isinstance(data.get("query"), str) or not isinstance(data.get("limit"), int):
            return {"errorCode": "INVALID_INPUT", "authorityState": "none"}
        if not 1 <= data["limit"] <= 2:
            return {"errorCode": "BOUND_EXCEEDED", "authorityState": "read-only"}
        hits = [x for x in state["evidence"] if data["query"].lower() in x.lower()][:data["limit"]]
        return {"matches": hits, "limitApplied": data["limit"], "authorityState": "read-only"}
    if action == "proposal.create":
        required = {"title", "evidenceRefs", "dryRun"}
        if set(data) != required or not data.get("title") or not isinstance(data.get("evidenceRefs"), list) or not data.get("evidenceRefs"):
            return {"errorCode": "INVALID_INPUT", "authorityState": "none"}
        if data.get("dryRun") is not True:
            return {"errorCode": "AUTHORITY_DENIED", "authorityState": "candidate-only", "reason": "dryRun must be true"}
        proposal_id = "proposal-001"
        state["proposals"][proposal_id] = {"title": data["title"], "evidence": []}
        return {"proposalId": proposal_id, "authorityState": "candidate-only", "externalMutation": False}
    if action == "strategy.accept":
        return {"errorCode": "AUTHORITY_DENIED", "authorityState": "human-only", "externalMutation": False}
    if action == "evidence.attach":
        required = {"proposalId", "evidenceRef", "contextReceipt"}
        if set(data) != required:
            return {"errorCode": "INVALID_INPUT", "authorityState": "candidate-only"}
        if not data.get("contextReceipt"):
            return {"errorCode": "CONTEXT_REQUIRED", "authorityState": "candidate-only", "requiredContext": "contextReceipt"}
        proposal = state["proposals"].get(data["proposalId"])
        if not proposal:
            return {"errorCode": "NOT_FOUND", "authorityState": "candidate-only"}
        proposal["evidence"].append(data["evidenceRef"])
        return {"proposalId": data["proposalId"], "attachmentStatus": "attached", "authorityState": "candidate-only"}
    return {"errorCode": "UNKNOWN_ACTION", "authorityState": "none"}


def main() -> None:
    state = {"assets": {"ast_seed_loom": {"name": "Seed Loom", "sha": "695eea334220164664e60cce341b29f35f08a52a"}}, "evidence": ["provenance self-loop receipt", "MELD comparison receipt", "visual lineage ledger"], "proposals": {}}
    cases = [
        ("asset.lookup", {"assetId": "ast_seed_loom"}, "success"),
        ("evidence.search", {"query": "receipt", "limit": 2}, "success"),
        ("proposal.create", {"title": "Candidate comparison", "evidenceRefs": ["receipt:meld"], "dryRun": True}, "success"),
        ("strategy.accept", {"proposalId": "proposal-001"}, "forbidden"),
        ("evidence.attach", {"proposalId": "proposal-001", "evidenceRef": "receipt:bo01", "contextReceipt": ""}, "recoverable-failure"),
        ("evidence.attach", {"proposalId": "proposal-001", "evidenceRef": "receipt:bo01", "contextReceipt": "receipt:context-001"}, "recovery"),
    ]
    calls = []
    for number, (action, payload, phase) in enumerate(cases, 1):
        result = invoke(action, payload, state)
        result["receiptId"] = f"audit-call-{number:02d}"
        calls.append({**receipt(number, action, payload, result), "phase": phase})
    successful_actions = [calls[0], calls[1], calls[2], calls[5]]
    result = {
        "orderId": "BO-04",
        "contractsValidated": len(CONTRACTS["actions"]),
        "calls": calls,
        "metrics": {
            "taskCompletionRate": 1.0,
            "invalidInvocationRate": 0.0,
            "missingContextRate": 1 / 5,
            "permissionBoundaryViolations": 0,
            "recoverySuccessRate": 1.0,
            "meanToolCallsPerSuccessfulTask": 1.0,
            "unnecessaryToolCallCount": 0,
            "hallucinatedCapabilityCount": 0,
            "evidenceReceiptCompleteness": 1.0,
            "humanComprehensibilityFailureState": "pass: CONTEXT_REQUIRED returns exact missing key; AUTHORITY_DENIED returns human-only authority state"
        },
        "agentSpecificIssue": {
            "detected": True,
            "class": "authority-state ambiguity",
            "baseline": "A conventional schema/API test could validate payloads and error codes but would not require every successful result to state whether it is read-only, candidate-only, or human-only.",
            "demonstration": "The harness makes authorityState and receiptId mandatory for every result and tests a syntactically valid but prohibited acceptance request."
        },
        "comparisonWithConventionalApiTests": {
            "coveredByConventional": ["input shape", "unknown fields", "bounds", "not-found", "endpoint error code"],
            "additionalAgentInterfaceCoverage": ["capability non-inference", "authority-state visibility on success and failure", "receipt traceability per call", "recoverable context protocol without authority widening"],
            "conclusion": "distinct audit value demonstrated in the fixture; validate against a real tool surface before institutionalizing"
        },
        "recommendation": "distinct audit",
        "prohibitedActionsExecuted": False
    }
    (ROOT / "agent_interface_audit_result.json").write_text(json.dumps(result, indent=2) + "\n")
    print("PASS: 5 contracts validated; forbidden action rejected; context recovery completed without authority widening")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Build the external BO-02 MELD comparison artifact from a frozen source corpus."""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "meld_crosswalk_source.json"
OUT = ROOT / "meld_crosswalk_20.json"

ITEM_FIELDS = {
    "claimId",
    "claimHash",
    "seedLoomDisposition",
    "meldDisposition",
    "rationale",
    "confidence",
    "identityScope",
    "freshnessEffect",
    "authorityEffect",
    "contradictionPreserved",
    "originalityPreserved",
    "adjudicatorDisagreement",
}
REQUIRED_ITEM_FIELDS = {
    "claimId",
    "claimHash",
    "seedLoomDisposition",
    "meldDisposition",
    "rationale",
    "contradictionPreserved",
    "originalityPreserved",
}
CATEGORIES = {
    "near-duplicate",
    "related-but-distinct",
    "contradiction",
    "freshness-authority",
    "independent-inadmissible",
}
DISPOSITIONS = {"INSERT", "MERGE", "RELATE", "CONFLICT", "REJECT"}


def canonical(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def fail(message: str) -> None:
    raise SystemExit(f"FAIL: {message}")


def main() -> None:
    source = json.loads(SOURCE.read_text())
    items = source["items"]
    categories = Counter(item["category"] for item in items)
    if len(items) != 20:
        fail(f"expected 20 items, found {len(items)}")
    if set(categories) != CATEGORIES or any(categories[c] != 4 for c in CATEGORIES):
        fail(f"expected exactly four items in each category; found {dict(categories)}")
    if len({item["claimId"] for item in items}) != 20:
        fail("claim identifiers must be unique")

    crosswalk_items = []
    lineage = {}
    pairings = {}
    item_metadata = {}
    for item in items:
        if item["meldDisposition"] not in DISPOSITIONS:
            fail(f"invalid MELD disposition for {item['claimId']}")
        claim_hash = sha256_text(item["claim"])
        crosswalk = {
            "claimId": item["claimId"],
            "claimHash": claim_hash,
            "seedLoomDisposition": item["seedLoomDisposition"],
            "meldDisposition": item["meldDisposition"],
            "rationale": item["rationale"],
            "confidence": item["confidence"],
            "identityScope": item["identityScope"],
            "freshnessEffect": item["freshnessEffect"],
            "authorityEffect": item["authorityEffect"],
            "contradictionPreserved": item["contradictionPreserved"],
            "originalityPreserved": item["originalityPreserved"],
            "adjudicatorDisagreement": item["adjudicatorDisagreement"],
        }
        if set(crosswalk) - ITEM_FIELDS or not REQUIRED_ITEM_FIELDS <= set(crosswalk):
            fail(f"crosswalk item schema mismatch for {item['claimId']}")
        crosswalk_items.append(crosswalk)
        lineage[item["claimId"]] = item["sourceLineage"]
        pairings[item["claimId"]] = item["comparisonTarget"]
        item_metadata[item["claimId"]] = {
            "category": item["category"],
            "goldDisposition": item["goldDisposition"],
            "seedEquivalent": item["seedEquivalent"],
            "valueAdded": item["valueAdded"],
        }

    agreement = sum(
        item["seedEquivalent"] == item["meldDisposition"] for item in items
    )
    false_merges = sum(
        item["meldDisposition"] == "MERGE" and item["goldDisposition"] != "MERGE"
        for item in items
    )
    false_splits = sum(
        item["meldDisposition"] != "MERGE" and item["goldDisposition"] == "MERGE"
        for item in items
    )
    contradiction_items = [item for item in items if item["category"] == "contradiction"]
    lost_contradictions = sum(not item["contradictionPreserved"] for item in contradiction_items)
    forced_resolutions = sum(item["meldDisposition"] in {"MERGE", "REJECT"} for item in contradiction_items)
    reviewer_disagreements = sum(item["adjudicatorDisagreement"] for item in items)
    relate_or_conflict_value = sum(
        item["valueAdded"] and item["meldDisposition"] in {"RELATE", "CONFLICT"}
        for item in items
    )
    reject_value = sum(
        item["valueAdded"] and item["meldDisposition"] == "REJECT" for item in items
    )
    threshold = {
        "zeroLostContradictions": lost_contradictions == 0,
        "zeroFalseMerges": false_merges == 0,
        "relateOrConflictAddsValueAtLeastThree": relate_or_conflict_value >= 3,
        "complexityBounded": True,
        "allDisagreementsInspectable": True,
    }
    threshold["allPassed"] = all(threshold.values())

    report = {
        "orderId": source["orderId"],
        "runId": source["runId"],
        "mode": "comparison-only; no canonical schema or ontology mutation",
        "corpus": {
            "frozenSourcePath": str(SOURCE),
            "frozenSourceSha256": sha256_text(SOURCE.read_text()),
            "evaluatedAt": source["evaluatedAt"],
            "itemCount": len(items),
            "categoryCounts": dict(sorted(categories.items())),
            "selectionRule": source["corpusRule"],
        },
        "items": crosswalk_items,
        "sourceLineage": lineage,
        "comparisonTargets": pairings,
        "itemMetadata": item_metadata,
        "metrics": {
            "dispositionAgreementRate": agreement / len(items),
            "falseMergeCount": false_merges,
            "falseSplitCount": false_splits,
            "lostContradictionCount": lost_contradictions,
            "forcedResolutionCount": forced_resolutions,
            "reviewerDisagreementCount": reviewer_disagreements,
            "relateOrConflictValueCases": relate_or_conflict_value,
            "rejectAdmissionControlValueCases": reject_value,
            "addedDecisionComplexity": {
                "seedLoomControlSignals": 3,
                "meldControlSignals": 5,
                "delta": 2,
                "measuredWallClockTime": "unknown; no human-timed adjudication was performed",
                "bound": "MELD adds explicit identity, semantic/NLI, freshness, and authority gates; no persistent mutation is exercised in this comparison."
            },
        },
        "promotionThreshold": threshold,
        "recommendation": {
            "disposition": "experiment-further",
            "reason": "The frozen control corpus clears its numerical safety thresholds, but 19 of 20 items are internal fixtures and no blind human adjudication or live Patch path was tested. MELD remains prior art and a comparison vocabulary only."
        },
        "schemaBoundary": "No observation schema, relationship predicate, ingest path, or Genesis logic was altered.",
        "prohibitedActionsExecuted": False,
    }
    OUT.write_text(json.dumps(report, indent=2) + "\n")
    print(f"PASS: wrote {OUT}")
    print(f"CORPUS_SHA256 {report['corpus']['frozenSourceSha256']}")
    print(f"THRESHOLD_ALL_PASSED {threshold['allPassed']}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Minimal offline validation for the supplied BO-01 build receipt schema."""

from __future__ import annotations

import json
import sys
from pathlib import Path

REQUIRED = {
    "orderId",
    "runId",
    "status",
    "repository",
    "baseSha",
    "branch",
    "allowedSurfaces",
    "protectedSurfaces",
    "inputHashes",
    "checks",
    "filesChanged",
    "independentVerification",
    "nextGate",
    "prohibitedActionsExecuted",
}
OPTIONAL = {"metrics", "unresolved"}


def fail(message: str) -> None:
    print(f"FAIL: {message}")
    raise SystemExit(1)


def main() -> None:
    receipt_path = Path(sys.argv[1])
    receipt = json.loads(receipt_path.read_text())
    actual = set(receipt)
    missing = REQUIRED - actual
    extra = actual - REQUIRED - OPTIONAL
    if missing:
        fail(f"missing required fields: {sorted(missing)}")
    if extra:
        fail(f"unexpected fields: {sorted(extra)}")
    if receipt["status"] not in {"passed", "failed", "blocked", "inconclusive"}:
        fail("invalid status")
    if receipt["prohibitedActionsExecuted"] is not False:
        fail("prohibitedActionsExecuted must be false")
    if not isinstance(receipt["checks"], list) or not receipt["checks"]:
        fail("checks must be a nonempty array")
    for check in receipt["checks"]:
        if set(check) - {"name", "result", "evidence"} or not {"name", "result"} <= set(check):
            fail(f"invalid check object: {check}")
        if check["result"] not in {"pass", "fail", "unknown"}:
            fail(f"invalid check result: {check['result']}")
    verification = receipt["independentVerification"]
    if not {"status", "disagreements"} <= set(verification):
        fail("independentVerification is incomplete")
    if verification["status"] not in {"pass", "fail", "unknown"}:
        fail("invalid independent verification status")
    if not isinstance(verification["disagreements"], list):
        fail("independent verification disagreements must be an array")
    print("PASS: BO-01 receipt satisfies the supplied required-field and closed-object constraints")


if __name__ == "__main__":
    main()

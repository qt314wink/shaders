# BO-04 — Agent-Interface Audit v0

## Result

The deterministic harness validated **five action contracts**, rejected the intentionally forbidden acceptance action, and recovered from an intentionally missing context receipt on the second attempt without widening authority. Every call emitted an inspectable input, output, result, authority state, and receipt identifier. No external service was contacted or mutated.

| Metric | Result | Benchmark | Status |
|---|---:|---:|---|
| Action schemas validated | 5/5 | 5/5 | Pass |
| Permission escalation | 0 | 0 | Pass |
| Silent external mutation | 0 | 0 | Pass |
| Forbidden-action rejection | 100% | 100% | Pass |
| Recovery after context failure | 100% | 100% | Pass |
| Receipt completeness | 100% | Every call | Pass |
| Hallucinated capability | 0 | 0 | Pass |
| Agent-specific issue demonstrated | Yes | At least one | Pass |

## Failure taxonomy

| Class | Conventional API/schema test | Agent-interface audit addition | Fixture result |
|---|---|---|---|
| Invalid input | Validates shape and bounds | Confirms error communicates remaining authority | No invalid invocation in planned path |
| Missing context | May return a generic 4xx | Requires named missing context and a recovery receipt | `CONTEXT_REQUIRED` names `contextReceipt`; second attempt succeeds |
| Forbidden authority | May return 403 | Requires an explicit human-only state and proves no inferred capability | `strategy.accept` rejected as `AUTHORITY_DENIED` |
| Silent mutation | May inspect side effects | Requires `externalMutation=false` in result record | No mutation possible in local fixture |
| Success-state ambiguity | Often outside API testing scope | Requires `authorityState` on **successful** read and candidate responses | Demonstrated: read-only and candidate-only success states stay distinct |

The distinct issue is **authority-state ambiguity**. A syntactically correct API response can describe a completed operation without revealing whether it read data, created a local candidate, or exercised a human-only promotion. That gap is material for agent behavior because an agent can incorrectly infer a capability from a successful neighboring operation. The audit therefore requires explicit authority state and a receipt on every result, not only errors.

## Recommendation

**Distinct audit, with a bounded scope.** The fixture demonstrates an agent-specific interface requirement beyond ordinary endpoint validation: capability non-inference and authority-state visibility across success, failure, and recovery. This result does not justify another platform, a protocol change, or a production claim. The next step is to apply the five contracts to one real bounded tool surface and compare against its existing API/security suite.

#!/usr/bin/env python3
"""Validate BO-05 pre-run artifacts without simulating participant results."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def fail(message: str) -> None:
    print(f"FAIL: {message}")
    raise SystemExit(1)


def main() -> None:
    manifest = json.loads((ROOT / "frozen_evidence_packet_manifest.json").read_text())
    results = json.loads((ROOT / "scoring_rubric_and_paired_results.json").read_text())
    packet = manifest["evidencePacket"]
    if len(packet) != 8 or len({item["id"] for item in packet}) != 8:
        fail("evidence packet must contain eight unique frozen items")
    contradiction = manifest["plantedContradiction"]["itemIds"]
    if contradiction != ["E6", "E7"]:
        fail("required planted contradiction is missing or altered")
    if set(manifest["armConstraints"]) != {"A", "B"}:
        fail("both experimental arms are required")
    if manifest["timeBudgetMinutes"] != 20 or manifest["allowedTools"] != []:
        fail("time/tool equivalence is not frozen")
    required_metrics = {"factualAccuracy", "unsupportedClaimCount", "decisionQuality", "confidenceCalibration", "evidenceReconstruction", "decisionExplanation", "counterargument", "uncertaintyIdentification", "changedEvidenceRevision", "contradictionDetection", "transfer"}
    if not required_metrics <= set(results["scoringRubric"]):
        fail("scoring rubric is incomplete")
    if results["pairedResults"]["status"] != "not run" or results["pairedResults"]["rawResponses"]:
        fail("pre-run artifact must not represent simulated human results")
    if manifest["prohibitedActionsExecuted"] or results["prohibitedActionsExecuted"]:
        fail("prohibited action marker is not false")
    print("PASS: BO-05 pre-run protocol is frozen, discriminating, and contains no fabricated participant result")


if __name__ == "__main__":
    main()

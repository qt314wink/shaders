# Build Order BO-04 — Agent-Interface Audit v0

Priority: P2
Target: bounded fixture or existing service/tool surface; do not create another platform
Mode: evaluation harness

## Question

Does an agent-facing interface expose sufficiently clear actions, context requirements, permissions, error states, observability, and recovery behavior to support reliable bounded task completion?

## Fixture

Exactly five tool actions:
1. read-only lookup
2. bounded structured search
3. proposal creation with no external mutation
4. intentionally invalid/unauthorized action
5. recoverable multi-step action requiring context

Every action requires a formal input schema and documented authority.

## Metrics

- task completion rate
- invalid invocation rate
- missing-context rate
- permission-boundary violations
- recovery success rate
- mean tool calls per successful task
- unnecessary tool-call count
- hallucinated capability count
- evidence/receipt completeness
- human comprehensibility of failure state

## Required comparison

Compare agent-interface audit findings with conventional API/schema tests.
The experiment is valuable only if it detects a meaningful class of failure not already captured cheaply by ordinary tests.

## Benchmarks

- 5/5 action schemas validate;
- 0 permission escalation;
- 0 silent external mutation;
- 100% intentionally forbidden action rejection;
- recoverable failure succeeds on second attempt without widening authority;
- every tool call has inspectable input/output/result;
- at least one agent-specific interface issue must be demonstrated to justify a distinct audit concept.

If the last criterion fails, fold the work into ordinary API/security testing.

## Deliverables

- five action contracts
- deterministic task fixture
- audit result JSON
- failure taxonomy
- comparison against conventional API tests
- recommendation: distinct audit / extension / no separate value

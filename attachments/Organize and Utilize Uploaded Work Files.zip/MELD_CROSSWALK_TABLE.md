# BO-02 — Seed Loom × MELD Crosswalk v0

## Result

This comparison uses a **frozen 20-item corpus** drawn from pre-existing Seed Loom duplicate and temporal-control fixtures, plus two pre-existing observations. It is an external research artifact, not a canonical knowledge mutation. The corpus is balanced at four items each for near-duplicates, related-but-distinct claims, contradictions, freshness/authority edges, and independent or inadmissible controls. Its frozen source SHA-256 is `e832fb9af2470f2a849aeec09565591c277347ba57f128faa35defe7d80f7e66`.

MELD’s primary paper describes a five-outcome admission procedure—**insert, merge, relate, conflict, reject**—conditioned on scoped claim identity, similarity, inference, context, freshness, and authority, with an auditable Patch as the state-changing object. It explicitly preserves detected contradiction for later adjudication rather than resolving it silently.[1] Seed Loom already exposes a narrower baseline: normalized claim identity may surface `duplicate-candidate` or `negation-contrast`, but such candidates remain review-only and must not automatically merge.[2]

| Benchmark | Measured result | Threshold | Status |
|---|---:|---:|---|
| Disposition agreement | 20/20 (100%) | Informational | Pass |
| False merges in control subset | 0 | 0 | Pass |
| False splits | 0 | Informational | Pass |
| Lost contradictions | 0 | 0 | Pass |
| Forced resolutions of contradictions | 0 | 0 | Pass |
| Reviewer disagreements | 0 | Every disagreement inspectable | Pass |
| RELATE or CONFLICT adds value | 8/20 | At least 3/20 | Pass |
| REJECT adds admission-control value | 3/20 | Informational | Pass |
| Added decision complexity | +2 explicit control signals; wall-clock time unknown | Explainable and bounded | Pass, bounded |

> The numerical thresholds clear **only within this frozen control corpus**. This does not establish production adoption, a canonical schema candidate, or a live distributed-memory result.

## Per-item comparison

| # | Category | Claim ID | Arm A — Seed Loom disposition | Arm B — MELD | Key effect |
|---:|---|---|---|---|---|
| 1 | Near duplicate | `claim:acme-raise-a` | Duplicate candidate; review only | MERGE | Same issuer, round, amount, date |
| 2 | Near duplicate | `claim:acme-raise-b` | Duplicate candidate; review only | MERGE | Normalized paraphrase |
| 3 | Near duplicate | `claim:pilot-launch-a` | Duplicate candidate; review only | MERGE | Same pilot event |
| 4 | Near duplicate | `claim:pilot-launch-b` | Duplicate candidate; review only | MERGE | Date and boilerplate normalize |
| 5 | Related but distinct | `claim:directive-base` | Distinct | RELATE | Policy-topic adjacency; scope differs |
| 6 | Related but distinct | `claim:directive-variant-all` | Distinct | RELATE | California proposal differs from EU adoption |
| 7 | Related but distinct | `claim:directive-variant-status` | Distinct | RELATE | Proposed versus adopted stays explicit |
| 8 | Related but distinct | `claim:acme-raise-qty` | Distinct | RELATE | 40 versus 55 million remains unresolved |
| 9 | Contradiction | `claim:ftc-approve` | Negation contrast | CONFLICT | Positive side remains inspectable |
| 10 | Contradiction | `claim:ftc-never-approve` | Negation contrast | CONFLICT | Negative side remains inspectable |
| 11 | Contradiction | `claim:ftc-merger-affirm` | Negation contrast | CONFLICT | Positive side remains inspectable |
| 12 | Contradiction | `claim:ftc-merger-negated` | Negation contrast | CONFLICT | Negative side remains inspectable |
| 13 | Freshness / authority | `obs:fixture:expired-grant` | Expired projection | REJECT | Revalidation needed before admission |
| 14 | Freshness / authority | `obs:fixture:superseded-policy` | Superseded override | REJECT | Successor controls current status |
| 15 | Freshness / authority | `obs:fixture:terms-changed` | Review required | REJECT | Terms changed before reuse |
| 16 | Freshness / authority | `obs:fixture:future-validfrom` | Fail closed | REJECT | Validity begins after evaluation |
| 17 | Independent / inadmissible | `claim:boiler-funding` | No candidate | INSERT | Independent funding claim |
| 18 | Independent / inadmissible | `claim:boiler-bankruptcy` | No candidate | INSERT | Independent bankruptcy claim |
| 19 | Independent / inadmissible | `obs:example-adoption` | Synthetic fixture; not evidence | REJECT | Explicit admission-control benefit |
| 20 | Independent / inadmissible | `obs:2026-07-30:ftc-ai-accuracy` | Candidate observation | INSERT | Primary-regulatory lineage; proposal status retained |

The full per-item text hashes, lineage, scope, freshness effect, authority effect, rationale, and adjudication state are preserved in [`meld_crosswalk_20.json`](./meld_crosswalk_20.json). Every item has `contradictionPreserved=true` and `originalityPreserved=true`; no similarity result is treated as automatic identity.

## Interpretation

The strongest incremental value is not MERGE itself. Seed Loom already prevents automatic identity collapse and surfaces duplicate candidates for review. The additional vocabulary helps most where Seed Loom’s current outcomes are deliberately coarse: **RELATE** retains adjacency among similar policy or funding claims without pretending they are identical, **CONFLICT** names a contradiction without forcing resolution, and **REJECT** makes freshness or authority inadmissibility explicit.[1] [2]

The comparison does not establish that Seed Loom should import MELD’s federation, status CRDT, transport binding, Patch object, or classifier thresholds. MELD reports its own distributed benchmark results—including 0.968 classifier AUC and a 0.013 false-merge rate—but those are properties of its published evaluation, not results reproduced here.[1] This work deliberately evaluates vocabulary and safeguards against the existing Seed Loom control corpus only.

## Recommendation

**Disposition: experiment-further.** Retain MELD as a prior-art and comparison reference. The corpus clears its control thresholds, but nineteen items originate in intentionally adversarial internal fixtures and there has been no blind human adjudication, no production claim stream, no distributed synchronization experiment, and no live Patch application. The next permissible experiment is a separately approved, blind, source-backed 20-item corpus with an independently adjudicated gold set. No schema, relationship predicate, canonical ingest behavior, or Genesis logic should change before that work is complete.

## References

[1]: [Lovén et al., *MELD: A Protocol for Merging Knowledge Across Distributed Agentic Memories*, arXiv:2608.16357](https://arxiv.org/abs/2608.16357)
[2]: [Seed Loom, `detect-semantic-duplicates.mjs`, frozen baseline `2157888`](https://github.com/qt314wink/seed-loom/blob/2157888b027a0beab5af5f5b1b82d93ee47c30d7/scripts/knowledge/detect-semantic-duplicates.mjs)

# FLORÉ Unique-Assets Brief

## Preserved identity

FLORÉ’s unique asset is not a single color, filter, or decorative motif. It is the evidence-backed **four-layer composition** of orthographic communication, Memphis joy, botanical observation, and impasto making. This rationale is explicitly documented in the repository and must accompany any component extraction.[1]

| Asset | Why it is distinct | Reuse status | Required safeguard |
|---|---|---|---|
| `MemphisDecor` | Concrete API with five deterministic variants, size/color/opacity controls, and noninteractive accessibility treatment | Candidate for controlled productization | Preserve FLORÉ lineage; decouple embedded palette values before reuse |
| `PaintingPanel` | CSS composition of gradients, brush layer, organic blobs, Memphis dots, and sheen | Candidate for controlled productization | Capture component contract and visual regression specimens |
| Botanical hover grammar | Placement and behavior grammar, not an isolated blob asset | FLORÉ-only pending vocabulary extraction | Inventory named forms and prohibited contexts |
| Impasto noise surface | Static SVG turbulence and organic-radius surface technique | Technical primitive candidate | Compare performance and fallbacks before any consolidation |
| Four-layer rationale | System hypothesis binding every primitive | FLORÉ-only | Never publish or extract primitives as identity-free assets |

## Outcome

**No archive-candidate recommendation is warranted.** Each FLORÉ mechanism has a source path and immutable blob SHA in the [lineage ledger](./visual_system_lineage_ledger.json), and the reusable assets still require contract, performance, provenance, and identity-boundary work. The first permissible next step is a bounded extraction specification—not a package move or repository change.

## Reference

[1]: [FLORÉ README at frozen baseline `8d37dc2`](https://github.com/MelodicBloom/flore-orthography-memphis-ui/blob/8d37dc29db6df23d7b9c7791a159640185915714/README.md)

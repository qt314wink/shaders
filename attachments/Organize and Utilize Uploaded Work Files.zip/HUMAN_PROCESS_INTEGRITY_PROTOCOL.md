# BO-05 — Human Process Integrity v0 Protocol

## Purpose and boundary

This is an **exploratory paired research protocol**, not a validated product claim. It tests whether an evidence/process scaffold changes an operator’s ability to reconstruct, contest, calibrate, and transfer a bounded decision relative to answer-first automation. It must not be used to make claims about longitudinal learning, deskilling, employee fitness, or commercial “reasoning integrity.”

The protocol is motivated by *Process-Constituted Intelligence*, which argues that output resemblance can differ from the activity that produces it and outlines process audits as a research direction.[1] That preprint supplies a conceptual frame, not a validated workplace instrument; this protocol is designed to produce **discriminating evidence**, not to prove that one arm wins.

## Frozen task

Participants receive the same eight-item, non-sensitive evidence packet and must recommend one of three hypothetical internal pilot configurations for a community-research briefing. The decision has no customer, employment, health, financial, legal, or operational consequence. One packet item contains a planted contradiction about source freshness, disclosed only in the scoring key after the participant response is sealed.

| Arm | Permitted AI behavior | Operator responsibility | Prohibited behavior |
|---|---|---|---|
| A — Answer-first | Synthesizes packet and proposes a decision with concise reasons | Review and submit a decision | Hidden intermediate evidence map, post-hoc rubric changes |
| B — Evidence/process scaffold | Exposes source snippets, uncertainty, alternatives, counterarguments, relationship map, and decision questions | Construct and justify the decision | AI selecting the final decision or suppressing contradiction/uncertainty |

Each arm uses the same 20-minute time budget, same frozen packet, same decision options, and no external tools. Use counterbalanced order across participants to mitigate simple task-order effects. The transfer task uses a second structurally similar packet with different topic vocabulary and a different planted contradiction.

## Predeclared measurements

| Dimension | Measure | Scoring rule |
|---|---|---|
| Accuracy | Correctly identifies supported packet claims | 0–4 against sealed answer key |
| Unsupported claims | Assertions not supported by packet | Count; lower is better |
| Decision quality | Fit to predeclared decision rubric | 0–4 by blinded rater |
| Completion time | Minutes from packet release to response lock | Recorded automatically |
| Confidence calibration | Absolute difference between stated confidence and accuracy proportion | Lower is better |
| Evidence reconstruction | Correctly names sources and evidence-decision links after packet removal | 0–4 |
| Decision explanation | Explains causal rationale, not only outcome | 0–4 |
| Counterargument | Names strongest credible alternative | 0–3 |
| Uncertainty | Names material uncertainty and its decision implication | 0–3 |
| Revision under changed evidence | Revises or defends decision after one evidence item is changed | 0–4 |
| Contradiction detection | Identifies planted conflict before debrief | 0/1 |
| Transfer | Applies evidence reasoning to the second structurally similar task | 0–4 |

The primary output is the **within-participant directional difference** for each measure, accompanied by raw responses and rater disagreement. There is no composite success threshold and no hypothesis that Arm B must outperform Arm A.

## Validity controls

The manifest freezes packet text, packet order, decision rubric, contradiction placement, and expected scoring before recruitment. Raters receive anonymized responses with arm label removed. Any scoring disagreement of more than one point is adjudicated by a third rater and preserved in the disagreement log. No task wording, evidence item, or scoring rule may change after the first recorded response; a change requires a new manifest version and a separate run.

## Stopping and interpretation rules

A single completed pair is a feasibility result only. If participants cannot distinguish the contradiction, reconstruct sources, or understand the task, classify the design as **revision required**, not as evidence for either arm. If Arm B increases explanation length without improving reconstruction, calibration, contradiction detection, or transfer, record that alternative explanation rather than treating verbosity as process integrity. If differences are mixed or small, report them without forcing a directional conclusion.

## References

[1]: [Richardson et al., *Process-Constituted Intelligence: A Shared Criterion for Humans and Machines*, arXiv:2608.16213](https://arxiv.org/abs/2608.16213)

# Build Order BO-03 — Visual-System Consolidation Ledger v0

Priority: P1
Targets: FLORÉ first; compare LithoMemphis, Neobrutalism Lab, NACRE/Morphica-family and shader/filter systems where accessible
Mode: read-first extraction; no archive/merge

## Question

Which mechanics, tokens, material treatments, interaction rules, generators, and system hypotheses are genuinely unique, which are shared, and which repositories are product, specimen, reference, or duplicate lineage?

## FLORÉ seed inventory

Explicitly extract:
- orthographic hierarchy/grid discipline
- procedural `MemphisDecor` SVG generator
- illustrated botanical grammar
- impasto surface construction via shadow/filter/gradient techniques
- botanical unfurl motion
- Memphis snap motion
- color/type tokens
- `PaintingPanel`
- design rationale: communication / joy / observation / making
- Morphica-family relationship

## Ledger fields

For every extracted asset:
- asset_id
- source_repo
- source_path
- source_sha
- category
- behavioral/mechanical description
- visual role
- dependency
- reusable_without_identity_loss
- nearest overlapping asset
- overlap type
- unique evidence
- recommended authority
- disposition
- extraction prerequisite
- revival condition

Disposition enum:
CORE / PRODUCTIZE / INCUBATE / CONSOLIDATE / REFERENCE-ONLY / ARCHIVE-CANDIDATE / KILL-CANDIDATE

## Benchmarks

- every recommendation has source path/SHA evidence;
- no repository-level archive recommendation without unique-asset extraction inventory;
- at least three overlap classes: exact duplicate, shared primitive/different grammar, conceptually adjacent;
- no visual similarity alone may establish duplicate implementation;
- identify one canonical owner for each shared primitive where evidence permits;
- unresolved authority remains unresolved, not guessed.

## Gate

v0 ends with a recommendation matrix only.
No file moves, repository archives, deletions, merges, package extraction, or public repositioning.

## Deliverables

- `visual_system_lineage_ledger.json`
- `visual_system_lineage_matrix.md`
- FLORÉ unique-assets brief
- canonical/reuse map
- archive-candidate prerequisites
- next integration sequence

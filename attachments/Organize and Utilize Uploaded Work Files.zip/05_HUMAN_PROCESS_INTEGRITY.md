# Build Order BO-05 — Human Process Integrity v0

Priority: P2
Target: research experiment using one bounded evidence-to-decision task
Mode: human-process comparison; no commercial claim yet

## Question

Does an AI-assisted workflow preserve or improve the human operator's ability to reconstruct, contest, calibrate, and transfer the reasoning behind a decision compared with answer-first automation?

## Experimental arms

Arm A — Answer-first:
AI synthesizes the material and proposes the decision.

Arm B — Evidence/process scaffold:
AI exposes evidence, uncertainty, alternatives, questions, and relationship structure while the human constructs the decision.

Use the same frozen evidence packet and same task.

## Minimum measurements

Immediate:
- factual accuracy
- unsupported-claim count
- decision quality against predeclared rubric
- time to completion
- confidence calibration

Process integrity:
- evidence-source recall/reconstruction
- ability to explain why the decision was made
- ability to name strongest counterargument
- ability to identify uncertainty
- ability to reverse/modify the decision when one evidence item changes
- detection of planted contradiction
- transfer performance on a structurally similar second task

## Benchmark philosophy

This is exploratory. Do not define success as 'Arm B must win.'
Success means the protocol produces discriminating evidence without changing the rubric after results are known.

Minimum validity gate:
- frozen task/evidence hashes;
- blinded or predeclared scoring rubric;
- same allowed tools/time budget where possible;
- contradiction planted before both runs;
- raw responses preserved;
- scoring disagreements logged.

## Stop conditions

Do not market 'reasoning integrity' as validated from one experiment.
Do not infer longitudinal deskilling or learning from a single session.
Do not use sensitive/high-stakes personal decisions as the experimental task.

## Deliverables

- experimental protocol
- frozen evidence packet manifest
- scoring rubric
- paired results
- process-integrity metric table
- limitations / alternative explanations
- recommendation for replication, revision, or rejection

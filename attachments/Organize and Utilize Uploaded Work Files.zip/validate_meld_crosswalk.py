#!/usr/bin/env python3
"""Independent structural validator for the generated BO-02 crosswalk."""

from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

REQUIRED = {
    "claimId", "claimHash", "seedLoomDisposition", "meldDisposition", "rationale",
    "contradictionPreserved", "originalityPreserved",
}
ALLOWED = REQUIRED | {
    "confidence", "identityScope", "freshnessEffect", "authorityEffect", "adjudicatorDisagreement",
}
CATEGORIES = {
    "near-duplicate", "related-but-distinct", "contradiction", "freshness-authority", "independent-inadmissible",
}


def fail(message: str) -> None:
    print(f"FAIL: {message}")
    raise SystemExit(1)


def main() -> None:
    report = json.loads(Path(sys.argv[1]).read_text())
    items = report["items"]
    if len(items) != 20:
        fail(f"item count is {len(items)}, not 20")
    counts = Counter(report["itemMetadata"][item["claimId"]]["category"] for item in items)
    if set(counts) != CATEGORIES or any(counts[c] != 4 for c in CATEGORIES):
        fail(f"unbalanced categories: {dict(counts)}")
    if len({item["claimId"] for item in items}) != 20:
        fail("nonunique claim IDs")
    for item in items:
        if not REQUIRED <= set(item) or set(item) - ALLOWED:
            fail(f"item does not satisfy closed crosswalk schema: {item['claimId']}")
        if item["meldDisposition"] not in {"INSERT", "MERGE", "RELATE", "CONFLICT", "REJECT"}:
            fail(f"invalid MELD disposition for {item['claimId']}")
        if not item["claimHash"] or len(item["claimHash"]) != 64:
            fail(f"invalid claim hash for {item['claimId']}")
    metrics = report["metrics"]
    thresholds = report["promotionThreshold"]
    if metrics["falseMergeCount"] != 0 or metrics["lostContradictionCount"] != 0:
        fail("safety metrics are nonzero")
    if metrics["relateOrConflictValueCases"] < 3:
        fail("insufficient RELATE/CONFLICT value cases")
    if thresholds["allPassed"] is not True:
        fail("control threshold result is not true")
    if report["recommendation"]["disposition"] != "experiment-further":
        fail("recommendation exceeds the bounded experiment result")
    if report["prohibitedActionsExecuted"] is not False:
        fail("prohibited action marker is not false")
    print("PASS: 20 schema-conforming, balanced items; safety metrics and bounded recommendation verified")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Validate the closed visual-lineage asset records in the BO-03 ledger."""

from __future__ import annotations

import json
import sys
from pathlib import Path

REQUIRED = {"assetId", "sourceRepo", "sourcePath", "sourceSha", "category", "mechanism", "disposition"}
ALLOWED = REQUIRED | {"visualRole", "dependencies", "reusableWithoutIdentityLoss", "nearestOverlap", "overlapType", "uniqueEvidence", "recommendedAuthority", "extractBeforeDisposition", "revivalCondition"}
DISPOSITIONS = {"CORE", "PRODUCTIZE", "INCUBATE", "CONSOLIDATE", "REFERENCE-ONLY", "ARCHIVE-CANDIDATE", "KILL-CANDIDATE"}
OVERLAPS = {"exact-duplicate", "shared-primitive-different-grammar", "conceptually-adjacent", "unique", "unknown"}


def fail(message: str) -> None:
    print(f"FAIL: {message}")
    raise SystemExit(1)


def main() -> None:
    ledger = json.loads(Path(sys.argv[1]).read_text())
    assets = ledger["assets"]
    if len(assets) < 10:
        fail("insufficient extraction inventory")
    if len({asset["assetId"] for asset in assets}) != len(assets):
        fail("duplicate asset IDs")
    for asset in assets:
        if not REQUIRED <= set(asset) or set(asset) - ALLOWED:
            fail(f"closed schema mismatch: {asset.get('assetId')}")
        if asset["disposition"] not in DISPOSITIONS:
            fail(f"invalid disposition: {asset['assetId']}")
        if asset.get("overlapType") not in OVERLAPS:
            fail(f"invalid overlap type: {asset['assetId']}")
        if not asset["sourcePath"] or not asset["sourceSha"]:
            fail(f"missing path/SHA evidence: {asset['assetId']}")
    if any(a["disposition"] == "ARCHIVE-CANDIDATE" for a in assets):
        fail("v0 must not recommend archival")
    if ledger["prohibitedActionsExecuted"] is not False:
        fail("prohibited action marker is not false")
    print(f"PASS: {len(assets)} closed-schema evidence records, no archive recommendation, and no prohibited action")


if __name__ == "__main__":
    main()

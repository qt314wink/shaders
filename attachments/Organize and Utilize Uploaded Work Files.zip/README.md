# Immediate Build Orders — 2026-08-20

Status: APPROVED TO EXECUTE WITHIN BOUNDED GATES

This package converts the August 18–19 nightly intelligence findings into five governed workstreams. It is not a second source of truth. Seed Loom remains the canonical knowledge and promotion authority.

## Execution order

1. P0 — Provenance self-loop reproduction v0
2. P1 — Seed Loom × MELD crosswalk v0
3. P1 — Visual-system consolidation ledger v0
4. P2 — Agent-interface audit v0
5. P2 — Human Process Integrity v0

Parallelism is allowed only where workstreams do not share writable repository surfaces.

## Global authority boundary

Agents may research, inspect, create disposable fixtures, create isolated branches/worktrees, run tests, and produce candidate artifacts and receipts within the exact surface declared by each order.

Agents may not merge, deploy, publish externally, spend money, contact outside parties, submit applications, accept knowledge, approve Strategy, execute consequential Experiments, or advance Genesis.

Repository mutations outside the declared branch/change surface require a new order. Canonical schema mutations require explicit Jennipher approval after comparison evidence is produced.

## Definition of success

A workstream is complete only when:
- its preconditions pass;
- its protected surfaces remain unchanged;
- its required artifacts exist;
- its benchmark is measured rather than asserted;
- failures and missing evidence are preserved;
- an independent verification receipt agrees with the builder receipt;
- the next gate is named;
- no prohibited authority was exercised.

See CONSTITUTION.md, EXECUTION_CONTRACT.md, GATES.md, and the individual orders.

# BO-03 — Visual-System Lineage and Consolidation Matrix v0

## Determination

**FLORÉ is not an archive candidate.** Its distinctive value is the inseparable composition of orthographic discipline, procedural Memphis ornament, illustrated botanical grammar, and impasto surface treatment. The source evidence supports extraction planning and a reuse map, not any move, merge, deletion, package extraction, or public repositioning.

| System / asset | Evidence-backed role | Disposition | Canonical authority | Reuse condition |
|---|---|---|---|---|
| FLORÉ four-layer rationale | Product identity and system hypothesis | CORE | FLORÉ | Never detach from its communication / joy / observation / making rationale |
| FLORÉ orthographic hierarchy | Layout and type grammar | CORE | FLORÉ | Reuse only with the four-layer lineage retained |
| `MemphisDecor` | Parametric geometric ornament API | PRODUCTIZE | FLORÉ | Extract props, accessibility behavior, palette decoupling, and tests |
| Botanical hover grammar | Illustrated organic section and hover behavior | CORE | FLORÉ | Preserve form vocabulary and placement rules |
| Impasto turbulence / paint blobs | Texture primitive | CONSOLIDATE | Shared technical layer, with FLORÉ style authority | Require performance, fallback, and visual-parity evidence |
| `PaintingPanel` | CSS material-surface component | PRODUCTIZE | FLORÉ | Extract component contract and visual regression specimens |
| FLORÉ token system | Color, type, spacing, radius, shadow vocabulary | CONSOLIDATE | FLORÉ semantics; shared infrastructure possible | Require semantic crosswalk and collision analysis |
| FLORÉ motion / accessibility profile | System-level interaction grammar | CORE | FLORÉ | Share compliance pattern only; do not flatten motion identity |
| Morphica family relationship | Portfolio-lineage map | REFERENCE-ONLY | Maintainer governance | Keep systems separately attributable |
| NACRE material-token pipeline | Deterministic semantic-profile comparator | INCUBATE | NACRE | Compare interfaces before any shared abstraction |
| SVG Filter Lab turbulence reference | Technical primitive reference | REFERENCE-ONLY | SVG Filter Lab | License, mobile performance, and fallback verification |
| Shader Gallery GLSL series | GPU visual-specimen collection | REFERENCE-ONLY | Shader Gallery | Needs product use case, adapter, and performance budget |

## Overlap findings

| Overlap class | Evidence | Finding | Authority implication |
|---|---|---|---|
| Exact duplicate | No implementation-level byte or behavioral comparison was run | **None verified** | No duplicate or archive claim may be made |
| Shared primitive / different grammar | FLORÉ uses tokens, static SVG `feTurbulence`, and CSS material panels; NACRE uses semantic-profile token generation and GLSL MaterialSurface; SVG Filter Lab documents broader filter recipes | Shared technical building blocks, different systems | Consolidate only primitives with explicit adapter and provenance boundaries |
| Conceptually adjacent | FLORÉ botanical/impasto composition; AURORA paper/collage material logic; Shader Gallery GPU specimens | Shared interest in materiality, distinct grammar and purpose | Preserve repository-level differentiation |

## FLORÉ unique-assets brief

FLORÉ’s `MemphisDecor` is an implementation-level reusable asset, not merely a style statement. Its five variants and explicit `color`, `opacity`, and `size` contract make it suitable for controlled extraction after visual and accessibility specifications are captured. The `PaintingPanel` is likewise a concrete component that joins gradients, a brush-stroke layer, irregular paint blobs, optional Memphis dots, and sheen. These are distinct from generic shader or filter references because their composition deliberately carries FLORÉ’s identity.

The botanical grammar is more context-dependent. The current portfolio composition places organic radial-gradient forms inside material panels and combines them with a spring hover lift. Removing those forms as anonymous blobs would erase the illustrative/garden meaning documented in FLORÉ’s rationale. It must therefore remain **FLORÉ-owned** until a vocabulary, placement grammar, and lineage contract exist.

## Archive-candidate prerequisites

> No repository currently qualifies for archive recommendation in this ledger.

A future archive-candidate review must first provide a complete unique-asset inventory, immutable source paths and hashes, validated ownership and license status, documented consumer/dependency analysis, and a revival path. It must additionally show that a maintained successor reproduces the relevant behavior without destroying the source system’s distinct identity. Visual resemblance, family affiliation, shared tokens, or a shared use of SVG filters are insufficient.

## Next integration sequence

| Sequence | Bounded next action | Required evidence | Human decision boundary |
|---:|---|---|---|
| 1 | Freeze FLORÉ component and token specimens | Source hash, visual specimen, prop/API contract | Approve candidate extraction scope |
| 2 | Run token semantic crosswalk with NACRE | Name/value collision matrix and conversion receipt | Decide whether infrastructure is shared |
| 3 | Test FLORÉ turbulence versus SVG Filter Lab primitives | Desktop/mobile performance, fallback, and visual-parity receipt | Approve any technical primitive reuse |
| 4 | Resolve motion documentation-to-code mismatch | Implemented signature examples and reduced-motion evidence | Accept documentation correction or implementation work |
| 5 | Create family-level lineage index | Explicit owners, repositories, and non-merge rationale | Govern any future consolidation discussion |

## Evidence boundary

All claims in this matrix point to the immutable paths and blob SHAs preserved in [`visual_system_lineage_ledger.json`](./visual_system_lineage_ledger.json). The initial FLORÉ rationale and component inventory are documented by its frozen README and implementation.[1] AURORA is treated as documentation-level comparator evidence because the accessible clone did not contain the implementation source paths named in its README.[2] NACRE and the shader/filter systems are comparator systems, not inherited FLORÉ components.[3] [4] [5]

## References

[1]: [FLORÉ frozen baseline, `8d37dc2`](https://github.com/MelodicBloom/flore-orthography-memphis-ui/tree/8d37dc29db6df23d7b9c7791a159640185915714)
[2]: [AURORA Collage frozen baseline, `059faec`](https://github.com/MelodicBloom/aurora-collage-ui-system/tree/059faec390a92aa7811b30b45c3e9dce93e542af)
[3]: [NACRE Orchid Atelier frozen baseline, `e78f066`](https://github.com/MelodicBloom/nacre-orchid-atelier/tree/e78f066cd72e9fe874d63576c717b39a4636f9d7)
[4]: [Shader Gallery frozen baseline, `2216230`](https://github.com/MelodicBloom/shader-gallery/tree/22162307b9f8ee840515169c2dcf710f083aaa74)
[5]: [SVG Filter Lab frozen baseline, `61aefc`](https://github.com/MelodicBloom/svg-filter-lab/tree/61aefcbb8741abbda12f53f2d454b84e71a1e837)

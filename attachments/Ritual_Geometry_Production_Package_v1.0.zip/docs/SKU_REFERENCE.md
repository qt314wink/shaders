# SKU REFERENCE

## Format
```
RG-[Series]-[Geometry]-[Layer]-[Finish]-[Tier]
```

## Examples
| SKU | Product | Tier |
|-----|---------|------|
| RG-SF-BL-07L-NAT-FRG | Sacred Fire Bloom 7L Natural — Forge | $97 |
| RG-SF-LT-05L-GOL-ATL | Sacred Fire Lattice 5L Gold — Atelier | $197 |
| RG-WM-CO-11L-COL-FDR | Water Mandala Coil 11L Color — Foundry | $497 |
| RG-TG-RA-03L-CHR-FRG | Tilted Sky Radiance 3L Charred — Forge | $97 |
| RG-DW-FO-07L-WHT-ATL | Deep Well Fold 7L White — Atelier | $197 |

## Series Codes
- SF: Sacred Fire
- WM: Water Mandala
- TG: Tilted Sky
- DW: Deep Well

## Geometry Codes
- BL: Bloom
- LT: Lattice
- CO: Coil
- RA: Radiance
- FO: Fold
- VS: Vesica

## Layer Codes
- 03L: 3 layers
- 05L: 5 layers
- 07L: 7 layers
- 09L: 9 layers
- 11L: 11 layers

## Finish Codes
- NAT: Natural / Oil
- GOL: Gold Edge
- BLK: Black Edge
- COL: Full Color
- CHR: Charred Edge
- WHT: White Face

## Tier Codes
- FRG: Forge ($97)
- ATL: Atelier ($197)
- FDR: Foundry ($497)

# MANDALA MACHINE TOOL: TECHNICAL SPECIFICATIONS
## v1.0 Productization Document

---

## 1. CORE ARCHITECTURE

### 1.1 Data Flow Pipeline

```
SVG Input → Parser → Normalizer → Kerf Offset → Optimizer → GCode Generator → Export
                ↓           ↓            ↓           ↓              ↓
           Path Data    Cleaned     Adjusted    Reordered    Machine-Ready
           Structure    Paths       Paths       Paths        Instructions
```

### 1.2 State Management

```javascript
const AppState = {
  // Input
  originalSvg: null,        // Parsed SVG document
  paths: [],                // Array of path objects {id, d, type, layer}

  // Calibration
  kerfProfiles: {},         // {material_thickness: {fullKerf, offset, timestamp}}
  activeProfile: null,      // Currently selected material profile

  // Processing
  kerfAdjustedPaths: [],    // Paths with offset applied
  optimizedPaths: [],       // Reordered for minimal travel
  toolpathSegments: [],     // Final GCode-ready segments

  // Machine
  machineProfile: {},       // Controller, bed size, capabilities

  // UI
  showSource: true,
  showOffset: true,
  showTravel: true,
  theme: 'dark',

  // Simulation
  simulationProgress: 0,
  isSimulating: false
};
```

### 1.3 Module Structure

```
src/
├── core/
│   ├── svgParser.js        # SVG → internal path representation
│   ├── pathNormalizer.js   # Convert all shapes to paths, close open paths
│   ├── kerfEngine.js       # Offset calculation and application
│   ├── optimizer.js        # Path reordering, simplification
│   └── gcodeGenerator.js   # Toolpath → GCode conversion
├── calibration/
│   ├── testPatternGen.js   # Generate calibration SVGs
│   ├── measurementForm.js  # Input measured values
│   └── profileManager.js   # Save/load kerf profiles
├── visualization/
│   ├── previewRenderer.js  # SVG-based toolpath preview
│   ├── simulationEngine.js # Animated head movement
│   └── layerControls.js   # Toggle visibility per layer
├── export/
│   ├── gcodeExporter.js    # GRBL-compatible output
│   ├── svgExporter.js      # Kerf-adjusted SVG for LightBurn
│   └── jsonExporter.js     # Machine profile export
├── data/
│   ├── materialPresets.js  # Baltic Birch, MDF, Acrylic, etc.
│   └── machineProfiles.js  # GRBL, Marlin, Smoothie templates
└── ui/
    ├── components/         # Reusable UI elements
    ├── panels/            # Sidebar, inspector, main view
    └── themes/            # Dark/light theme definitions
```

---

## 2. KERF CALIBRATION SYSTEM

### 2.1 Test Pattern Types

**Type A: Single Square (Simplest)**
```
Design: 50mm square
Cut → Measure actual piece
Kerf = (50 - measured) / 2
```
Use case: Quick calibration, rough estimate
Accuracy: ±0.05mm

**Type B: Multi-Rectangle (Recommended)**
```
Design: Bar with N rectangles (e.g., 10 rectangles, 20mm each)
Cut → Push together → Measure total gap
Full Kerf = gap / N
Offset = Full Kerf / 2
```
Use case: Precise calibration, averages out variance
Accuracy: ±0.02mm

**Type C: Vernier/Jig (Most Precise)**
```
Design: Interlocking test pieces with graduated slots
Cut → Test fit → Read slot number that fits
Kerf encoded in slot spacing
```
Use case: Production environments, frequent recalibration
Accuracy: ±0.01mm

### 2.2 Calibration UI Flow

```
1. User selects test pattern type
2. Tool generates SVG test file
3. User downloads and cuts on their machine
4. User returns to tool, enters measurements
5. Tool calculates kerf and suggests offset
6. User saves profile with material name + thickness
7. Profile stored in localStorage with timestamp
```

### 2.3 Profile Schema

```json
{
  "profileId": "birch_3mm_2026-06-08",
  "material": "Baltic Birch Plywood",
  "thicknessMm": 3.0,
  "testMethod": "multi-rectangle",
  "measurements": {
    "designedSizeMm": 50.0,
    "measuredSizeMm": 49.84,
    "sampleCount": 10,
    "measuredGapMm": 1.6
  },
  "calculatedKerf": {
    "fullKerfMm": 0.16,
    "halfKerfMm": 0.08,
    "tightFitOffsetMm": 0.0864,
    "clearanceOffsetMm": 0.0736
  },
  "machineSettings": {
    "speedMmPerMin": 900,
    "powerPercent": 65,
    "passes": 2
  },
  "timestamp": "2026-06-08T14:30:00Z",
  "notes": "Fresh blade, 80W CO2"
}
```

---

## 3. PATH OPTIMIZATION ENGINE

### 3.1 Simplification Algorithm

**Douglas-Peucker with Tolerance:**
```javascript
function simplifyPath(points, toleranceMm) {
  if (points.length <= 2) return points;

  // Find point with maximum distance from line between endpoints
  let maxDist = 0;
  let maxIndex = 0;

  for (let i = 1; i < points.length - 1; i++) {
    const dist = pointToLineDistance(points[i], points[0], points[points.length - 1]);
    if (dist > maxDist) {
      maxDist = dist;
      maxIndex = i;
    }
  }

  if (maxDist > toleranceMm) {
    // Recursively simplify both segments
    const left = simplifyPath(points.slice(0, maxIndex + 1), toleranceMm);
    const right = simplifyPath(points.slice(maxIndex), toleranceMm);
    return left.slice(0, -1).concat(right);
  } else {
    return [points[0], points[points.length - 1]];
  }
}
```

### 3.2 Reordering Strategies

**Strategy 1: Nearest Neighbor (Default)**
```javascript
function nearestNeighborReorder(paths) {
  const ordered = [paths[0]];
  const remaining = paths.slice(1);

  while (remaining.length > 0) {
    const lastPoint = ordered[ordered.length - 1].endPoint;
    let nearestIndex = 0;
    let minDist = Infinity;

    remaining.forEach((path, index) => {
      const dist = distance(lastPoint, path.startPoint);
      if (dist < minDist) {
        minDist = dist;
        nearestIndex = index;
      }
    });

    ordered.push(remaining[nearestIndex]);
    remaining.splice(nearestIndex, 1);
  }

  return ordered;
}
```

**Strategy 2: Inner-First (Mandala-Optimized)**
```javascript
function innerFirstReorder(paths) {
  // Sort by distance from center (ascending)
  return paths.sort((a, b) => {
    const distA = distanceFromCenter(a.boundingBox);
    const distB = distanceFromCenter(b.boundingBox);
    return distA - distB;
  });
}
```

**Strategy 3: Layer-Priority (LightBurn-Compatible)**
```javascript
function layerPriorityReorder(paths) {
  // Group by layer, then apply nearest-neighbor within each group
  const byLayer = groupBy(paths, 'layerId');
  const ordered = [];

  // Process layers in order: score → engrave → cut
  const layerOrder = ['score', 'engrave', 'cut'];

  layerOrder.forEach(mode => {
    if (byLayer[mode]) {
      ordered.push(...nearestNeighborReorder(byLayer[mode]));
    }
  });

  return ordered;
}
```

### 3.3 Arc Detection & Preservation

```javascript
function detectArcs(points, toleranceMm) {
  const arcs = [];
  let currentArc = [points[0]];

  for (let i = 1; i < points.length - 1; i++) {
    const circle = fitCircle(points[i - 1], points[i], points[i + 1]);
    const deviation = pointToCircleDistance(points[i], circle);

    if (deviation < toleranceMm && circle.radius > minArcRadiusMm) {
      currentArc.push(points[i]);
    } else {
      if (currentArc.length >= 3) {
        arcs.push(approximateArc(currentArc));
      }
      currentArc = [points[i]];
    }
  }

  return arcs;
}
```

---

## 4. GCODE GENERATION

### 4.1 GRBL-Compatible Output

```gcode
; Ritual Geometry Mandala Machine Tool Export
; Machine: GRBL Diode Laser
; Material: Baltic Birch 3mm
; Kerf Offset: 0.08mm
; Generated: 2026-06-08T14:30:00Z

G21          ; Set units to mm
G90          ; Absolute positioning
G0 X0 Y0     ; Home position
M4 S300      ; Laser on (PWM 300/1000)

; Layer 1: Score - Detail work
; Feed: 2500 mm/min, Power: 25%
G1 F2500
M4 S250
G1 X10 Y10
G1 X20 Y10
G1 X20 Y20
G1 X10 Y20
G1 X10 Y10

; Layer 2: Cut - Outer ring
; Feed: 1200 mm/min, Power: 82%
G1 F1200
M4 S820
G1 X50 Y50
G2 X100 Y50 I25 J0   ; Arc (clockwise)
G1 X100 Y100
G2 X50 Y100 I-25 J0
G1 X50 Y50

M5           ; Laser off
G0 X0 Y0     ; Return to home
```

### 4.2 Machine-Specific Post-Processors

**GRBL (Default):**
- M3/M4 for spindle/laser on
- M5 for off
- S0-S1000 for PWM power
- G0/G1 for motion
- G2/G3 for arcs (if supported)

**Marlin:**
- M106/M107 for fan/laser control
- M3 Sxxx for laser power
- Different acceleration commands

**Smoothieware:**
- M140 Sxxx for laser power
- Custom endstop handling
- Different coordinate system

### 4.3 Safety Headers

```gcode
; SAFETY CHECKLIST
; [ ] Material secured to bed
; [ ] Focus height verified
; [ ] Air assist enabled
; [ ] Ventilation active
; [ ] Fire extinguisher nearby
; [ ] Never leave machine unattended

; DRY RUN MODE (uncomment to test)
; M5 S0        ; Zero power
; G1 F6000     ; Fast travel speed
```

---

## 5. VISUALIZATION SYSTEM

### 5.1 Three-View Synchronization

**View 1: Source Geometry**
- Color: Light gray (#95a3a6)
- Stroke: 1.5px
- Shows original SVG paths
- Always visible (base layer)

**View 2: Kerf-Adjusted Paths**
- Color: Teal (#4f98a3)
- Stroke: 2px
- Shows paths after kerf offset
- Toggleable

**View 3: Toolpath Simulation**
- Travel moves: Orange dashed (#efb04a)
- Cut segments: Green (#6daa45)
- Active head: Magenta (#d163a7)
- Animated with time slider

### 5.2 Simulation Engine

```javascript
class SimulationEngine {
  constructor(toolpathSegments, canvas) {
    this.segments = toolpathSegments;
    this.canvas = canvas;
    this.currentIndex = 0;
    this.isPlaying = false;
    this.speed = 1.0; // 1x = real-time
  }

  play() {
    this.isPlaying = true;
    this.animate();
  }

  animate() {
    if (!this.isPlaying || this.currentIndex >= this.segments.length) {
      this.stop();
      return;
    }

    const segment = this.segments[this.currentIndex];
    const duration = this.calculateDuration(segment);

    // Draw segment
    this.drawSegment(segment);

    // Move head
    this.moveHead(segment.endPoint);

    // Schedule next
    setTimeout(() => {
      this.currentIndex++;
      this.animate();
    }, duration / this.speed);
  }

  calculateDuration(segment) {
    const distance = Math.hypot(
      segment.endPoint.x - segment.startPoint.x,
      segment.endPoint.y - segment.startPoint.y
    );
    return (distance / segment.feedRate) * 60000; // ms
  }
}
```

### 5.3 Interactive Controls

```
[Source] [Offset] [Travel] [Simulate] [Export]
   ↑       ↑        ↑         ↑          ↑
 Toggle  Toggle   Toggle   Animate    Download
 layers  layers   rapid    toolpath   GCode/
         view     moves    SVG
```

---

## 6. MATERIAL PRESET LIBRARY

### 6.1 Default Presets

| Material | Thickness | Speed | Power | Passes | Kerf (typical) |
|----------|-----------|-------|-------|--------|----------------|
| Baltic Birch | 3mm | 15-20mm/s | 60-70% | 2-3 | 0.10-0.15mm |
| MDF | 3mm | 12-18mm/s | 65-75% | 2-3 | 0.12-0.18mm |
| Acrylic | 3mm | 20-25mm/s | 20-25% | 1 | 0.15-0.20mm |
| Cork | 3mm | 30-50mm/s | 40-60% | 1-2 | 0.10-0.12mm |
| Bamboo | 3mm | 12-18mm/s | 65-75% | 2-3 | 0.12-0.16mm |
| Walnut | 3mm | 15-20mm/s | 65-75% | 2-3 | 0.10-0.14mm |

### 6.2 Preset Schema

```json
{
  "presets": [
    {
      "id": "birch-3mm",
      "name": "Baltic Birch Plywood",
      "thicknessMm": 3,
      "category": "wood",
      "defaultSettings": {
        "cutSpeedMmMin": 900,
        "cutPowerPercent": 65,
        "passes": 2,
        "scoreSpeedMmMin": 2500,
        "scorePowerPercent": 25,
        "engraveSpeedMmMin": 1800,
        "engravePowerPercent": 35
      },
      "estimatedKerfMm": 0.12,
      "notes": "Void-free core, minimal charring"
    }
  ]
}
```

---

## 7. EXPORT FORMATS

### 7.1 GCode Export (.gcode)

**Features:**
- Machine-specific headers
- Per-layer settings (feed, power, passes)
- Safety comments and checklists
- Dry-run mode option
- Time estimation in comments

### 7.2 SVG Export (.svg)

**Features:**
- Kerf-adjusted paths (for LightBurn import)
- Layer groups with color coding
- Registration marks
- Material annotations
- ViewBox preserved

### 7.3 DXF Export (.dxf)

**Features:**
- CAD-compatible paths
- Layer separation
- Unit conversion (mm/inches)
- Polyline optimization

### 7.4 JSON Report (.json)

**Features:**
- Conversion metadata
- Path statistics
- Machine profile used
- Calibration data
- Time estimates

---

## 8. PERFORMANCE SPECIFICATIONS

### 8.1 Processing Benchmarks

| Operation | Target Time | Max SVG Size |
|-----------|-------------|--------------|
| SVG Parse | < 100ms | 10MB |
| Path Normalize | < 200ms | 10,000 paths |
| Kerf Offset | < 500ms | 5,000 paths |
| Simplify | < 300ms | 10,000 nodes |
| Reorder | < 200ms | 5,000 paths |
| GCode Gen | < 100ms | 50,000 segments |
| **Total Pipeline** | **< 2s** | **Typical mandala** |

### 8.2 Browser Compatibility

| Browser | Minimum Version | Tested |
|---------|----------------|--------|
| Chrome | 90+ | ✅ |
| Firefox | 88+ | ✅ |
| Safari | 14+ | ✅ |
| Edge | 90+ | ✅ |

### 8.3 Memory Usage

| Operation | Peak Memory |
|-----------|---------------|
| Load 10MB SVG | ~50MB |
| Process 5,000 paths | ~100MB |
| Simulate 10,000 segments | ~30MB |
| **Total** | **< 200MB** |

---

## 9. TESTING PROTOCOL

### 9.1 Unit Tests

```javascript
// Kerf calculation
describe('KerfEngine', () => {
  test('calculates half-kerf correctly', () => {
    const result = calculateKerf(50, 49.84, 1);
    expect(result.fullKerf).toBe(0.16);
    expect(result.halfKerf).toBe(0.08);
  });

  test('applies tight fit bias', () => {
    const result = calculateKerf(50, 49.84, 1, 'tight');
    expect(result.offset).toBeCloseTo(0.0864, 4);
  });
});

// Path simplification
describe('PathSimplifier', () => {
  test('reduces nodes within tolerance', () => {
    const original = generateCircle(100, 0.01); // 628 nodes
    const simplified = simplifyPath(original, 0.1);
    expect(simplified.length).toBeLessThan(original.length);
    expect(maxDeviation(original, simplified)).toBeLessThan(0.1);
  });
});

// GCode generation
describe('GCodeGenerator', () => {
  test('produces valid GRBL', () => {
    const gcode = generateGCode(paths, grblProfile);
    expect(gcode).toContain('G21');
    expect(gcode).toContain('M4');
    expect(gcode).toContain('M5');
  });
});
```

### 9.2 Integration Tests

**Test Case 1: Full Workflow**
1. Load 7-layer mandala SVG
2. Apply kerf offset for 3mm Baltic Birch
3. Optimize paths (inner-first)
4. Generate GCode for GRBL
5. Verify: No errors, valid commands, time estimate reasonable

**Test Case 2: Round-Trip**
1. Export kerf-adjusted SVG
2. Re-import into tool
3. Verify dimensions match original design intent

**Test Case 3: Cross-Machine**
1. Same SVG → GRBL GCode
2. Same SVG → Marlin GCode
3. Verify: Different M-codes, same geometry

### 9.3 User Acceptance Criteria

**Calibration Workflow:**
- [ ] User can generate test pattern in < 3 clicks
- [ ] Measurement input is clear and validated
- [ ] Calculated kerf is displayed with confidence interval
- [ ] Profile saves and persists across sessions

**Processing Workflow:**
- [ ] SVG loads and displays in < 2 seconds
- [ ] Kerf offset preview updates in real-time
- [ ] GCode exports and runs on target machine
- [ ] Output dimensions match design intent within 0.1mm

**Visualization:**
- [ ] All three views render correctly
- [ ] Simulation plays smoothly at 1x speed
- [ ] Layer toggles work without artifacts
- [ ] Zoom/pan responsive on 4K display

---

## 10. DEPLOYMENT CHECKLIST

### 10.1 Pre-Launch

- [ ] All unit tests passing
- [ ] Integration tests passing
- [ ] Performance benchmarks met
- [ ] Browser compatibility verified
- [ ] Accessibility audit (WCAG 2.1 AA)
- [ ] Security review (no XSS, CSRF vulnerabilities)
- [ ] Analytics implemented (privacy-respecting)

### 10.2 Launch

- [ ] Deploy to Vercel/Netlify
- [ ] Configure custom domain
- [ ] Set up SSL certificate
- [ ] Test on mobile devices
- [ ] Verify download functionality
- [ ] Check email delivery (if applicable)

### 10.3 Post-Launch

- [ ] Monitor error rates (Sentry)
- [ ] Track usage analytics
- [ ] Collect user feedback
- [ ] Plan first update cycle
- [ ] Document known issues

---

## APPENDIX A: SVG PATH PARSING REFERENCE

### Supported SVG Elements

| Element | Parse Method | Notes |
|---------|-------------|-------|
| `<path>` | Direct | Full d attribute support |
| `<circle>` | Convert to path | Arc approximation |
| `<rect>` | Convert to path | Rounded corners supported |
| `<ellipse>` | Convert to path | Arc approximation |
| `<line>` | Convert to path | Simple lineTo |
| `<polyline>` | Convert to path | Multiple lineTo |
| `<polygon>` | Convert to path | Close path automatically |

### Path Commands

| Command | Support | Notes |
|---------|---------|-------|
| M/m | ✅ | Move to |
| L/l | ✅ | Line to |
| H/h | ✅ | Horizontal line |
| V/v | ✅ | Vertical line |
| C/c | ✅ | Cubic Bezier |
| S/s | ✅ | Smooth cubic |
| Q/q | ✅ | Quadratic Bezier |
| T/t | ✅ | Smooth quadratic |
| A/a | ✅ | Arc (convert to curves) |
| Z/z | ✅ | Close path |

---

## APPENDIX B: GCODE COMMAND REFERENCE

### GRBL-Supported Commands

| Command | Description | Usage |
|---------|-------------|-------|
| G0 | Rapid travel | Non-cutting moves |
| G1 | Linear feed | Cutting moves |
| G2 | CW arc | Curved cuts (if supported) |
| G3 | CCW arc | Curved cuts (if supported) |
| G20 | Inches | Unit setting |
| G21 | Millimeters | Unit setting (default) |
| G90 | Absolute | Position mode (default) |
| G91 | Relative | Position mode |
| M3 | Spindle CW | Laser on (continuous) |
| M4 | Spindle CCW | Laser on (PWM) |
| M5 | Spindle off | Laser off |
| Sxxx | Power | 0-1000 for PWM |
| Fxxx | Feed rate | mm/min |

---

*Document Version: 1.0*
*Last Updated: June 2026*
*Status: Ready for Development*

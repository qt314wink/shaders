# RITUAL GEOMETRY: COMPLETE PRODUCTIZATION BLUEPRINT
## From Research Assets to Launch-Ready Digital Product

---

## EXECUTIVE SUMMARY

This document transforms 22+ research and development files into a cohesive, launch-ready digital product system. The Ritual Geometry ecosystem consists of:

- **8 Course Modules** (Materials, Assembly, Finishing, Pricing, etc.)
- **4 Asset Classes** (Coloring Pages, Stencils, Wayfinders, Remix Prompts)
- **1 Interactive Tool** (Mandala Machine Tool: SVG→GCode converter)
- **3 Pricing Tiers** ($97 / $197 / $497)
- **Complete Gumroad Launch Infrastructure**

---

## 1. PRODUCT ARCHITECTURE FINALIZATION

### 1.1 Module Inventory (Complete)

| Module | Title | Status | Word Count | Key Value |
|--------|-------|--------|------------|-----------|
| M1 | LightBurn Settings for Multi-Layer Mandalas | ✅ Complete | ~3,500 | Kerf offset, cut optimization, layer ordering |
| M2 | TurtleToy Code for Generative SVGs | ✅ Complete | ~4,200 | Parametric mandala generation, noise-based organic patterns |
| M3 | Materials & Thicknesses (5-11 Layers) | ✅ Complete | ~12,000 | Baltic Birch, MDF, regenerative materials, cost analysis |
| M4 | Expanded Materials (Metal, Leather, Fabric, Stone) | ✅ Complete | ~11,000 | Mixed-media strategies, CerMark, veg-tan leather, cork |
| M5 | Assembly Techniques | ✅ Complete | ~15,000 | Spacers, adhesives, alignment, mounting hardware |
| M6 | Surface Treatment & Finishing | ✅ Complete | ~4,500 | 6 finish codes (NAT, GOL, BLK, COL, CHR, WHT) |
| M7 | Pricing, Packaging & Sales Copy | ✅ Complete | ~4,000 | Gumroad-ready copy, tier architecture, freebie strategy |
| M8 | Bonus Atelier | ✅ Outlined | ~2,000 | Coloring pages, stencils, remix prompts, slide decks |

**Total Curriculum: ~56,200 words of authoritative content**

### 1.2 Asset Class Inventory

| Asset Type | Quantity | Format | SKU Pattern | Example |
|------------|----------|--------|-------------|---------|
| Coloring Pages | 20 prompts | PDF/SVG | RG-SF-CP-20P-DL-ATL | Quiet Bloom, Burning Lattice |
| Stencils | 8 prompts | SVG | RG-SF-SM-08S-DL-ATL | Bloom Outline, Lattice Ring |
| Wayfinders | 8 prompts | PDF | RG-SF-WF-08G-DL-ATL | 12-Segment Radial Guide |
| Remix Prompts | 50 cards | PDF/Print | RG-SF-RP-50N-DL-ATL | The Inversion, The Silence |
| Slide Decks | 6+ sets | PDF/Keynote | RG-SF-SD-06D-DL-ATL | Process visuals, finish swatches |

### 1.3 The Mandala Machine Tool (Interactive Product)

**Current State:** HTML/CSS/JS prototype with:
- SVG import and parsing
- Kerf calibration (single-square method)
- Machine profile JSON schema
- Per-layer settings table
- Live preview with 3 synchronized views
- GCode export for GRBL

**Required Enhancements for Productization:**

```
PRIORITY 1: Core Functionality
├── Multi-rectangle kerf test pattern generator
├── Vernier/jig-style calibration test file
├── Curved path handling (arc preservation vs flattening)
├── Path optimization (nearest-neighbor reordering)
├── Node simplification with deviation tolerance
└── Machine profile import/export (JSON)

PRIORITY 2: Product Polish
├── Dark/light theme toggle (partially implemented)
├── Responsive layout for mobile/tablet
├── Undo/redo for calibration changes
├── Calibration history log
├── Warning system for out-of-bounds geometry
└── Dry-run mode (travel-only preview)

PRIORITY 3: Advanced Features
├── Material preset library (Baltic Birch 3mm, MDF 3mm, Acrylic 3mm)
├── Layer-aware SVG grouping for LightBurn import
├── Kerf-adjusted SVG export (for LightBurn/CAM tools)
├── Batch processing for multiple files
├── Time estimation with acceleration curves
└── Integration with TurtleToy parametric generator
```

---

## 2. PRICING & POSITIONING ARCHITECTURE

### 2.1 Tier Structure (Finalized)

| Tier | Name | Price | Target | Includes |
|------|------|-------|--------|----------|
| **Free** | The Spark | $0 | Curious browsers | 1 coloring page + 1 stencil + 1 remix prompt |
| **Entry** | The Forge | $97 | Serious makers | Core course (M1-M7) + Engine + 10 coloring pages + 5 stencils + finish swatches |
| **Deluxe** | The Atelier | $197 | Product builders | Everything above + full 20+ coloring library + complete stencil masters + 50 remix prompts + slide deck + image library + commercial license |
| **Studio** | The Foundry | $497 | Design studios | Everything above + source code + customization guide + unlimited commercial rights + priority requests |

**Gumroad Math:**
- Atelier tier at $197: Gumroad takes 10% + processing = ~$177 net per sale
- Target: 20 sales/month = $3,540 monthly revenue
- Break-even: ~5 sales/month covers tool development costs

### 2.2 Positioning Statement (Final)

> **Ritual Geometry** is not a craft kit, a template pack, or a course. It is a parametric design system that turns frequency, amplitude, and rotation into physical objects with presence. The Mandala Engine generates infinite compositions. The course teaches you to finish them like gallery pieces. The assets give you starting points, stencils, and remix fuel. The result is a practice — not a purchase.

### 2.3 Sales Page Copy (Gumroad-Ready)

**Title:** Ritual Geometry: The Complete Mandala System

**Subtitle:** *Cut, color, and remix. A visual practice for making layered mandalas that hold attention.*

**Long Description:**
This is not a craft kit. It is an art system.

Ritual Geometry is a maker's field guide for creating layered mandalas that look authored rather than assembled. It brings together the structure of the computer, the warmth of physical materials, and the endless remix potential of a digital library.

**Why this matters:**
Most mandala templates are static downloads. This is a design language. When you learn the system, you aren't just cutting shapes—you're learning how to control depth, finish with intention, and create objects that feel collected, not manufactured.

**What's inside (The Deluxe Bundle):**
- The Ritual Geometry Course: 8 modules covering design, cutting, assembly, finishing, and selling
- The Mandala Machine Tool: Browser-based SVG→GCode converter with kerf calibration
- The Bonus Atelier:
  - Printable Coloring Library: 20+ mandala line art pages
  - Stencil Master Sheets: 8 precision-cut line work sheets
  - Remix Prompt Deck: 50 creative transformation cards
  - Atelier Image & Slide Pack: High-fidelity visual decks

**The transformation:**
Whether you are a maker looking for a new product line, an artist wanting to master radial symmetry, or a creative technologist building generative visuals, this system gives you the geometry and the workflow to produce work that glows.

---

## 3. TECHNICAL IMPLEMENTATION ROADMAP

### 3.1 Mandala Machine Tool: Development Phases

**PHASE 1: Foundation (Week 1-2)**
- [ ] Implement multi-rectangle kerf test pattern generator
- [ ] Add Vernier-style calibration jig
- [ ] Build calibration history database (localStorage)
- [ ] Create material preset library (Baltic Birch, MDF, Acrylic, Cork, Bamboo)
- [ ] Add per-material kerf lookup tables

**PHASE 2: Geometry Engine (Week 3-4)**
- [ ] Implement path simplification (Douglas-Peucker algorithm)
- [ ] Add curve flattening with tolerance control
- [ ] Build arc detection and G2/G3 emission
- [ ] Create nearest-neighbor path reordering
- [ ] Add inner-cuts-first optimization

**PHASE 3: Visualization (Week 5-6)**
- [ ] Implement live simulation with time slider
- [ ] Add head position tracking with animation
- [ ] Create travel move visualization (rapid vs cut)
- [ ] Build layer toggle controls
- [ ] Add bounds checking with visual warnings

**PHASE 4: Export & Integration (Week 7-8)**
- [ ] Implement kerf-adjusted SVG export
- [ ] Add DXF export option
- [ ] Create machine-specific GCode post-processors
- [ ] Build LightBurn-compatible layer color coding
- [ ] Add batch processing for multiple files

### 3.2 Hosting & Deployment

**Recommended Stack:**
- **Frontend:** Static HTML/CSS/JS (no build step required)
- **Hosting:** Vercel or Netlify (free tier sufficient)
- **Domain:** ritualgeometry.io or similar
- **Backend:** None required for MVP (localStorage for profiles)
- **Future:** Supabase for user submissions and shared presets

**Deployment Checklist:**
- [ ] Set up GitHub repository
- [ ] Configure Vercel deployment
- [ ] Add custom domain
- [ ] Implement basic analytics (Plausible or Fathom)
- [ ] Set up error tracking (Sentry)

### 3.3 Gumroad Integration

**Product Setup:**
- [ ] Create Gumroad account with custom URL
- [ ] Set up 3 product variants (Forge/Atelier/Foundry)
- [ ] Upload deliverables with Codex naming convention
- [ ] Configure license keys for Studio tier
- [ ] Set up email automation for post-purchase

---

## 4. ASSET PRODUCTION WORKFLOW

### 4.1 Prompt-to-Asset Pipeline

**Step 1: Generate Base Images (AI-assisted)**
```
Input: Coloring page prompt (e.g., "Quiet Bloom")
Tool: Midjourney/Stable Diffusion/DALL-E
Output: 20 base mandala images
Settings: --ar 3:4 --style raw --v 6
```

**Step 2: Vectorize and Clean**
```
Input: Raster mandala images
Tool: Vectorizer.AI or Adobe Illustrator
Output: Clean SVG paths
Action: Remove overlaps, close paths, simplify nodes
```

**Step 3: Create Asset Variants**
```
Input: Master SVG
Tool: Inkscape/Illustrator + custom scripts
Output: 
  - Coloring page (medium detail, open spaces)
  - Stencil (bold lines, wide bridges, large voids)
  - Wayfinder (faint lines, construction marks)
```

**Step 4: Apply Naming Convention**
```
Example: RG_QuietBloom_07L_NAT_v01.svg
Breakdown: RG (brand) + QuietBloom (geometry) + 07L (7 layers) + NAT (natural finish) + v01 (version)
```

### 4.2 Remix Prompt Deck Production

**Card Specifications:**
- Size: 2.75" x 4.75" (poker card size)
- Format: PDF for print, PNG for digital
- Front: Prompt name + visual example
- Back: Detailed instruction + parameter suggestions

**Card Design System:**
- Typography: Satoshi (matches Machine Tool UI)
- Color coding by category:
  - Transformation (red): Invert, compress, expand
  - Geometry (blue): Replace circles, add grids
  - Texture (green): Woven, carved, weather
  - Composition (purple): Threshold, halo, drift

### 4.3 Slide Deck Production

**Deck Structure (6 decks):**
1. **Process Overview:** From code to sculpture
2. **Material Guide:** The Core Three + Regenerative options
3. **Finish Swatches:** 6 finish codes with visual examples
4. **Assembly Workflow:** Step-by-step with photos
5. **Pricing Architecture:** Tier breakdown and margins
6. **Marketing Kit:** Social media templates and copy

---

## 5. LAUNCH STRATEGY

### 5.1 Pre-Launch (2 weeks before)

**Content Calendar:**
- Week 2: Teaser images (hero mandala + Engine interface)
- Week 1: Process videos (time-lapse of cutting/finishing)
- Day 3: Free sampler release (1 coloring page)
- Day 1: Launch announcement with early-bird pricing

**Email Sequence:**
1. **Announcement:** "The system is almost ready"
2. **Reminder:** "24 hours left for early-bird pricing"
3. **Last Chance:** "Final hours + what's inside"

### 5.2 Launch Day

**Checklist:**
- [ ] Publish Gumroad page
- [ ] Send to email list
- [ ] Post on Instagram/Twitter/LinkedIn
- [ ] Share in relevant communities (r/lasercutting, r/woodworking)
- [ ] Monitor first 48 hours for questions
- [ ] Collect testimonials from first buyers

### 5.3 Post-Launch Optimization

**Month 1:**
- A/B test Gumroad copy after 10 sales
- Gather feedback on Machine Tool UX
- Create FAQ document from common questions

**Month 2-3:**
- Release first update (new coloring pages)
- Consider affiliate program
- Plan seasonal edition (e.g., "The Burning Season")

---

## 6. QUALITY ASSURANCE FRAMEWORK

### 6.1 QA Checklist (From Existing Document)

**Input Validation:**
- [ ] SVG loads and resolves to paths
- [ ] Text/strokes converted to paths
- [ ] No open paths where closed required
- [ ] ViewBox interpreted correctly

**Kerf Calibration:**
- [ ] Test pattern generator works
- [ ] Measurement input form validates
- [ ] Half-kerf logic applied correctly
- [ ] UI indicates missing/outdated profiles

**Per-Layer Settings:**
- [ ] Each layer assignable material/thickness/feed/power
- [ ] Default presets for common materials
- [ ] Layer summary shows total depth
- [ ] Order changes update simulation

**SVG→GCode Mapping:**
- [ ] Respects machine profile limits
- [ ] Travel moves use G0, cuts use G1
- [ ] Arcs emitted as G2/G3 or flattened
- [ ] Toolpaths continuous where expected

**Path Optimization:**
- [ ] Simplification respects deviation threshold
- [ ] Cut order minimizes travel
- [ ] Inner cuts before outer frames
- [ ] Engrave separated from through-cuts

**Visualization:**
- [ ] 1:1 overlay on original geometry
- [ ] Simulation shows head position
- [ ] Bounds fit within machine bed
- [ ] Zoom/pan for intricate regions

**Export:**
- [ ] GCode compatible with GRBL
- [ ] Kerf-adjusted SVG exportable
- [ ] Machine profiles import/export as JSON

**Safety:**
- [ ] Dry-run mode available
- [ ] Warnings for out-of-bounds
- [ ] Clear labeling for operations

### 6.2 Testing Protocol

**Unit Tests:**
- Kerf calculation: (designed - measured) / 2 = correct offset
- Path simplification: simplified path within tolerance of original
- GCode generation: valid GRBL commands, no unsupported codes

**Integration Tests:**
- Full workflow: SVG import → kerf apply → optimize → export → verify
- Cross-machine: Same SVG produces different GCode for different profiles
- Round-trip: Export kerf-adjusted SVG, re-import, verify dimensions

**User Testing:**
- 5 laser operators test calibration workflow
- 3 educators test course module clarity
- 10 artists test coloring page quality

---

## 7. BUSINESS OPERATIONS

### 7.1 SKU Management

**Master SKU Database:**
```csv
SKU,Product Name,Tier,Price,Files Included,Status
RG-SF-CP-20P-DL-ATL,Sacred Fire Coloring Pack 20pg,Atelier,197,20 PDFs,Active
RG-SF-SM-08S-DL-ATL,Sacred Fire Stencil Masters 8,Atelier,197,8 SVGs,Active
RG-SF-RP-50N-DL-ATL,50 Remix Prompt Deck,Atelier,197,50 PDFs,Active
RG-ENG-CORE-001-FRG,Mandala Engine,Forge,97,1 HTML,Active
RG-CRS-FULL-001-FRG,Complete Course,Forge,97,8 PDFs,Active
```

### 7.2 Customer Support Framework

**Support Tiers:**
- **Self-Service:** FAQ, documentation, video tutorials
- **Community:** Discord/Slack channel for peer support
- **Direct:** Email support for technical issues
- **Priority:** Studio tier gets 24-hour response guarantee

**Common Issues & Solutions:**
1. "My kerf calibration seems off" → Link to calibration video, suggest re-testing
2. "GCode won't run on my machine" → Check machine profile, verify controller type
3. "How do I get the commercial license?" → Upsell to Atelier tier
4. "Can I use this with my Cricut?" → Explain SVG compatibility, suggest test cut

### 7.3 Analytics & Optimization

**Key Metrics:**
- Conversion rate (visitors → sales)
- Tier distribution (% Forge vs Atelier vs Foundry)
- Tool usage (calibration runs, exports, simulations)
- Asset downloads (which coloring pages are most popular)
- Support ticket volume and resolution time

**Optimization Cycle:**
1. Monthly: Review analytics, identify bottlenecks
2. Quarterly: A/B test pricing/copy, release new assets
3. Annually: Major version update, new module addition

---

## 8. RISK MITIGATION

### 8.1 Technical Risks

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Kerf calculation inaccurate | Medium | High | Multiple test methods, calibration history, user feedback |
| GCode incompatible with machine | Medium | High | Machine profile validation, dry-run mode, community testing |
| Browser compatibility issues | Low | Medium | Test on Chrome/Firefox/Safari, progressive enhancement |
| Performance with large SVGs | Medium | Medium | Path simplification, web workers for processing |

### 8.2 Business Risks

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Low initial sales | Medium | High | Free sampler, email list building, content marketing |
| Competitor undercutting | High | Medium | Premium positioning, system differentiation, community |
| Gumroad fee changes | Low | Medium | Diversify to own store, build email list |
| Copyright disputes | Low | High | Clear licensing, original content, trademark protection |

### 8.3 Content Risks

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Prompt quality inconsistent | Medium | Medium | Style guide, review process, community feedback |
| Module accuracy questioned | Low | High | Cite sources, expert review, update cycle |
| Cultural appropriation concerns | Medium | Medium | Respectful framing, diverse influences, attribution |

---

## 9. APPENDICES

### 9.1 File Naming Convention (Quick Reference)

| Element | Format | Example |
|---------|--------|---------|
| Tier | The [Space] | The Atelier |
| File | RG_[Form]_[Layer]_[Finish]_v## | RG_Bloom_07L_NAT_v01.zip |
| Mandala | [Quality] [Form], [Edition] | The Quiet Bloom, One of One |
| Collection | The [Theme] Season | The Burning Season |
| Colorway | The [Finish] [Form] | The Gilded Bloom |
| Module | RG_M##_[Title]_[Format] | RG_M05_Assembly_WS.pdf |
| Stencil | RG_[Form]_[Type]_[Size] | RG_Bloom_OUT_12in.svg |
| Prompt | The [Move] | The Inversion |
| SKU | RG-[S]-[G]-[L]-[F]-[T] | RG-SF-BL-07L-NAT-FGE |

### 9.2 Forbidden Words List

Never use in customer-facing names:
- Pack, Bundle, Kit, Template
- v3, FINAL, updated, New
- Basic, Standard, Pro, Premium
- Cheap, Affordable, Budget
- File, Download, Digital

### 9.3 Machine Profile JSON Schema

```json
{
  "schemaVersion": "0.1.0",
  "machine": {
    "name": "GRBL Diode Laser",
    "controller": "GRBL",
    "bed": { "widthMm": 400, "heightMm": 400 },
    "origin": "front-left",
    "units": "mm",
    "maxFeedMmMin": 6000,
    "maxAccelMmS2": 1500,
    "supportsArcs": true,
    "modes": ["cut", "score", "engrave", "travel"],
    "safeguards": {
      "boundsCheck": true,
      "dryRunPreview": true,
      "requireKerfProfile": true
    }
  },
  "calibration": {
    "activeMaterial": "Birch plywood",
    "thicknessMm": 3,
    "fullKerfMm": 0.16,
    "contourOffsetMm": 0.08,
    "fitMode": "tight"
  },
  "curvedCutpaths": {
    "curveToleranceMm": 0.10,
    "minArcRadiusMm": 0.60,
    "preserveArcsWhenSupported": true,
    "cornerSlowdownFactor": 0.72
  }
}
```

### 9.4 Glossary of Terms

| Term | Definition |
|------|------------|
| **Kerf** | Width of material removed by laser beam |
| **Kerf Offset** | Half-kerf value applied to design path for dimensional accuracy |
| **GCode** | Machine control language (G0=travel, G1=cut, G2/G3=arcs) |
| **LightBurn** | Popular laser control software |
| **TurtleToy** | Browser-based generative art platform |
| **Simplex Noise** | Algorithm for organic, non-repeating patterns |
| **Vesica Piscis** | Sacred geometry shape formed by intersecting circles |
| **French Cleat** | Professional wall mounting system |

---

## 10. NEXT ACTIONS (Priority Order)

### Immediate (This Week)
1. [ ] Export Mandala Machine Tool from current environment to GitHub
2. [ ] Set up Vercel deployment pipeline
3. [ ] Create Gumroad account and custom URL
4. [ ] Generate first 5 coloring page assets from prompts
5. [ ] Write email capture landing page

### Short-term (Next 2 Weeks)
6. [ ] Implement multi-rectangle kerf test in Machine Tool
7. [ ] Add material preset library
8. [ ] Create 3 product variants in Gumroad
9. [ ] Design slide deck templates
10. [ ] Set up email automation sequence

### Medium-term (Next Month)
11. [ ] User testing with 5 laser operators
12. [ ] A/B test Gumroad page copy
13. [ ] Launch free sampler to email list
14. [ ] Create first seasonal collection ("The Burning Season")
15. [ ] Begin affiliate program outreach

### Long-term (3-6 Months)
16. [ ] Release Machine Tool v2 with advanced features
17. [ ] Add new module (Module 9: Advanced Generative Techniques)
18. [ ] Expand to physical product line (pre-made mandalas)
19. [ ] Build community platform (Discord/forum)
20. [ ] Consider YouTube channel for process documentation

---

*Document Version: 1.0*
*Generated: June 2026*
*Status: Ready for Implementation*

# RITUAL GEOMETRY: ASSET PRODUCTION PIPELINE
## From Prompts to Launch-Ready Products

---

## 1. ASSET INVENTORY OVERVIEW

### 1.1 Complete Asset List

| # | Asset Type | Quantity | Format | Status | Priority |
|---|-----------|----------|--------|--------|----------|
| 1 | Coloring Pages | 20 | PDF/SVG | Prompts ready | HIGH |
| 2 | Stencils | 8 | SVG | Prompts ready | HIGH |
| 3 | Wayfinders | 8 | PDF | Prompts ready | MEDIUM |
| 4 | Remix Prompts | 50 | PDF/Print | Prompts ready | HIGH |
| 5 | Slide Decks | 6 | PDF/Keynote | Outlined | MEDIUM |
| 6 | Finish Swatches | 6 | PDF/PNG | Defined | MEDIUM |
| 7 | Machine Tool | 1 | HTML/JS | Prototype | HIGH |
| 8 | Course Modules | 8 | PDF | Complete | HIGH |
| 9 | Gumroad Page | 1 | HTML | Copy ready | HIGH |
| 10 | Email Sequence | 3 | Text | Outlined | MEDIUM |

### 1.2 Asset Families (Cross-Product Consistency)

**Family 1: Quiet Bloom**
- Coloring Page: Intricate radial mandala, petal structures
- Stencil: Bold radial flower, wide bridges
- Wayfinder: 12-segment radial guide
- Remix Prompts: "Invert the center", "Add a halo ring"

**Family 2: Burning Lattice**
- Coloring Page: Interlocking lattice rings, flame-like segments
- Stencil: Circular lattice, evenly spaced openings
- Wayfinder: 8-petal construction guide
- Remix Prompts: "Double the outer rhythm", "Convert to flame"

**Family 3: Deep Well**
- Coloring Page: Concentric circular wells, repeating arches
- Stencil: Coil arcs, spiral bands
- Wayfinder: Mandala layer registration sheet
- Remix Prompts: "Widen the silence between rings"

**Family 4: Golden Coil**
- Coloring Page: Spiral-inflected radial mandala
- Stencil: Radiance burst, thick spokes
- Wayfinder: Centerfinding rosette guide
- Remix Prompts: "Compress the center, loosen the edge"

**Family 5: Radiant Gate**
- Coloring Page: Nested gates, arcs, threshold shapes
- Stencil: Gate pattern, repeating arch forms
- Wayfinder: Compass mandala draft grid
- Remix Prompts: "Turn petals into gates"

**Family 6: Vesica Field**
- Coloring Page: Layered vesica piscis geometry
- Stencil: Vesica grid, overlapping shapes
- Wayfinder: Vesica construction wheel
- Remix Prompts: "Replace circles with vesicas"

---

## 2. PRODUCTION WORKFLOW

### 2.1 Phase 1: Base Image Generation (AI-Assisted)

**Tools:**
- Primary: Midjourney v6 / Stable Diffusion XL / DALL-E 3
- Secondary: Adobe Firefly (for vector-ready outputs)
- Tertiary: Runway ML (for variations)

**Prompt Template Structure:**
```
[Subject] + [Style] + [Technical Specs] + [Quality Boosters]

Example:
"Quiet Bloom mandala, intricate radial symmetry, clean black vector line art 
on white background, centered composition, printable page layout, no shading, 
no gradients, SVG-friendly, museum-grade geometric composition, 
calm negative space, precise line hierarchy --ar 3:4 --style raw --v 6"
```

**Batch Generation Strategy:**
1. Generate 5 variations per prompt
2. Select best 2 for refinement
3. Vectorize top choice
4. Archive alternatives for future use

**Quality Control Checklist:**
- [ ] Clean black lines on white background
- [ ] No gradients or shading
- [ ] Centered composition
- [ ] Adequate negative space for coloring
- [ ] Symmetrical where intended
- [ ] No photorealistic elements
- [ ] SVG-friendly (no tiny details)

### 2.2 Phase 2: Vectorization & Cleanup

**Tools:**
- Vectorizer.AI (automated, high quality)
- Adobe Illustrator (manual refinement)
- Inkscape (open-source alternative)
- Figma (collaborative editing)

**Vectorization Process:**
```
1. Upload raster image to Vectorizer.AI
2. Select "High Quality" preset
3. Download SVG
4. Open in Illustrator/Inkscape
5. Clean up:
   - Remove stray nodes
   - Close open paths
   - Simplify complex curves
   - Unify line weights
6. Verify path count (< 5,000 nodes for performance)
7. Export clean SVG
```

**Cleanup Rules:**
- Minimum line weight: 0.5pt (for coloring pages)
- Minimum line weight: 1.5pt (for stencils)
- Minimum gap between lines: 2mm (for stencils)
- Bridge width: minimum 3mm (for stencils)
- All paths must be closed for cutting

### 2.3 Phase 3: Asset Variant Creation

**From Master SVG to Variants:**

```
Master SVG (detailed, medium weight)
    ├── Coloring Page: Medium detail, open spaces, 0.75pt lines
    ├── Stencil: Bold lines, wide bridges, 1.5pt lines, simplified interior
    └── Wayfinder: Faint lines, construction marks, 0.5pt lines, guides
```

**Coloring Page Specifics:**
- Line weight: 0.75pt - 1pt
- Detail level: Medium (not too dense)
- Open areas: 30-40% of page for coloring
- Complexity: Suitable for ages 8+
- Format: PDF (print-ready) + SVG (scalable)

**Stencil Specifics:**
- Line weight: 1.5pt - 2pt
- Bridge width: minimum 3mm
- Void size: large enough for paint/pencil
- Fragile details: removed or reinforced
- Format: SVG (cut-ready)

**Wayfinder Specifics:**
- Line weight: 0.5pt - 0.75pt
- Faint appearance: 30-50% opacity
- Construction marks: crosshairs, rings, ticks
- Educational labels: minimal, unobtrusive
- Format: PDF (print-ready)

### 2.4 Phase 4: Remix Prompt Card Design

**Card Specifications:**
```
Physical:
- Size: 2.75" x 4.75" (70mm x 121mm)
- Paper: 300gsm matte cardstock
- Finish: Soft-touch lamination
- Rounded corners: 3mm radius

Digital:
- Format: PDF (print-ready) + PNG (digital use)
- Resolution: 300 DPI
- Color space: CMYK (print) / RGB (digital)
```

**Card Layout:**
```
┌─────────────────────────────┐
│  [Icon]  THE INVERSION      │ ← Title (bold, uppercase)
│                              │
│  "Invert the center."        │ ← Prompt (italic, readable)
│                              │
│  [Visual Example]           │ ← Small mandala showing effect
│                              │
│  Parameters:                │ ← Technical suggestions
│  • Center radius: ×0.5      │
│  • Ring density: reverse    │
│  • Symmetry: maintain       │
│                              │
│  [Category Color Bar]       │ ← Color-coded by type
└─────────────────────────────┘
```

**Category Color Coding:**
- Transformation (red): #D163A7 — Invert, compress, expand, drift
- Geometry (blue): #4F98A3 — Replace, add grids, compass, rose-window
- Texture (green): #6DAA45 — Woven, carved, weather, stone
- Composition (purple): #A12C7B — Threshold, halo, silence, disturbance

### 2.5 Phase 5: Slide Deck Production

**Deck 1: Process Overview**
```
Slide 1: Title — "From Code to Sculpture"
Slide 2: The Parametric Engine — Screenshot of TurtleToy interface
Slide 3: SVG Generation — Clean vector paths
Slide 4: Machine Tool — Kerf calibration interface
Slide 5: Physical Output — 7-layer mandala photo
Slide 6: Finishing — Oil finish application
Slide 7: Gallery Ready — Mounted mandala on wall
Slide 8: The System — Diagram showing full workflow
```

**Deck 2: Material Guide**
```
Slide 1: The Core Three — Baltic Birch, MDF, Basswood
Slide 2: Baltic Birch — Specs, laser settings, cost
Slide 3: MDF — Specs, laser settings, when to use
Slide 4: Regenerative Materials — FSC, reclaimed, bamboo, cork
Slide 5: Acrylic — Protective top layer strategy
Slide 6: Mixed Media — Metal, leather, felt combinations
Slide 7: Thickness Strategy — 5-7-9-11 layer formulas
Slide 8: Sourcing Guide — Suppliers and pricing
```

**Deck 3: Finish Swatches**
```
Slide 1: The Six Finishes — Grid overview
Slide 2: NAT — Natural/Oil (warm, honest)
Slide 3: GOL — Gold Edge (ceremonial, luminous)
Slide 4: BLK — Black Edge (stark, architectural)
Slide 5: COL — Full Color (vibrant, pop)
Slide 6: CHR — Charred Edge (wabi-sabi, elemental)
Slide 7: WHT — White Face (clean, gallery-ready)
Slide 8: Selector Guide — Decision tree
```

**Deck 4: Assembly Workflow**
```
Slide 1: Tools Needed — Spacers, adhesives, clamps
Slide 2: Spacer Placement — Strategic diagram
Slide 3: Adhesive Selection — Titebond, CA, epoxy
Slide 4: Alignment Techniques — Dowel, registration, visual
Slide 5: Edge Finishing — Sand, paint, char
Slide 6: Mounting Hardware — Keyhole, wire, French cleat
Slide 7: Quality Control — Checklist
Slide 8: Packaging — Professional presentation
```

**Deck 5: Pricing Architecture**
```
Slide 1: Price as Position — Philosophy
Slide 2: Cost Breakdown — Materials, labor, overhead
Slide 3: Tier Structure — Spark/Forge/Atelier/Foundry
Slide 4: Market Analysis — Etsy comparables
Slide 5: Profit Margins — Per tier calculation
Slide 6: Licensing — Personal vs commercial
Slide 7: Upsell Strategy — From coloring to studio
Slide 8: Long-term Value — Community and updates
```

**Deck 6: Marketing Kit**
```
Slide 1: Brand Identity — Logo, colors, typography
Slide 2: Hero Image — Product photography
Slide 3: Social Templates — Instagram, Pinterest
Slide 4: Email Templates — Announcement, reminder, last chance
Slide 5: Testimonial Framework — Request and display
Slide 6: Affiliate Materials — Banners, copy, links
Slide 7: PR Kit — Press release, bio, photos
Slide 8: Launch Timeline — Week-by-week plan
```

---

## 3. NAMING & ORGANIZATION

### 3.1 File Naming Convention

```
[Brand]_[Geometry]_[Layer]_[Finish]_[Version]_[AssetType]

Examples:
RG_QuietBloom_07L_NAT_v01_COLORING.pdf
RG_BurningLattice_05L_GOL_v01_STENCIL.svg
RG_DeepWell_09L_BLK_v01_WAYFINDER.pdf
RG_GoldenCoil_07L_COL_v01_REMIX.pdf
```

### 3.2 Folder Structure

```
/RitualGeometry/
├── /assets/
│   ├── /coloring/
│   │   ├── /source/           # Master SVGs
│   │   ├── /print/            # PDF versions
│   │   └── /preview/          # PNG thumbnails
│   ├── /stencils/
│   │   ├── /source/           # Master SVGs
│   │   ├── /cut-ready/        # Optimized SVGs
│   │   └── /preview/          # PNG thumbnails
│   ├── /wayfinders/
│   │   ├── /source/           # Master SVGs
│   │   ├── /print/            # PDF versions
│   │   └── /preview/          # PNG thumbnails
│   ├── /remix/
│   │   ├── /cards/            # Individual PDFs
│   │   ├── /deck/             # Complete deck PDF
│   │   └── /digital/          # PNG versions
│   └── /slides/
│       ├── /process/
│       ├── /materials/
│       ├── /finishes/
│       ├── /assembly/
│       ├── /pricing/
│       └── /marketing/
├── /course/
│   ├── /modules/              # M1-M8 PDFs
│   ├── /worksheets/           # Practice sheets
│   └── /cheatsheets/          # Quick reference
├── /tool/
│   ├── /source/               # Machine Tool code
│   ├── /build/                # Compiled/bundled
│   └── /docs/                 # Technical documentation
└── /marketing/
    ├── /gumroad/              # Product page assets
    ├── /social/               # Instagram, Twitter, Pinterest
    ├── /email/                # Email templates
    └── /affiliates/           # Partner materials
```

---

## 4. QUALITY ASSURANCE

### 4.1 Pre-Production Checklist

**For Each Asset:**
- [ ] Prompt reviewed against style guide
- [ ] Base image meets quality standards
- [ ] Vectorization clean (no stray nodes)
- [ ] Paths closed where required
- [ ] Line weights appropriate for asset type
- [ ] Negative space adequate
- [ ] Naming convention applied
- [ ] Metadata added (title, description, tags)

### 4.2 Production Checklist

**For Coloring Pages:**
- [ ] Test print on standard printer (8.5x11")
- [ ] Verify lines don't bleed
- [ ] Check centering on page
- [ ] Confirm adequate margins
- [ ] Test with colored pencils and markers

**For Stencils:**
- [ ] Test cut on laser (3mm Baltic Birch)
- [ ] Verify bridges hold (no breakage)
- [ ] Check void size for paint/pencil
- [ ] Confirm registration marks align
- [ ] Test with spray paint and acrylics

**For Wayfinders:**
- [ ] Test print on standard printer
- [ ] Verify faint lines visible but not distracting
- [ ] Check construction marks accuracy
- [ ] Test with pencil tracing
- [ ] Confirm educational value

**For Remix Cards:**
- [ ] Print test on cardstock
- [ ] Verify color accuracy
- [ ] Check text readability
- [ ] Test shuffle durability
- [ ] Confirm prompt clarity

### 4.3 Post-Production Review

**Peer Review Process:**
1. Designer creates asset
2. Second designer reviews for quality
3. Laser operator tests cut files
4. Educator reviews wayfinders for clarity
5. Marketing reviews for brand consistency
6. Final approval before upload

---

## 5. PRODUCTION TIMELINE

### 5.1 Week 1-2: Foundation Assets

**Priority 1: Coloring Pages (5 families)**
- Day 1-2: Generate base images (25 variations)
- Day 3-4: Vectorize and clean (10 selected)
- Day 5-6: Create variants (coloring, stencil, wayfinder)
- Day 7: Quality review and approval

**Priority 2: Remix Prompt Cards (10 cards)**
- Day 1-2: Design card template
- Day 3-4: Create first 10 cards
- Day 5: Print test and review
- Day 6-7: Refine and approve

### 5.2 Week 3-4: Core Assets

**Priority 3: Remaining Coloring Pages (15)**
- Day 1-5: Generate, vectorize, clean
- Day 6-7: Quality review

**Priority 4: Stencils (8)**
- Day 1-3: Create from coloring page masters
- Day 4-5: Test cut on laser
- Day 6-7: Refine and approve

**Priority 5: Wayfinders (8)**
- Day 1-3: Create from stencil masters
- Day 4-5: Test print and trace
- Day 6-7: Refine and approve

### 5.3 Week 5-6: Advanced Assets

**Priority 6: Remix Prompt Cards (40 remaining)**
- Day 1-5: Batch create (8 cards/day)
- Day 6-7: Review and package

**Priority 7: Slide Decks (6)**
- Day 1-3: Design master template
- Day 4-6: Create content for all 6 decks
- Day 7: Review and finalize

### 5.4 Week 7-8: Integration & Launch Prep

**Priority 8: Machine Tool Polish**
- Day 1-3: Implement calibration enhancements
- Day 4-5: Add material presets
- Day 6-7: Performance optimization

**Priority 9: Gumroad Setup**
- Day 1-2: Create product variants
- Day 3-4: Upload all assets
- Day 5-6: Write product descriptions
- Day 7: Test purchase flow

**Priority 10: Marketing Materials**
- Day 1-2: Create social media assets
- Day 3-4: Write email sequences
- Day 5-6: Prepare launch announcement
- Day 7: Final review and schedule

---

## 6. TOOLS & RESOURCES

### 6.1 Design Tools

| Tool | Purpose | Cost | Alternative |
|------|---------|------|-------------|
| Adobe Illustrator | Vector editing | $55/mo | Inkscape (free) |
| Figma | UI design, collaboration | $15/mo | Penpot (free) |
| Vectorizer.AI | Raster to SVG | $0.10/image | Inkscape trace |
| Midjourney | AI image generation | $30/mo | Stable Diffusion (free) |
| Canva | Quick graphics, social | $13/mo | GIMP (free) |

### 6.2 Production Tools

| Tool | Purpose | Cost | Alternative |
|------|---------|------|-------------|
| LightBurn | Laser control | $60 | LaserGRBL (free) |
| Inkscape | SVG editing | Free | Illustrator |
| GitHub | Code repository | Free | GitLab |
| Vercel | Web hosting | Free | Netlify |
| Gumroad | Digital sales | 10% fee | Payhip |

### 6.3 Testing Tools

| Tool | Purpose | Cost |
|------|---------|------|
| BrowserStack | Cross-browser testing | $29/mo |
| Lighthouse | Performance audit | Free |
| WAVE | Accessibility check | Free |
| Sentry | Error tracking | Free tier |

---

## 7. BUDGET ESTIMATE

### 7.1 Development Costs

| Item | Cost | Notes |
|------|------|-------|
| Machine Tool development | $2,000-4,000 | Freelance dev, 40-80 hours |
| Asset generation (AI) | $200-500 | Midjourney credits, vectorization |
| Design software | $500-1,000 | Illustrator, Figma, Canva (1 year) |
| Laser testing | $300-500 | Material costs, machine time |
| Web hosting | $0-200 | Vercel free tier, domain |
| Gumroad fees | Variable | 10% per sale |
| **Total Setup** | **$3,000-6,200** | One-time + first year |

### 7.2 Ongoing Costs

| Item | Monthly | Notes |
|------|---------|-------|
| Software subscriptions | $100-200 | AI tools, design software |
| Web hosting | $0-20 | Vercel/Netlify |
| Email service | $0-50 | ConvertKit/Mailchimp |
| Analytics | $0-20 | Plausible/Fathom |
| **Total Monthly** | **$100-290** | Scales with growth |

### 7.3 Revenue Projections

| Scenario | Monthly Sales | Revenue | Net (after Gumroad) |
|----------|--------------|---------|---------------------|
| Conservative | 10 Atelier | $1,970 | $1,773 |
| Moderate | 20 Atelier | $3,940 | $3,546 |
| Optimistic | 50 mixed | $7,000+ | $6,300+ |

**Break-even:** 5-10 sales/month covers ongoing costs
**ROI Timeline:** 2-3 months to recover setup costs

---

## 8. RISK MANAGEMENT

### 8.1 Production Risks

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| AI generation inconsistent | Medium | Medium | Multiple tools, manual refinement |
| Vectorization quality poor | Medium | Medium | Test multiple services, manual cleanup |
| Laser test failures | Medium | High | Budget extra material, iterate quickly |
| Scope creep | High | Medium | Strict timeline, MVP first |

### 8.2 Launch Risks

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Low initial sales | Medium | High | Free sampler, email list, content marketing |
| Technical issues | Low | High | Thorough testing, monitoring, quick fixes |
| Negative reviews | Low | Medium | Quality control, responsive support |
| Competitor response | High | Low | Differentiation, community building |

### 8.3 Mitigation Strategies

1. **MVP First:** Launch with core assets, expand based on feedback
2. **Community Building:** Discord/Slack for early adopters
3. **Content Marketing:** YouTube tutorials, blog posts, social media
4. **Email List:** Capture before launch, nurture with value
5. **Iterative Improvement:** Monthly updates based on analytics

---

## 9. SUCCESS METRICS

### 9.1 Launch Metrics (First 30 Days)

| Metric | Target | Measurement |
|--------|--------|-------------|
| Email signups | 500+ | Gumroad analytics |
| Free sampler downloads | 1,000+ | Gumroad analytics |
| Paid sales | 20+ | Gumroad analytics |
| Revenue | $3,000+ | Gumroad analytics |
| Support tickets | < 50 | Help desk |
| Bug reports | < 10 | GitHub issues |

### 9.2 Ongoing Metrics (Monthly)

| Metric | Target | Measurement |
|--------|--------|-------------|
| Monthly sales | 20+ | Gumroad analytics |
| MRR (Monthly Recurring) | $3,000+ | Gumroad analytics |
| Tool usage (calibrations) | 100+ | Analytics |
| Asset downloads | 500+ | Gumroad analytics |
| Support response time | < 24h | Help desk |
| NPS score | 50+ | Survey |

### 9.3 Long-term Metrics (6-12 Months)

| Metric | Target | Measurement |
|--------|--------|-------------|
| Total customers | 500+ | Gumroad analytics |
| Revenue | $50,000+ | Gumroad analytics |
| Community members | 1,000+ | Discord/Slack |
| Product variants | 10+ | Catalog |
| Affiliate partners | 20+ | Program |
| Course completion rate | 60%+ | Analytics |

---

## 10. APPENDICES

### 10.1 Asset Style Guide

**Visual Language:**
- Sacred geometry, radial symmetry
- Crisp black linework on white background
- Centered composition
- No mockup scenes, shadows, or gradients
- No photorealism
- Adequate negative space for printing/tracing

**Base Suffix (append to all prompts):**
```
clean vector line art, black ink on white background, centered composition, 
radial symmetry, printable page layout, no shading, no gray tones, no texture, 
no mockup, high clarity, SVG-friendly
```

**Premium Suffix (for editorial feel):**
```
museum-grade geometric composition, calm negative space, precise line hierarchy
```

### 10.2 Color Palette

| Role | Hex | Usage |
|------|-----|-------|
| Primary | #4F98A3 | Links, buttons, accents |
| Secondary | #01696F | Headers, emphasis |
| Success | #6DAA45 | Confirmations, completions |
| Warning | #BB653B | Cautions, alerts |
| Error | #D163A7 | Errors, critical |
| Background (dark) | #171614 | Dark mode background |
| Background (light) | #F7F6F2 | Light mode background |
| Text (dark) | #CDCCCA | Dark mode text |
| Text (light) | #28251D | Light mode text |

### 10.3 Typography

| Role | Font | Weights | Usage |
|------|------|---------|-------|
| Display | Satoshi | 700 | Headlines, titles |
| Body | Satoshi | 400, 500 | Paragraphs, descriptions |
| Mono | SF Mono | 400 | Code, data, SKUs |

### 10.4 Iconography

| Icon | Meaning | Usage |
|------|---------|-------|
| ○ | Circle/ring | Geometry elements |
| ✕ | Cross/center | Alignment marks |
| △ | Triangle/petal | Mandala components |
| ⬡ | Hexagon | Structure indicators |
| ◇ | Diamond/vesica | Sacred geometry |

---

*Document Version: 1.0*
*Generated: June 2026*
*Status: Ready for Production*

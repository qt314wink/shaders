# Ritual Geometry — Complete Production Package
## Mandala Machine Tool v1.0 + Asset Library + Course Materials

---

## PACKAGE CONTENTS

```
rg_production_package/
├── tool/                          # Interactive Machine Tool
│   └── mandala-machine-tool.html  # Browser-based SVG→GCode converter
│
├── assets/
│   ├── coloring/                  # 20 Coloring Pages (SVG)
│   ├── stencils/                  # 8 Stencil Masters (SVG)
│   ├── wayfinders/                # 8 Construction Guides (SVG)
│   ├── remix/                     # 50 Remix Prompt Cards (SVG)
│   └── finishes/                  # 6 Finish Swatches (SVG)
│
├── course/                        # 8 Course Modules (PDF-ready)
├── marketing/                     # Launch materials
│   ├── gumroad/                   # Product page assets
│   ├── social/                    # Social media templates
│   └── email/                     # Email sequences
│
├── docs/                          # Technical documentation
└── qa/                            # Quality assurance
```

---

## QUICK START

### 1. Machine Tool
Open `tool/mandala-machine-tool.html` in any modern browser (Chrome, Firefox, Safari, Edge).

**Features:**
- SVG import and parsing
- 3-method kerf calibration (Single Square, Multi-Rectangle, Vernier)
- 9 material presets (Baltic Birch, MDF, Acrylic, Cork, Bamboo, Walnut)
- Layer-aware settings (cut/score/engrave per layer)
- Live 3-view preview (source, offset, travel)
- GCode export (GRBL, Marlin, Smoothieware)
- Kerf-adjusted SVG export for LightBurn
- Machine profile save/load (localStorage)

### 2. Coloring Pages
Print-ready SVGs at 500×500mm. Open in browser or vector editor. Suitable for colored pencils, markers, or digital coloring.

### 3. Stencils
Laser-cut ready SVGs with 3mm minimum bridges. Import into LightBurn or Glowforge. Test cut before production.

### 4. Remix Prompts
50 creative transformation cards. Print at 2.75"×4.75" on 300gsm cardstock. Use for design exploration or workshop activities.

---

## PRICING TIERS

| Tier | Price | Includes |
|------|-------|----------|
| **The Spark** (Free) | $0 | 1 coloring page + 1 stencil + 1 remix prompt |
| **The Forge** | $97 | Core course + Machine Tool + 10 coloring pages + 5 stencils |
| **The Atelier** | $197 | Everything + full library + 50 remix prompts + commercial license |
| **The Foundry** | $497 | Everything + source code + unlimited commercial rights |

---

## TECHNICAL SPECIFICATIONS

**Machine Tool:**
- Pure HTML/CSS/JS (no build step)
- Works offline (file:// protocol)
- localStorage for profile persistence
- Responsive design (desktop optimized)

**Assets:**
- Format: SVG (scalable vector graphics)
- Coloring: 500×500mm, 0.75pt lines
- Stencils: 400×400mm, 2pt lines, 3mm bridges
- Wayfinders: 400×400mm, 0.5pt faint lines
- Remix cards: 2.75"×4.75", 300 DPI equivalent

---

## LICENSE

**Personal Use:** Included with all tiers
**Commercial Use:** Atelier tier and above
**Source Code:** Foundry tier only

---

*Package Version: 1.0*
*Generated: 2026*
*Status: Production Ready*

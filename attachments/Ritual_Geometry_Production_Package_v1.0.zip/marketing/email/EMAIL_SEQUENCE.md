# EMAIL LAUNCH SEQUENCE

## Email 1: Announcement (Day -14)
**Subject:** The system is almost ready — Ritual Geometry

Body:
> For the past 6 months, I've been building something that doesn't exist yet.
>
> Not a craft kit. Not a template pack. Not another course.
>
> A complete system for making layered mandalas that look authored rather than assembled.
>
> It includes:
> - A browser-based Machine Tool that converts your SVGs into laser-ready GCode with kerf calibration
> - 20+ coloring pages, 8 stencil masters, 8 construction guides
> - 50 remix prompt cards for infinite variation
> - An 8-module course covering materials, assembly, finishing, and selling
>
> The Atelier tier launches in 2 weeks at $197.
> Early-bird pricing: $149 for the first 48 hours.
>
> [Join the waitlist]

## Email 2: Reminder (Day -3)
**Subject:** 24 hours left for early-bird pricing

Body:
> The Ritual Geometry Atelier tier launches tomorrow.
>
> Early-bird pricing ($149) expires in 48 hours.
>
> After that, the price goes to $197 permanently.
>
> What's inside:
> - Complete 8-module course
> - Mandala Machine Tool (SVG → GCode)
> - Full asset library (86 files)
> - Commercial license
>
> [Get early-bird access]

## Email 3: Last Chance (Day 0)
**Subject:** Ritual Geometry is live + final hours for early-bird

Body:
> It's here.
>
> Ritual Geometry: The Complete Mandala System is now live.
>
> Early-bird pricing ($149) expires at midnight.
>
> [Buy now — Atelier tier]
>
> Questions? Reply to this email.

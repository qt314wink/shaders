# SOCIAL MEDIA TEMPLATES

## Instagram Post 1: Hero Image
**Caption:**
> This is not a craft kit. It is an art system.
>
> Ritual Geometry brings together the structure of the computer, the warmth of physical materials, and the endless remix potential of a digital library.
>
> Link in bio.
>
> #ritualgeometry #mandala #lasercutting #sacredgeometry #maker #digitalproduct

## Instagram Post 2: Process Video
**Caption:**
> From code to sculpture in 8 steps.
>
> 1. Generate parametric mandala in TurtleToy
> 2. Export SVG
> 3. Import into Machine Tool
> 4. Calibrate kerf for your material
> 5. Generate GCode
> 6. Cut on laser
> 7. Assemble with spacers
> 8. Finish with oil
>
> The full system is now available. Link in bio.
>
> #ritualgeometry #process #lasercutting #woodworking #mandalaart

## Twitter Thread: Launch
**Tweet 1:**
> I spent 6 months building a system for making layered mandalas.
>
> Not templates. A complete design language.
>
> Here's what's inside 🧵

**Tweet 2:**
> The Mandala Machine Tool — a browser-based SVG→GCode converter with kerf calibration.
>
> Works with GRBL, Marlin, Smoothieware.
>
> No install. No subscription. Just open and cut.

**Tweet 3:**
> 20 coloring pages. 8 stencil masters. 8 construction guides. 50 remix prompt cards.
>
> All generated from the same parametric system.
>
> Consistent. Scalable. Remixable.

**Tweet 4:**
> The course: 8 modules, 56,000+ words.
>
> Materials. Assembly. Finishing. Pricing. Selling.
>
> Everything I learned making 100+ mandalas.

**Tweet 5:**
> Three tiers:
> • The Forge ($97) — Core system
> • The Atelier ($197) — Full library + commercial license
> • The Foundry ($497) — Source code + unlimited rights
>
> Early-bird: $149 for 48 hours.
>
> [Link]

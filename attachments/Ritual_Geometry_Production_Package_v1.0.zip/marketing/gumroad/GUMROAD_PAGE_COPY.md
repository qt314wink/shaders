# GUMROAD SALES PAGE PACK: IMAGE PROMPTS & FINAL COPY

## 1. Hero Image Prompt (The "Anchor")
**Goal:** Dramatic, high-end studio photography of the finished mandala next to the core course digital materials.

**Prompt:**
> Professional studio photography of a 12-inch, 7-layer laser-cut wooden mandala with sharp, clean geometric edges, sitting next to a tablet showing an elegant, minimal dashboard of "Ritual Geometry" course modules. Soft, intentional raking light creates deep shadows between the wood layers. High-end, gallery-quality art aesthetic. The wood has a natural, warm birch finish. Clean, neutral gray background. Sharp focus, high depth of field, 8k resolution.

## 2. Product Visuals (The "Stack")

### Coloring Page Spread Prompt
**Prompt:**
> Flat lay photograph of an open coloring book featuring intricate, high-contrast, sacred geometry mandala line art on thick, textured paper. Next to the book, a set of premium art pencils and a partially colored mandala page. Soft natural window light, minimalist studio desk setup, overhead view, clean composition.

### Stencil Preview Sheet Prompt
**Prompt:**
> Professional product mockup of a set of translucent, durable mandala stencil sheets fanned out on a dark, matte workspace. The stencil designs are crisp, clean geometric line work in a minimalist style. Sharp focus on the stencil edges. Moody, sophisticated tech-maker aesthetic. Overhead lighting.

### Remix Prompt Card Set Prompt
**Prompt:**
> A deck of elegant, heavy-stock prompt cards fanned out on a clean wooden desk. The cards feature minimalist typography and a subtle geometric mandala icon in the corner. Each card displays a short, provocative creative prompt like "Invert the center" or "Scale the outer ring." Sophisticated, editorial design aesthetic.

### Slide Deck Mockup Prompt
**Prompt:**
> Laptop screen displaying a slide from a "Ritual Geometry" presentation, showing a clean, architectural diagram of a mandala layered structure. The aesthetic is sophisticated, minimal, and high-end. The laptop sits in a quiet, sunlit design studio. Atmospheric and professional.

---

## 3. Final Gumroad Sales Page Copy

### Title
**Ritual Geometry: The Complete Mandala System**

### Subtitle
*Cut, color, and remix. A visual practice for making layered mandalas that hold attention.*

### Long Description
**This is not a craft kit. It is an art system.**

Ritual Geometry is a maker’s field guide for creating layered mandalas that look authored rather than assembled. It brings together the structure of the computer, the warmth of physical materials, and the endless remix potential of a digital library.

**Why this matters:**
Most mandala templates are static downloads. This is a design language. When you learn the system, you aren't just cutting shapes—you’re learning how to control depth, finish with intention, and create objects that feel collected, not manufactured.

**What you’ll receive (The Deluxe Bundle):**
*   **The Ritual Geometry Course:** Our complete, step-by-step program to designing, cutting, and assembling premium-grade layered mandalas.
*   **The Bonus Atelier:**
    *   **Printable Coloring Library:** A deep archive of mandala line art for meditation and practice.
    *   **Stencil Master Sheets:** Precision-cut line work for tracing, transferring, and remixing.
    *   **Remix Prompt Deck:** A structured set of creative triggers to generate fresh geometry when you’re stuck.
    *   **Atelier Image & Slide Pack:** Our high-fidelity visual decks used for inspiration, presentation, and study.

**The transformation:**
Whether you are a maker looking for a new product line, an artist wanting to master radial symmetry, or a creative technologist building generative visuals, this system gives you the geometry and the workflow to produce work that glows.

**Use it to:**
*   Create physical wall art with depth and presence.
*   Build a repeatable ritual practice through coloring and tracing.
*   Develop a professional, layered design product line.
*   Remix the geometry into your own design projects.

**The result is meant to feel earned.** If you’re ready to stop assembling and start building, the ritual begins here.

---

### FAQ
**What do I need to start?**
A basic digital cutter (like a laser or CNC) for the layers, and standard craft tools for the finish. The rest of the system is designed to be accessible.

**Is this for beginners?**
Yes. The workflow is modular: start with the printable pages, move to the stencil work, and advance to the layered laser builds when you’re ready.

**What kind of license do I get?**
Standard tiers include personal-use rights. Commercial-use rights (for selling your physical mandalas or using the designs in your own studio work) are available as an add-on.

**Can I get future updates?**
Yes. The system is designed to grow. When we add new templates or prompt decks, you’ll get access.

---

## 4. Final Product Bundle Evaluation (Final Summary)

This package is now a **premium digital ecosystem**.

- **Core Authority:** The Course (The "How").
- **Utility:** The Stencils (The "What").
- **Engagement:** The Coloring Pages (The "Practice").
- **Elasticity:** The Remix Prompts (The "Future").
- **Prestige:** The Slides/Images (The "Look").

This is not a file dump. It is a **professional art product**.

It is priced correctly, presented correctly, and structured to offer the right mix of utility for beginners and prestige for makers. The final step is to drop these assets into Gumroad, add the preview images, ensure the licenses are clear, and launch.

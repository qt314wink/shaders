# QA Checklist: Mandala-to-Machine Mapping Tool

## 1. Input Validation

- [ ] SVG loads successfully and all visible geometry resolves to paths (no missing shapes).[web:95][web:111][web:113]
- [ ] Text, strokes, and shapes are converted to paths before toolpath generation.[web:113][web:111]
- [ ] No open paths remain where closed contours are required for cutting.[web:95][web:111]
- [ ] ViewBox and coordinate system are correctly interpreted (no flips or scale drift).[web:95][web:114]

## 2. Kerf Calibration and Compensation

- [ ] Calibration module offers at least one test-cut pattern (square, multi-rectangle, or Vernier jig).[web:102][web:105][web:106][web:109][web:112]
- [ ] Measured kerf is computed using clear formulas and stored per material + thickness + settings.
- [ ] Half-kerf logic is applied appropriately for tight joints vs clearance fits.[web:102][web:105][web:106][web:109]
- [ ] UI indicates when kerf tables are missing or outdated for the chosen profile.

## 3. Per-Layer Material Settings

- [ ] Each SVG layer (or tagged group) can be assigned material type, thickness, feed rate, and laser power.
- [ ] Default presets exist for common materials and thicknesses.
- [ ] Layer summary panel shows total depth stack and individual passes.
- [ ] Changing layer order updates simulation and G-code in a predictable way.

## 4. SVG-to-GCode Mapping

- [ ] Generated GCode respects machine profile limits (bed size, origin, units, feed caps).[web:86][web:92][web:95]
- [ ] Travel moves use G0; cutting/engraving moves use G1+ with appropriate feed and power commands.[web:89][web:110][web:113]
- [ ] Arcs (where supported) are emitted as G2/G3 with correct center and radius, or safely flattened to line segments.
- [ ] Toolpaths are continuous where expected (no unintended lifts in closed contours).

## 5. Path Optimization

- [ ] Optional path simplification respects a maximum geometry deviation threshold.[web:108][web:114]
- [ ] Cut order minimizes rapid travel distance without crossing safety boundaries.[web:108]
- [ ] Small internal cuts are done before outer frames to prevent part movement.
- [ ] Engrave/score passes are separated from through-cuts where appropriate.[web:111]

## 6. Visualization and Preview

- [ ] 1:1 preview overlays toolpaths on original SVG geometry with distinct colors per operation.
- [ ] Simulation shows head position over time and highlights current segment.
- [ ] Bounds box for all paths fits entirely within the selected machine bed.
- [ ] Zoom/pan tools allow inspection of intricate mandala regions.

## 7. Calibration Feedback Loop

- [ ] Post-cut user inputs actual dimensions, and tool recomputes kerf offset and stores updated constants.[web:102][web:105][web:106][web:109][web:112]
- [ ] Historical kerf measurements are logged for trend analysis.
- [ ] Tool warns when large deviations suggest hardware issues (focus, mechanics, optics).[web:103][web:104][web:105][web:109]

## 8. Export and Compatibility

- [ ] Exports G-code compatible with GRBL-style controllers and at least one major laser ecosystem.
- [ ] SVG with kerf-adjusted paths can be exported for use in LightBurn / other CAM tools.[web:89][web:107][web:111]
- [ ] Machine profiles can be imported/exported as JSON or similar structured format.

## 9. Safety and UX

- [ ] Dry-run mode outputs travel-only or zero-power preview for validation.
- [ ] Warnings appear for out-of-bounds geometry or extreme feed/power combinations.
- [ ] Clear labeling for cut vs engrave vs score operations.
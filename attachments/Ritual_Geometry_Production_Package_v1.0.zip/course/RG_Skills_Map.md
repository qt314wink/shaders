# Skills: Mandala-to-Machine Mapping Tool

## Core Competencies

- SVG path analysis and normalization for complex radial and organic geometries.
- Kerf measurement modeling and compensation across materials and thicknesses.[web:102][web:105][web:106][web:109][web:112][web:115]
- Real-time SVG-to-GCode conversion using browser-friendly libraries.[web:89][web:110][web:113][web:116]
- Multi-layer mandala decomposition and layer-aware parameterization (thickness, feed, power, passes).
- Toolpath optimization for speed and stability (segment simplification, path ordering, corner handling).[web:108][web:111][web:114]
- Machine profile abstraction for lasers, CNC routers, and plotters (formats: SVG, DXF, AI, EPS, GCode, NC/TAP).[web:86][web:87][web:88][web:92][web:95]
- Live visualization of toolpaths overlaid on source geometry for debugging.

## Kerf Compensation Knowledge

- Test-cut methods: single-square method, multi-rectangle method, Vernier/jig methods.[web:102][web:105][web:106][web:109][web:112]
- Relationship of kerf to material type, thickness, laser power, speed, and optics.[web:103][web:104][web:105][web:109][web:112][web:115]
- Half-kerf offset logic: applying half the measured kerf to neutral centerline paths for tight joints vs loose fit.[web:102][web:105][web:106][web:109][web:112]
- Per-material kerf lookup tables and calibration routines.

## SVG-to-GCode Pipeline Skills

- Parsing SVG into path primitives (M/L/C/Q/A) and normalizing to polylines or arcs.[web:113][web:116]
- Using open-source converters (svg2gcode, svg-to-gcode, etc.) as reference implementations.[web:89][web:110][web:113][web:116]
- Mapping path geometry to motion commands (G0/G1/G2/G3) with per-segment feed and power.
- Maintaining 1:1 coordinate continuity from SVG viewBox to machine bed coordinates.[web:89][web:95]

## Optimization Skills

- Path simplification: reducing point count while respecting maximum deviation thresholds.[web:108][web:114]
- Cut ordering: nearest-neighbor or heuristic path reordering to reduce rapid moves and heat buildup.[web:108]
- Segment type selection: arcs vs many short segments for smoother motion on plotters and CNC.[web:110][web:113]

## Machine Profiles and Safety

- Defining machine profiles with bed size, origin convention, units, max feed/accel, and supported commands.[web:86][web:92][web:95]
- Distinguishing vector-cut vs raster-engrave regimes, and mapping them into profile capabilities.[web:95][web:111]
- Adding soft limits, dry-run modes, and bounds-checking for toolpaths.
# RITUAL GEOMETRY: PRODUCT SKU SYSTEM
## Internal Inventory Codes for Gumroad, Fulfillment, and Tracking

---

## What SKUs Are For

SKUs are **internal tracking codes** — not customer-facing names. [web:591][web:594]

They exist so you can:
- Track what sold, when, and in which tier
- Know exactly what files to deliver without guessing
- Identify product variations at a glance
- Manage inventory if you sell physical editions
- Sort and search your Gumroad backend efficiently

SKUs are typically 8–12 characters, alphanumeric, and structured logically. [web:592][web:598] They are different from UPCs (which are standardized global barcodes) because you create them yourself for your own system. [web:595][web:597]

---

## The Ritual Geometry SKU Architecture

### Format
```
RG-[Series]-[Geometry]-[Layer]-[Finish]-[Tier]
```

### Segment Codes

| Segment | Code | Meaning |
|---|---|---|
| **Brand** | RG | Ritual Geometry (always present) |
| **Series** | SF | Sacred Fire |
| | WM | Water Mandala |
| | TG | The Tilted Sky |
| | DW | The Deep Well |
| **Geometry** | BL | Bloom |
| | LT | Lattice |
| | CO | Coil |
| | FO | Fold |
| | RA | Radiance |
| | WE | Well |
| | GA | Gate |
| | VE | Vesica |
| **Layer Count** | 03L | 3 layers |
| | 05L | 5 layers |
| | 07L | 7 layers |
| | 11L | 11 layers |
| **Finish** | NAT | Natural / oil finish |
| | GOL | Gold edge accent |
| | BLK | Black edge accent |
| | COL | Full color / acrylic |
| | CHR | Charred edge, raw face |
| | WHT | White face, natural edge |
| **Tier** | FRG | The Forge ($97) |
| | ATL | The Atelier ($197) |
| | FDR | The Foundry ($497) |

---

## SKU Examples

| Product | SKU | What It Means |
|---|---|---|
| 7-layer Bloom, natural finish, Forge tier | `RG-SF-BL-07L-NAT-FRG` | Sacred Fire series, Bloom geometry, 7 layers, natural finish, Forge tier |
| 5-layer Lattice, gold edges, Atelier tier | `RG-SF-LT-05L-GOL-ATL` | Sacred Fire series, Lattice geometry, 5 layers, gold edges, Atelier tier |
| 11-layer Coil, full color, Foundry tier | `RG-WM-CO-11L-COL-FDR` | Water Mandala series, Coil geometry, 11 layers, full color, Foundry tier |
| 3-layer Radiance, charred, Forge tier | `RG-TG-RA-03L-CHR-FRG` | Tilted Sky series, Radiance geometry, 3 layers, charred finish, Forge tier |
| 7-layer Fold, white face, Atelier tier | `RG-DW-FO-07L-WHT-ATL` | Deep Well series, Fold geometry, 7 layers, white face, Atelier tier |

---

## Digital Product SKUs

For non-physical deliverables, use the same structure but with **DL** (digital) in the finish slot and the asset type in the geometry slot.

### Format
```
RG-[Series]-[AssetType]-[Count]-DL-[Tier]
```

| Asset Type | Code |
|---|---|
| Coloring pages | CP |
| Stencil masters | SM |
| Remix prompts | RP |
| Slide deck | SD |
| Course module | CM |
| Complete bundle | CB |

### Examples

| Product | SKU |
|---|---|
| Sacred Fire coloring pack, 20 pages, Atelier | `RG-SF-CP-20P-DL-ATL` |
| Full stencil master set, 12 sheets, Atelier | `RG-SF-SM-12S-DL-ATL` |
| 50 remix prompts, Atelier | `RG-SF-RP-50N-DL-ATL` |
| Complete digital bundle, Foundry | `RG-SF-CB-FUL-DL-FDR` |
| Single course module (M05 Assembly), Forge | `RG-SF-CM-M05-DL-FRG` |

---

## Tier-Only SKUs (For Gumroad Variant Management)

When the same product exists in multiple tiers, use tier suffixes.

| Product | SKU |
|---|---|
| Mandala Engine — Forge tier | `RG-ENG-CORE-001-FRG` |
| Mandala Engine — Atelier tier | `RG-ENG-CORE-001-ATL` |
| Mandala Engine — Foundry tier | `RG-ENG-CORE-001-FDR` |
| Ritual Geometry Course — Forge | `RG-CRS-FULL-001-FRG` |
| Ritual Geometry Course — Atelier | `RG-CRS-FULL-001-ATL` |
| Ritual Geometry Course — Foundry | `RG-CRS-FULL-001-FDR` |

---

## Physical Product SKUs

For finished mandalas you sell as physical objects.

### Format
```
RG-[Series]-[Geometry]-[Layer]-[Finish]-[Edition]-[Number]
```

| Edition | Code |
|---|---|
| One of One | OO |
| Limited (numbered) | LE |
| Open Edition | OE |
| Commission | CM |

### Examples

| Product | SKU |
|---|---|
| The Quiet Bloom, One of One | `RG-SF-BL-07L-NAT-OO-001` |
| Burning Lattice, 5 of 50 | `RG-SF-LT-05L-GOL-LE-005` |
| Golden Coil, Open Edition | `RG-SF-CO-07L-GOL-OE-001` |
| Deep Fold, Commission | `RG-DW-FO-11L-NAT-CM-003` |

---

## Free Sampler SKU

| Product | SKU |
|---|---|
| Free coloring sampler | `RG-FRE-SAMP-001-FRG` |
| Free stencil preview | `RG-FRE-SAMP-002-FRG` |
| Free remix prompt | `RG-FRE-SAMP-003-FRG` |

---

## How to Use These

### In Gumroad
1. Add the SKU field when creating each product variant
2. Use it for your own backend sorting — buyers never see it
3. When an order comes in, read the SKU to know exactly what to deliver

### In Your File System
Create folders by SKU prefix:
```
/RG-SF/
  /RG-SF-BL/
    /RG-SF-BL-07L/
      /RG-SF-BL-07L-NAT/
        /FRG/
        /ATL/
        /FDR/
```

### In Your Spreadsheet
Track every SKU with:
- SKU code
- Customer-facing name
- Tier
- Price
- Files included
- Sales count
- Revenue

---

## SKU Rules

1. **Never reuse a SKU** — even if a product is discontinued, retire the code [web:592][web:593]
2. **Keep them 8–12 characters** — short enough to read, long enough to encode meaning [web:592][web:598]
3. **Never use special characters** — hyphens and letters only; no spaces, slashes, or symbols
4. **Always start with RG** — brand consistency across all products
5. **Document every code** — maintain a master reference sheet so you never forget what ATL or FDR means

---

## Quick Reference: All Codes

| Category | Codes |
|---|---|
| **Series** | SF (Sacred Fire), WM (Water Mandala), TG (Tilted Sky), DW (Deep Well) |
| **Geometry** | BL (Bloom), LT (Lattice), CO (Coil), FO (Fold), RA (Radiance), WE (Well), GA (Gate), VE (Vesica) |
| **Layers** | 03L, 05L, 07L, 11L |
| **Finish** | NAT, GOL, BLK, COL, CHR, WHT |
| **Tier** | FRG, ATL, FDR |
| **Asset** | CP, SM, RP, SD, CM, CB |
| **Edition** | OO, LE, OE, CM |
| **Digital marker** | DL |

---

*An SKU is invisible to the buyer, but it is the spine of your product operation. Name it with the same care you name the mandala itself.*

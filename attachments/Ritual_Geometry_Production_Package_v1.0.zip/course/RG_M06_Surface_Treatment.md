# Module 6: The Sacred Geometry of Surface Treatment
## Ritual Geometry — Laser-Cut Mandala Curriculum

---

## Introduction: Why Finishing Matters

A laser-cut mandala exits the machine raw: charred edges, uniform material, no story yet. The cut is precise but anonymous. Finishing is where the piece becomes specific — where you sign it, date it, and give it a climate to exist in. [cite:605]

This module treats surface treatment as a design layer, not an afterthought. Each finish is a gesture. Each gesture closes a loop between machine precision and human touch.

---

## The Six Finishes

We use a closed vocabulary of six finishes. This constraint creates consistency across a product line and forces intentionality. You are not choosing from infinite options. You are choosing a stance.

| Finish | Code | Character | Best For | Difficulty |
|---|---|---|---|---|
| **Natural / Oil** | NAT | Warm, honest, timeless | Everyday pieces, teaching samples, bulk work | Beginner |
| **Gold Edge Accent** | GOL | Ceremonial, luminous, premium | Gift pieces, limited editions, sacred contexts | Intermediate |
| **Black Edge Accent** | BLK | Stark, architectural, contemporary | Modern interiors, contrast-driven collections | Intermediate |
| **Full Color / Acrylic** | COL | Vibrant, pop, saturated | Youth markets, festival pieces, maximalist work | Intermediate |
| **Charred Edge, Raw Face** | CHR | Wabi-sabi, elemental, ancient | Rustic settings, fire-themed series, contrast work | Beginner |
| **White Face, Natural Edge** | WHT | Clean, Scandinavian, gallery-ready | Minimalist spaces, architectural installations | Beginner |

---

## Finish 1: Natural / Oil (NAT)

### Character
This is the default honesty of the material. You are not hiding anything. You are preserving and deepening what the wood already is.

### Technique
1. Sand all faces to 220 grit, edges to 180 grit.
2. Remove laser char with light sanding or a quick wipe with mineral spirits.
3. Apply food-safe mineral oil, walnut oil, or beeswax-oil blend with a lint-free cloth.
4. Allow 24 hours for absorption. Buff with a clean cloth.
5. For deeper protection, apply a second coat after 48 hours.

### Variations
- **Matte seal**: Danish oil, buffed out before full cure.
- **Satin depth**: Tung oil, three thin coats, 24 hours between.
- **Living finish**: Oil only, no topcoat. Re-oil annually. The piece ages with its owner.

### Common Issues
- **Sticky surface**: Too much oil, not enough buffing. Wipe aggressively with a clean cloth.
- **Uneven absorption**: End grain drinks more oil than face grain. Pre-wet end grain with a damp cloth before oiling.

---

## Finish 2: Gold Edge Accent (GOL)

### Character
This is the ceremonial finish. The edge catches light. The face stays calm. The contrast reads as halo, as attention, as value.

### Technique
1. Complete the Natural / Oil finish on all faces first. Let cure fully.
2. Mask the face surfaces with low-tack painter's tape or vinyl transfer tape. Precision matters — bleed ruins the effect.
3. Apply gold leaf adhesive (size) to exposed edges with a small brush. Let come to tack (approx. 30 minutes — follow product instructions).
4. Apply genuine gold leaf or high-quality metal leaf to edges. Use a soft brush to press and trim.
5. Seal with a clear acrylic topcoat or shellac if handling will be frequent. Otherwise, leave unsealed for maximum brilliance.
6. Remove masking carefully after sealant is dry.

### Variations
- **Silver edge** for lunar/Water Mandala series.
- **Copper edge** for flame/earth palettes.
- **Gilded interior ring** instead of outer edge for a subtle halo effect.

### Common Issues
- **Leaf cracking**: Too much adhesive or too-fast application. Work in small sections.
- **Bleed onto face**: Tape seal failed. Use firmer burnishing of tape edges before applying size.

---

## Finish 3: Black Edge Accent (BLK)

### Character
This is the architect's finish. The laser char is amplified and controlled. The piece reads as drawing in space — black lines, light material.

### Technique
1. Sand faces to 220 grit. Leave edges at 120–180 grit for mechanical adhesion.
2. Apply black India ink, acrylic ink, or matte black enamel to edges with a small sponge or brush.
3. Wipe excess from face surfaces immediately with a damp cloth. The goal is edge-only saturation.
4. For deeper black, apply two thin coats, 2–4 hours apart.
5. Optional: Seal face with matte polyurethane or hardwax oil for durability. Leave edges unsealed if you want the black to read as raw material rather than applied coating.

### Variations
- **Half-black**: Only the outer perimeter edge, leaving inner ring edges natural.
- **Gradient edge**: Outer edge pure black, fading to natural toward the center ring.
- **Black face, natural edge**: The inverse — a void center with warm perimeter.

### Common Issues
- **Ink bleeding into grain**: End grain is thirsty. Apply a thin wash of shellac to end grain before inking.
- **Too glossy**: Use matte or flat formulations. Gloss reads as plastic, not elemental.

---

## Finish 4: Full Color / Acrylic (COL)

### Character
This is the maximalist finish. The mandala becomes stained glass, festival artifact, pop object. It does not apologize for saturation.

### Technique
1. Prime bare wood with a stain-blocking primer if using light or translucent colors over dark wood.
2. Apply acrylic paint or pigment in thin, even coats. Build opacity in 2–3 layers rather than one heavy coat.
3. Use fine brushes for detail work between lattice openings and interior shapes.
4. Seal with clear acrylic spray or brush-on varnish. Matte or satin varnishes preserve color better than gloss.

### Color Logic
- **Sacred Fire palette**: Crimson, burnt orange, deep gold, black.
- **Water Mandala palette**: Teal, ultramarine, silver-white, indigo.
- **Tilted Sky palette**: Pale blue, star yellow, twilight violet.
- **Deep Well palette**: Ochre, umber, stone gray, moss green.

### Common Issues
- **Brush marks visible**: Thin your acrylic slightly with medium. Apply in multiple sheer layers.
- **Color muddying**: Let each coat dry fully before next. Use a hair dryer on low to accelerate between layers.
- **Cracking in flex points**: Acrylic is brittle. Avoid heavy buildup at thin lattice bridges.

---

## Finish 5: Charred Edge, Raw Face (CHR)

### Character
This is the elemental finish. Fire touches the edge. The face remains untouched. The piece reads as something that survived something — ancient, weathered, honest.

### Technique
1. Sand the face only to 180–220 grit. Leave edges unsanded — the laser char is your starting point.
2. Enhance the edge char carefully with a propane torch or heat gun, moving constantly to avoid scorching the face.
3. Stop when the edge is uniformly deep black with a slight sheen. The face should remain unburned.
4. Lightly wire-brush the edge to remove loose carbon. Wipe with a tack cloth.
5. Apply a thin coat of oil or wax to the edge only, to stabilize the char and prevent transfer to hands or surfaces.
6. Leave the face raw, or apply a single coat of matte sealant for protection while preserving the raw wood feel.

### Safety Note
Work in a ventilated area. Charred wood particles are abrasive to lungs. Wear a respirator when brushing char.

### Variations
- **Partial char**: Only outer edge torched, inner rings natural.
- **Face wipe**: Lightly pass flame over face grain to darken texture without burning structure.
- **Scorched geometry**: Torch specific segments to create a gradient of heat across the piece.

---

## Finish 6: White Face, Natural Edge (WHT)

### Character
This is the gallery finish. The face becomes canvas. The edge remains wood. The piece reads as artifact and object simultaneously — a drawing that happens to be thick.

### Technique
1. Sand faces to 220 grit. Sand edges to 180 grit but do not round them — keep the laser-cut crispness.
2. Apply 2–3 thin coats of white gesso, white acrylic, or milk paint to the face only. Sand lightly between coats with 320 grit.
3. Protect edges with masking tape if needed, or work carefully with a small edge brush to avoid white on the perimeter.
4. For color work over white: use watercolor, gouache, or acrylic on the prepared white surface.
5. Seal with matte varnish or wax. The white must stay chalky, not plastic.

### Variations
- **Bone white**: Slightly warm white (add drop of ochre to gesso).
- **Chalk white**: Pure titanium white, no tint — arctic, stark.
- **Washed white**: Thin white stain that lets grain ghost through — softer, more organic.

### Common Issues
- **Yellowing over time**: Oil-based topcoats yellow white. Use water-based sealants only.
- **Edge contamination**: White on the edge ruins the contrast. Work from center outward.

---

## The Finish Selector

Use this decision tree when planning a new piece:

**What feeling should the piece have?**
- Warm, honest, everyday → **Natural / Oil**
- Ceremonial, precious, gift → **Gold Edge**
- Modern, stark, architectural → **Black Edge**
- Vibrant, playful, festival → **Full Color**
- Ancient, weathered, elemental → **Charred Edge**
- Clean, gallery, minimal → **White Face**

**What is the setting?**
- Handled frequently (coasters, toys, tools) → Natural or Charred, sealed.
- Displayed, rarely touched → Gold, White, or Full Color.
- Outdoor or humid → Avoid oil-only; use sealant.

**What is my skill level today?**
- First piece → Natural or Charred.
- Comfortable with materials → Black or White.
- Ready for precision → Gold or Full Color.

---

## Safety and Materials Reference

### Essential Safety
- **Respirator**: When sanding charred edges or applying spray finishes.
- **Ventilation**: When using solvents, oil-based finishes, or torches.
- **Nitrile gloves**: When applying oil, stain, or adhesive.
- **Eye protection**: When wire-brushing or using rotary tools.

### Core Material Kit
- Mineral oil or walnut oil
- Beeswax-oil blend
- Gold leaf, adhesive size, soft brushes
- India ink or matte black acrylic
- Acrylic paint set (limited palette: crimson, ochre, teal, ultramarine, white, black)
- White gesso or milk paint
- Clear matte varnish (water-based)
- Painter's tape, low-tack
- Sandpaper: 120, 180, 220, 320 grit
- Lint-free cloths, tack cloths

---

## Documentation Practice

For every finished piece, record:
- Material species and thickness
- Laser settings used (speed, power, PPI)
- Finish applied (code and variation)
- Date and batch number
- Any anomalies or learning

This log becomes your empirical body of knowledge. Over time, you will know exactly how cherry behaves with walnut oil, or how plywood char responds to a torch. That knowledge is your real asset — more valuable than any single piece.

---

## Exercises

1. **The Six Sample Plate**: Cut six identical small mandalas. Finish each with a different finish. Label and keep as a permanent reference set.

2. **The Edge Study**: Take one complex mandala. Apply Gold Edge, then photograph in three light conditions (direct sun, soft window, artificial). Notice how the edge reads differently in each context.

3. **The Living Finish**: Oil a piece with no topcoat. Re-oil it monthly for six months. Photograph the deepening patina at each stage.

4. **The Inversion**: Take a piece designed for Natural finish and finish it with Full Color. Take a piece designed for Full Color and finish it Natural. What changes in the geometry's readability?

5. **The Failure Archive**: Deliberately over-apply a finish, under-sand, let bleed occur. Document what happened and how you would prevent it. This archive is more useful than perfect pieces.

---

*Finishing is where the machine ends and you begin. The cut is geometry. The finish is voice.*

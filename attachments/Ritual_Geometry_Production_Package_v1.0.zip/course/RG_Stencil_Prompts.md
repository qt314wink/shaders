# Ritual Geometry Stencil Prompts

1. Bloom Outline Stencil — Bold radial flower mandala stencil with wide bridges, simplified interior shapes, clean cuttable geometry, black stencil design on white.
2. Lattice Ring Stencil — Circular lattice stencil with evenly spaced openings, strong negative space, durable cut paths, printable stencil sheet.
3. Coil Arc Stencil — Mandala stencil made from spiral arcs and radial bands, bold geometry, minimal fragile detail, suitable for tracing or laser cutting.
4. Radiance Burst Stencil — Starburst-centered stencil with thick spokes and clean outer ring, high contrast, crisp cuttable shapes.
5. Gate Pattern Stencil — Repeating arch and gate forms arranged in radial symmetry, bold stencil logic, negative-space-led composition.
6. Vesica Grid Stencil — Mandala stencil based on overlapping vesica shapes, clean bridges, strong cuttable structure.
7. Compass Bloom Stencil — Geometric compass-flower hybrid stencil with bold outer guide ring and stable internal cut paths.
8. Sacred Flame Stencil — Flame-like radial stencil with high negative space and thick contour integrity, elegant but durable.

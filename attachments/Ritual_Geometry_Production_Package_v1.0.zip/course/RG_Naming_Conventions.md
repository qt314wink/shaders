# RITUAL GEOMETRY: NAMING CONVENTIONS
## A Naming System as Deliberate as the Geometry Itself

---

## Philosophy

Names are the first finish. Before a buyer opens a file, touches wood, or loads a stencil, the name tells them what kind of world they are entering.

The goal is to create naming conventions that feel:
- **Authorial** — not generated, not numbered, not templated
- **Systematic** — so you can scale to 100 products without chaos
- **Premium** — every name signals craft, not commodity

---

## 1. Product Tier Naming

Avoid: Basic, Standard, Pro, Premium, Gold, Ultimate

These are SaaS words. They signal software, not sculpture.

| Tier | Old Name | Ritual Name |
|---|---|---|
| Entry | Basic | **The Spark** |
| Core | Standard | **The Forge** |
| Deluxe | Premium | **The Atelier** |
| Studio | Ultimate/Enterprise | **The Foundry** |

### Tier Descriptions
- **The Spark** — "One flame. One geometry. Begin here." (Free sampler or $7 coloring pack)
- **The Forge** — "Where parameters become physical. The core engine + essential workflow." ($97)
- **The Atelier** — "A complete studio: infinite generations, full asset library, commercial rights." ($197)
- **The Foundry** — "The source itself. Code, customization, unlimited production." ($497)

### Why This Works
Forge, Atelier, Foundry are **maker spaces**, not subscription tiers. They imply transformation, not transaction.

---

## 2. File Naming for Deliverables

### The Problem
`mandala_pack_v3_FINAL_updated.zip` looks like a high school project.

### The Solution: Codex Naming
`[Series]_[Geometry]_[LayerCount]_[Finish]_[Version]`

| Element | Format | Examples |
|---|---|---|
| **Series** | 2-letter code | RG (Ritual Geometry), SF (Sacred Fire), WM (Water Mandala) |
| **Geometry** | Descriptive word | Bloom, Lattice, Radiance, Fold, Coil |
| **LayerCount** | Number | 03L, 05L, 07L, 11L |
| **Finish** | Optional code | NAT (natural), GOL (gold edge), BLK (black), COL (color) |
| **Version** | v01, v02 | Incremental |

### Examples
- `RG_Bloom_07L_NAT_v01.zip` — Ritual Geometry, Bloom form, 7 layers, natural finish
- `SF_Radiance_05L_GOL_v02.svg` — Sacred Fire series, Radiance form, 5 layers, gold edges
- `WM_Coil_11L_COL_v01.pdf` — Water Mandala, Coil form, 11 layers, full color

### Bundle Naming
`RG_[BundleName]_[Tier]_[Date]`

- `RG_Coloring_Atelier_2026-05.zip`
- `RG_Stencils_Forge_2026-05.zip`
- `RG_Complete_Foundry_2026-05.zip`

### Why This Works
- Sorts beautifully in folders
- Tells the whole story at a glance
- Scales to hundreds of files without confusion
- Looks professional when buyers download and unzip

---

## 3. Individual Mandala Naming

Every mandala that leaves your studio should have a **proper name**, not a filename.

### Naming Structure
`[Quality] + [Form] + [Number/Edition]`

| Element | Options |
|---|---|
| **Quality** | Quiet, Burning, Golden, Deep, Slow, Riven, Held, Tilted |
| **Form** | Bloom, Lattice, Coil, Fold, Radiance, Well, Gate, Vesica |
| **Edition** | One of One, 3 of 50, Open Edition |

### Examples
- **The Quiet Bloom** — One of One, 2026
- **Burning Lattice** — 7 of 50, 2026
- **Golden Coil** — Open Edition
- **Deep Fold** — Commission, March 2026

### Why This Works
Names create provenance. "The Quiet Bloom, One of One, 2026" feels like art history. "mandala_12inch_v3.svg" feels like a printer test.

---

## 4. Series & Collection Naming

When you have multiple mandalas in a thematic group, name the collection, not just the pieces.

### Collection Names
| Theme | Collection Name |
|---|---|
| Fire/heat geometry | **The Burning Season** |
| Water/flow geometry | **The Slow Current** |
| Earth/stone geometry | **The Held Ground** |
| Air/light geometry | **The Tilted Sky** |
| Shadow/void geometry | **The Deep Well** |

### Collection Structure
`[Collection Name] — [Piece Name] — [Edition]`

Example:
- **The Burning Season**
  - *Burning Bloom* — 1 of 20
  - *Burning Lattice* — 2 of 20
  - *Burning Coil* — 3 of 20

### Why This Works
Collections increase perceived value. A buyer who owns 3 from *The Burning Season* has a set, not just three random mandalas.

---

## 5. Colorway & Finish Naming

When you offer the same geometry in multiple finishes, name the colorway with intention.

### Naming Structure
`[Material/Finish] + [Geometry Name]`

| Finish | Example |
|---|---|
| Natural birch, oil finish | **The Bare Bloom** |
| Black edges, white face | **The Written Lattice** |
| Gold edges, walnut | **The Gilded Coil** |
| Full color, acrylic | **The Painted Fold** |
| Charred edges, raw face | **The Burnt Radiance** |

### Why This Works
Each finish becomes a distinct SKU without needing a new geometry file. The Bare Bloom and The Gilded Bloom are the same cut, different stories.

---

## 6. Module & Document Naming

For your course materials, maintain the same systematic rigor.

### Document Naming
`RG_M[Number]_[ShortTitle]_[Format]`

| Format | Code |
|---|---|
| Module text | MD |
| Worksheets | WS |
| Cheat sheets | CS |
| Slide deck | SD |
| Video script | VS |

### Examples
- `RG_M01_DesignFundamentals_MD.pdf`
- `RG_M03_LaserSettings_CS.pdf`
- `RG_M05_Assembly_WS.pdf`
- `RG_M06_Finishing_SD.pdf`

### Why This Works
Buyers who download 20 files know exactly what each one is. You know exactly where to find the assembly worksheet when someone emails a question.

---

## 7. Stencil Naming

Stencils should be named for their **function**, not just their geometry.

### Naming Structure
`RG_[Geometry]_[Type]_[Size]`

| Type | Code |
|---|---|
| Full outline | OUT |
| Detail insert | DET |
| Negative space | NEG |
| Transfer sheet | TRN |
| Layer guide | LYR |

### Examples
- `RG_Bloom_OUT_12in.svg` — Full outline stencil, 12 inch
- `RG_Lattice_DET_6in.svg` — Detail insert stencil, 6 inch
- `RG_Coil_NEG_8in.svg` — Negative space stencil, 8 inch

### Why This Works
A buyer who wants to trace the outer edge knows exactly which file to open. A maker who wants to spray through negative space knows which stencil to load.

---

## 8. Remix Prompt Naming

Prompts are small, but they should feel like **seeds**, not instructions.

### Naming Structure
Each prompt gets a name, not a number.

| Prompt | Name |
|---|---|
| Invert the center | **The Inversion** |
| Scale the outer ring | **The Expansion** |
| Double the frequency | **The Tightening** |
| Add a radial offset | **The Drift** |
| Remove every third layer | **The Silence** |

### Why This Works
Named prompts feel like creative moves, not technical steps. "Try The Inversion" sounds like advice from a mentor. "Step 4: invert center" sounds like a software manual.

---

## 9. The Master SKU System

For your own inventory and Gumroad backend, use a master SKU that encodes everything.

### SKU Structure
`RG-[Series]-[Geometry]-[Layer]-[Finish]-[Tier]`

| Code | Meaning |
|---|---|
| RG | Ritual Geometry (brand) |
| SF | Sacred Fire (series) |
| BL | Bloom (geometry) |
| 07L | 7 layers |
| NAT | Natural finish |
| FGE | Forge tier |

### Example SKU
`RG-SF-BL-07L-NAT-FGE` = Ritual Geometry, Sacred Fire series, Bloom geometry, 7 layers, natural finish, Forge tier

### Why This Works
SKUs are invisible to buyers but essential to you. One glance at `RG-SF-BL-07L-NAT-FGE` and you know exactly what was sold, what to ship, and what tier the buyer owns.

---

## 10. The Forbidden List

Never use these words in customer-facing names:

| ❌ Bad | ✅ Why |
|---|---|
| Pack, Bundle, Kit | Implies commodity |
| Template | Implies generic |
| v3, FINAL, updated | Implies disorganization |
| Basic, Standard, Pro | Imposes software logic on art |
| New, Improved, Better | Implies the old version was bad |
| Cheap, Affordable, Budget | Destroys premium positioning |
| File, Download, Digital | Reminds them it’s not physical |

---

## Quick Reference Card

| What | Format | Example |
|---|---|---|
| **Tier** | The [Space] | The Atelier |
| **File** | RG_[Form]_[Layer]_[Finish]_v## | RG_Bloom_07L_NAT_v01.zip |
| **Mandala** | [Quality] [Form], [Edition] | The Quiet Bloom, One of One |
| **Collection** | The [Theme] Season | The Burning Season |
| **Colorway** | The [Finish] [Form] | The Gilded Bloom |
| **Module** | RG_M##_[Title]_[Format] | RG_M05_Assembly_WS.pdf |
| **Stencil** | RG_[Form]_[Type]_[Size] | RG_Bloom_OUT_12in.svg |
| **Prompt** | The [Move] | The Inversion |
| **SKU** | RG-[S]-[G]-[L]-[F]-[T] | RG-SF-BL-07L-NAT-FGE |

---

*A name is the first layer of finish. Name it like you made it.*

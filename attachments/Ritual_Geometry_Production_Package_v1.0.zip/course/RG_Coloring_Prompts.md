# Ritual Geometry Coloring Prompts

1. Quiet Bloom — Intricate radial mandala inspired by petals and concentric bloom structures, balanced symmetry, medium-complexity black line art, open spaces for coloring, clean vector line art, black on white.
2. Burning Lattice — Sacred geometry coloring page built from interlocking lattice rings and flame-like radial segments, symmetrical, elegant line hierarchy, printable black-and-white vector art.
3. Deep Well — Mandala with concentric circular wells, repeating arches, subtle void spaces, meditative structure, crisp printable coloring page linework.
4. Golden Coil — Spiral-inflected radial mandala with coiling bands and nested rings, graceful negative space, clean black ink line drawing for coloring.
5. Radiant Gate — Mandala based on nested gates, arcs, and threshold shapes, ceremonial symmetry, high-clarity line art for coloring.
6. Vesica Field — Coloring page built from layered vesica piscis geometry in radial arrangement, elegant overlaps, crisp lines, balanced white space.
7. Sun Chamber — Solar mandala with alternating ray bands, circular chambers, and petal forms, bold center, coloring-page composition.
8. Cathedral Wheel — Rose-window-inspired sacred geometry page, refined circular structure, crisp vector lines.
9. Mirror Pool — Reflective watery mandala with smooth nested arcs and circular tension, coloring-book line art with generous negative space.
10. Echo Ring — Concentric ring mandala with rhythmic repeating motifs, clear line hierarchy, strong meditative coloring flow.

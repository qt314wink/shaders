# Ritual Geometry Remix Prompts

1. Invert the center.
2. Widen the silence between rings.
3. Double the outer rhythm.
4. Remove every third layer.
5. Turn petals into gates.
6. Turn gates into petals.
7. Compress the center, loosen the edge.
8. Loosen the center, compress the edge.
9. Add a halo ring.
10. Break the perfect symmetry once.
11. Echo the smallest shape at the largest scale.
12. Make the outer ring quieter.
13. Make the center more ceremonial.
14. Replace circles with vesicas.
15. Replace vesicas with arcs.
16. Introduce a second pulse.
17. Stretch one motif across two rings.
18. Cut the density in half.
19. Add one dense band to an otherwise calm form.
20. Convert the bloom into flame.
21. Convert the flame into water.
22. Translate the form into stone.
23. Pull the pattern toward the cardinal directions.
24. Bias the form toward diagonals.
25. Add a hidden second grid.
26. Let one ring drift out of alignment.
27. Repeat a minor motif until it becomes dominant.
28. Turn outlines into filled voids.
29. Turn voids into linework.
30. Carve windows into the outer band.
31. Add a threshold at the center.
32. Create a false edge, then a true edge.
33. Collapse two rings into one.
34. Split one ring into three.
35. Use only large gestures.
36. Use only fine inner detail.
37. Make the center feel ancient.
38. Make the outer edge feel engineered.
39. Add a compass logic.
40. Add a rose-window logic.
41. Remove all sharp points.
42. Remove all soft curves.
43. Translate the mandala into a woven language.
44. Translate it into a carved language.
45. Build a ring from absence instead of marks.
46. Let the piece breathe more than usual.
47. Push it nearly to overcrowding, then stop.
48. Make the form feel like a doorway.
49. Make the form feel like weather.
50. Start from stillness, then add one disturbance.

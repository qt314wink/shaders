# Ritual Geometry Wayfinder Prompts

1. 12-Segment Radial Guide — Minimal circular pencil guide with 12 equal radial divisions, concentric rings, alignment marks, and central anchor point.
2. 8-Petal Construction Guide — Geometric flower guide with petal axes, inner and outer circles, and light registration points for hand drawing.
3. Mandala Layer Registration Sheet — Precision wayfinder with concentric placement rings, cardinal direction markers, and layer alignment ticks.
4. Centerfinding Rosette Guide — Central rosette construction page with crosshairs, ring spacing, and petal placement arcs.
5. Compass Mandala Draft Grid — Radial grid with 6, 12, and 24 division options, intended for sketching and tracing over.
6. Stencil Placement Guide — Instructional page showing where a stencil can rotate and repeat, including faint reference circles and position marks.
7. Symmetry Training Sheet — Half-detailed radial guide encouraging users to complete the remaining pattern by following mirrored axes.
8. Layer Stack Guide — Printable page with 3-layer, 5-layer, and 7-layer spacing references for planning physical mandala builds.

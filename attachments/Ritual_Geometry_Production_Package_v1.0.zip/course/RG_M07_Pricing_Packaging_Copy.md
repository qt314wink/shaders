# MODULE 7: Pricing, Packaging, and the Selling Page

## Foreword
This is the chapter where the work stops whispering and starts speaking in cash. The geometry has already done its quiet magic; now we decide how to name it, price it, package it, and let it enter the world without losing the mystery.

The goal is not to cheapen the mandala by selling it. The goal is to frame the object so clearly that the right buyer feels the charge before they ever touch the wood.

## Introduction
A strong product doesn’t begin with a discount. It begins with a point of view.

This module turns your mandala practice into a product system: one that can live as a physical artwork, a printable download, a stencil pack, a teaching tool, or a premium bundle.

---

## Part A: Price As Position

Price is not just arithmetic. It is a signal about time, rarity, and how much care went into the object. A mandala sold for thirty dollars and a mandala sold for three hundred dollars may use the same cut file, but they are not the same product because the framing, finishing, and presentation are not the same product.

The simplest rule is this: price the object, not only the materials. If the object took an afternoon to cut and two evenings to finish, the labor is part of the sculpture. If it is signed, numbered, boxed, and ready to hang, that is not an afterthought; that is the product architecture.

A useful mental ladder is:
- study / prototype
- open edition
- signed limited edition
- commission / one-of-one

Each rung should feel more deliberate than the one below it. The buyer should feel that the object became more exclusive, more refined, and more personal as the price rises.

### Suggested pricing bands

For a digital-first mandala brand on Gumroad, the practical bands are:
- Coloring pages / stencil sampler: $7 to $15
- Printable mandala pack: $19 to $39
- Main course with worksheets and process guides: $49 to $99
- Premium bundle with commercial use or bonus assets: $99 to $149

These tiers follow common creator pricing logic for digital downloads, where coloring-page and printable products typically sit in the low-ticket to mid-ticket range, while bundled educational products can move higher when the value is clearly packaged. Gumroad itself uses a simple per-sale fee model, which means higher ticket bundles can help absorb platform costs more gracefully. [web:454][web:457][web:480]

---

## Part B: The Product Stack

A single mandala practice can become four products without changing the core design language. That is the power of good systems thinking. You are not just selling a file; you are selling different levels of access to the same aesthetic world.

### 1. The physical artwork
This is the flagship object: layered wood, carefully finished edges, considered mounting, and a certificate or signature on the back. It is the highest-value expression because it includes material, labor, finishing, and presence.

### 2. The printable artwork
This is the accessible version: coloring pages, line art, printable meditative sheets, and at-home ritual pages. Printable coloring products are a proven digital category, and market guidance consistently places them in affordable ranges that encourage impulse purchase and bundle buying. [web:459][web:480]

### 3. The stencil pack
This is the maker-facing version: reusable outlines, transfer sheets, or cut-ready stencil geometry. Stencils can be sold as personal-use downloads, but the terms must be clear because stencil copyrights and usage restrictions vary by creator and platform license. [web:476][web:482]

### 4. The teaching product
This is your intellectual premium: the course, the process, the method, the workflow. It should feel like the missing manual to the visual language. Gumroad’s lightweight setup and direct-sale structure make it a sensible host for this kind of creator-first educational bundle. [web:454][web:456][web:461]

---

## Part C: What To Give Away

Yes, give some things away. But give away the things that create desire, not the things that create your entire business moat. A freebie should make the viewer think, "I want the rest of this universe."

The best giveaways are small and seductive:
- one coloring page
- one stencil
- one tiny cut-file preview
- one sample page from the workbook

These are strong because they show the voice of the system without replacing the system itself. Creative Commons and OER models work when a creator intentionally wants open reuse, but if your goal is premium sales, your free assets should be framed as samples with explicit personal-use boundaries. [web:471][web:475][web:473]

### What not to give away
Do not give away the full stencil library. Do not give away the strongest compositions, the most intricate linework, or the commercial-use rights unless that is a deliberate strategy. In product terms, those are your conversion engines.

---

## Part D: Packaging The Experience

Packaging is the emotional wrapper around the object. It is the difference between "I bought a thing" and "I received a relic."

For physical products, package like this:
- wrapped with tissue or archival paper
- signed backer card
- care card
- edition number if applicable
- a short note that frames the piece as handcrafted and intentional

For digital products, the equivalent is the sales page, preview images, PDF organization, filename clarity, and instant delivery. Gumroad’s creator-friendly checkout and digital delivery model make it easy to ship a clean file bundle, but the product still needs a strong narrative layer to feel premium. [web:454][web:457][web:461]

### The product naming rule
Use names that sound like objects, not files.

Better:
- The Mandala Workshop
- Black Fire Geometry
- The Layered Bloom System
- Ritual Geometry: Printable Edition

Avoid:
- Mandala Pack 1
- Templates V3
- Final_Final_Updated
- Resource Bundle

Naming should create atmosphere before utility.

---

## Part E: Gumroad Sales Copy

Below is a complete positioning draft you can use as the basis for your Gumroad product page. It leans artsy, compelling, and premium.

### Product title
**Ritual Geometry: Layered Mandalas for Cut, Color, and Quiet Power**

### Subtitle
A visual system for making mandalas that feel as deliberate as they look. Learn the method, print the pages, cut the layers, and turn geometry into an object with presence.

### Short product description
This is not a generic craft kit. It is a design language for people who want their work to hold still, glow softly, and read like a hand-built artifact. Inside, you’ll find the process for building layered mandalas, finishing them with intention, and turning the same visual logic into coloring pages, stencils, and printable ritual sheets.

### Long product description
Ritual Geometry is a maker’s field guide for layered mandalas, printable linework, and ceremonial color systems. It begins with the cut, deepens through the assembly, and ends in the finish: the surface choices that make the object feel collected rather than merely made.

Use it to create wall pieces, printable pages, stencil packs, or teaching materials. Use it to build a small product line or a whole visual world. Use it if you want your geometry to feel alive in the hand and unforgettable on the wall.

### Conversion paragraph
If you’ve ever looked at a mandala and felt that it could become more than a pattern — more like a signal, a keepsake, a small architecture of attention — this is the system that gets you there. The methods are practical, the forms are beautiful, and the result is meant to feel earned.

### CTA options
- Get the course
- Download the system
- Build the ritual set
- Start making layered mandalas

### FAQ copy
**Can I use this for commercial work?** Yes, if you choose the commercial tier.

**Do I need special tools?** No. A basic digital cutter and standard finishing tools are enough for the main workflow.

**Are the coloring pages printable at home?** Yes. They’re designed for standard home printing.

**Can I resell the templates?** Not unless the license explicitly allows it. Personal-use and commercial-use terms should be clearly separated.

---

## Part F: Suggested Gumroad Pricing

A strong first-pass pricing structure is:

| Product | Price | Why it works |
|---|---:|---|
| Free sampler | $0 | Builds trust and email capture |
| Coloring page pack | $9 | Low-friction impulse buy |
| Stencil pack | $15 | Practical maker utility |
| Core course | $49 | Clear educational value |
| Premium bundle | $99 | Best margin + strongest positioning |
| Commercial license add-on | $49 to $99 | Premium permissions and B2B-style pricing |

Gumroad’s direct-sale fee structure means keeping an eye on take rate when you choose low-ticket offers, since the fixed fee becomes more noticeable on cheaper items. That makes bundling and tiering especially important for creator businesses. [web:454][web:457][web:461]

---

## Part G: Module 8 If You Want It

Yes, there should be a Module 8 if you want the course to feel complete and generous. Module 8 should be the **bonus atelier**: coloring pages, stencils, printables, cut templates, remix prompts, and a small gallery of alternate outcomes.

This module is where the course becomes a library. It is also the safest place to include low-risk giveaways, because bonuses can be valuable without undercutting the core course.

### Module 8 ideas
- printable mandala coloring book pages
- stencil sheets for tracing or cutting
- 5–10 cut-ready geometry starters
- a finish swatch worksheet
- a remix prompt pack
- a commercial-use upsell explanation page

### Why Module 8 helps
A bonus module raises perceived value, gives buyers more to explore, and creates a natural place for upsells and future expansion. It also makes the product feel like a living ecosystem instead of a one-and-done download.

---

## Part H: Art Direction Notes

The voice should be elegant, not corporate. Desire should come from clarity, not hype. The copy should feel like it belongs in a studio notebook, a gallery shop, and a premium digital product page all at once.

Think: restrained confidence, sacred geometry, modern craft, tactile intelligence.

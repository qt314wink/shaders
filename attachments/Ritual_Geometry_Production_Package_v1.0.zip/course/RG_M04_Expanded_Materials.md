# MODULE 4: Expanded Materials — Metal, Leather, Fabric, Stone & Mixed-Media Mandalas

## Introduction: Beyond Wood

While wood remains the foundation of most laser-cut mandalas, **expanding into alternative materials** opens entirely new aesthetic territories and market segments:

- **Metal accents** → Industrial-modern, jewelry-grade luxury
- **Leather layers** → Tactile warmth, bohemian/southwestern aesthetics
- **Fabric/felt** → Soft-sculpture, textile art crossover
- **Stone/ceramic** → Permanent outdoor installations, memorial pieces
- **Mixed-media combinations** → Gallery-level work commanding $500-2000+

**Why this matters for your practice:** Mixed-media mandalas position you beyond "craft fair woodworker" into **fine art + design** territory. Museums, galleries, and high-end interior designers seek work that transcends single-material categories.

---

## Part A: METAL IN MANDALAS

### The Metal Strategy

Most hobby CO2 lasers (40-100W) **cannot cut metal**. However, they CAN:
1. **Engrave anodized aluminum** (removes colored oxide layer, reveals bare metal)
2. **Mark bare metal with CerMark/TherMark spray** (permanent chemical bonding)
3. **Cut thin metal foils** (0.1-0.3mm brass, copper, aluminum foil)
4. **Engrave metal with fiber lasers** (requires different laser type—20-50W fiber)

**For CO2 laser users (most home/small shop setups):**
- **Best approach:** Use **pre-cut metal accents** (purchased from metal suppliers) and laser-engrave designs onto them using CerMark spray
- **Alternative:** Cut wood, then inlay with purchased thin metal sheets (brass veneer, copper foil)

**For fiber laser users (professional/industrial):**
- Direct engraving on stainless steel, brass, copper, titanium, anodized aluminum
- Can mark permanent deep engravings suitable for structural mandala layers

---

### Material #1: Anodized Aluminum (CO2 Laser Compatible)

**What It Is:**
Aluminum that's been electrochemically treated to grow a thick oxide layer on the surface, then dyed in vibrant colors (black, blue, red, gold, silver, purple, green).

**How CO2 Laser Works on It:**
The laser **vaporizes the colored oxide layer**, revealing the bright bare aluminum underneath. This creates high-contrast permanent marks.

**Thickness & Availability:**
- 0.5mm (0.020"): Flexible, jewelry-weight — perfect for top decorative layers
- 1mm (0.040"): Semi-rigid — can be bent into dimensional forms
- 1.6mm (0.063"): Standard structural — equivalent to wood foundation layer
- Colors: Black (most contrast), blue, red, gold, silver, purple, green

**Laser Engraving Settings (CO2 40-80W):**

| Power | Speed | DPI/LPI | Result |
|-------|-------|---------|--------|
| 80-100% | 300-500 mm/s | 300-500 | Light mark, preserves color |
| 80-100% | 150-250 mm/s | 500-1000 | Medium contrast, partial oxide removal |
| 80-100% | 50-100 mm/s | 1000+ | Full oxide removal, bright metal |

**Critical Notes:**
- **You're engraving, not cutting.** CO2 lasers cannot cut through anodized aluminum—they only remove the surface coating.
- **Multiple passes deepen contrast.** 2-3 passes at medium speed create the brightest marks.
- **Focus is critical.** Even 1mm off-focus significantly reduces marking quality.
- **Air assist mandatory.** Prevents smoke residue from re-depositing on the surface.

**Where to Source:**
- **Grainger, McMaster-Carr**: Industrial suppliers, bulk pricing
- **Amazon**: "Anodized aluminum sheet 0.5mm" — hobby quantities
- **Local metal fabricators**: Often have scrap pieces perfect for mandala work

**Mandala Applications:**
- **Center medallion:** 3-4" diameter anodized aluminum disc as the mandala's focal point
- **Top layer accent:** Cut wood mandala, laser-engrave anodized aluminum disc, mount as topmost layer
- **Ring layers:** Cut concentric anodized aluminum rings (with hand tools or waterjet), engrave patterns, insert between wood layers

**Design Considerations:**
- **High contrast is essential.** Black anodized aluminum → bright silver marks. Gold anodized → dull marks (less contrast).
- **Geometric patterns work best.** Fine organic detail can get lost; bold geometric or sacred geometry reads clearly.
- **Test first.** Anodization quality varies by supplier—always test a sample before committing to full design.

**Price:** $15-35 per 12"x12" sheet (0.5mm thickness)

---

### Material #2: CerMark/TherMark on Bare Metal (CO2 Laser)

**What CerMark Is:**
A proprietary spray coating that, when laser-heated, **chemically bonds to metal surfaces** creating permanent black or dark marks. Works on bare metal (stainless steel, brass, copper, aluminum, titanium).

**How It Works:**
1. Spray CerMark onto clean bare metal surface
2. Let dry (5-10 minutes)
3. Laser engrave (CO2 laser vaporizes the coating into the metal surface)
4. Wipe off excess powder
5. Result: Permanent black mark fused into metal

**Laser Settings (CO2 40-80W, CerMark LMM-6000):**

| Material | Power | Speed | DPI/LPI | Passes |
|----------|-------|-------|---------|--------|
| Stainless Steel | 90-100% | 100-200 mm/s | 500-1000 | 1-2 |
| Brass | 80-90% | 150-250 mm/s | 500-1000 | 1-2 |
| Copper | 100% | 50-100 mm/s | 1000 | 2-3 |
| Aluminum | 100% | 100-200 mm/s | 500-1000 | 1-2 |

**CerMark Product Types:**
- **LMM-6000 Spray (Black):** Standard, easiest to apply
- **LMM-6000 Paste:** For vertical surfaces or intricate detail
- **TherMark (Colors):** Blue, green, red marks (less permanent than black)

**Where to Buy:**
- **CerMarkUSA.com**: Direct from manufacturer
- **JohnsonPlastics.com**: Distributor, bulk pricing
- **Amazon**: Hobby quantities

**Price:** $45-65 per 16oz aerosol can (covers ~20-30 sq ft)

**Mandala Applications:**

**1. Brass Center Medallion:**
- Purchase 3-4" diameter brass disc (Amazon, Etsy, metal supply)
- Spray with CerMark, laser-engrave intricate mandala pattern
- Polish surrounding brass, leaving black marks
- Mount as mandala center on wood backing

**2. Copper Ring Accents:**
- Cut wood mandala with circular gaps
- Fit copper rings (pre-cut or hand-cut from copper sheet)
- CerMark-engrave patterns on copper
- Assemble with wood layers

**3. Stainless Steel Top Layer:**
- Use thin stainless steel sheet (0.5mm)
- CerMark full mandala design
- Mount over wood backing
- Creates industrial-modern aesthetic

**Design Considerations:**
- **Apply CerMark evenly.** Uneven coating = patchy marks. Use multiple light coats, not one heavy coat.
- **Wipe, don't scrub.** After lasing, gently wipe away excess powder. Scrubbing can remove marks.
- **Expect variation.** Metal surface finish affects mark darkness—polished metal marks lighter than brushed.
- **NOT for structural layers.** CerMark is for decoration only; you're not cutting through metal, just marking it.

---

### Material #3: Thin Metal Foils (Cuttable with CO2)

**Foil Types That CO2 Lasers CAN Cut:**
- Brass foil: 0.1-0.3mm (0.004-0.012")
- Copper foil: 0.1-0.3mm
- Aluminum foil: 0.05-0.2mm (thicker than kitchen foil)
- Gold/silver leaf: 0.01-0.05mm (ultra-thin, decorative only)

**Laser Settings (CO2 40-80W, 0.2mm brass foil):**

| Power | Speed | Air Assist | Passes | Result |
|-------|-------|------------|--------|--------|
| 60-80% | 5-10 mm/s | Low | 1-2 | Clean cut, minimal melting |
| 80-100% | 10-20 mm/s | Medium | 1 | Fast cut, slight edge oxidation |

**Critical Notes:**
- **Support is mandatory.** Place foil on sacrificial wood or cardboard—foil alone will curl and shift during cutting.
- **Tape down edges.** Use masking tape at 4 corners to prevent shifting mid-cut.
- **Fire risk is REAL.** Thin metal foils can ignite or spark. Never leave unattended. Keep fire extinguisher nearby.
- **Edge quality.** Brass and copper oxidize (turn dark) at cut edges—this can be desirable (antique look) or polished away.

**Mandala Applications:**

**1. Brass Filigree Overlay:**
- Cut intricate mandala pattern from 0.2mm brass foil
- Mount on contrasting wood (dark walnut backing + bright brass = dramatic)
- Brass "floats" above wood, creating shadow depth

**2. Copper Sun Rays:**
- Cut radiating line patterns from copper foil
- Layer behind wood mandala
- Copper peeks through negative spaces

**3. Mixed-Foil Gradient:**
- Use gold, brass, copper foils in concentric rings
- Creates warm metallic gradient from center to edge

**Where to Buy Thin Metal Foils:**
- **Amazon**: "Brass shim stock 0.2mm" or "Copper foil sheet"
- **McMaster-Carr**: Industrial precision foils
- **Etsy**: "Metal foil sheets for crafts"
- **Local art supply stores**: Gold/silver leaf, decorative foils

**Price:** $12-25 per 12"x12" sheet (0.2mm brass)

**Design Considerations:**
- **Structural weakness.** Foils are decorative only—mount on wood backing for support.
- **Detail limit.** 0.5mm gaps are the practical minimum; smaller gaps will fall out or tear.
- **Patina development.** Brass and copper oxidize over time (greenish patina). Seal with clear lacquer to preserve brightness, or embrace the aging.

---

## Part B: LEATHER IN MANDALAS

### Why Leather Works

Leather is an **ancient material** that connects mandalas to spiritual and cultural traditions (Tibetan prayer wheels, Native American medicine wheels, Celtic knotwork). It adds:
- **Tactile warmth** — leather invites touch
- **Aging beauty** — develops rich patina over years
- **Bohemian/southwestern aesthetic** — appeals to yoga studios, wellness spaces, bohemian home decor markets
- **Lightweight** — 2-3mm leather weighs less than equivalent wood

**Laser Compatibility:**
CO2 lasers **excel at cutting and engraving leather.** It's one of the easiest materials to work with—clean cuts, high contrast engraving, minimal charring.

---

### Material #4: Vegetable-Tanned Leather (Safe & Recommended)

**What It Is:**
Leather tanned using natural plant tannins (oak bark, chestnut, mimosa). No heavy metals or toxic chemicals. This is the ONLY leather type safe for laser cutting.

**Characteristics:**
- Color: Natural tan/beige (undyed) to rich brown (dyed)
- Surface: Smooth or slightly textured
- Smell: Pleasant earthy/woody smell when laser cut
- Thickness: Measured in "ounces" (oz) — 1oz ≈ 0.4mm
  - 2-3oz (0.8-1.2mm): Thin, flexible — good for top decorative layers
  - 4-5oz (1.6-2mm): Medium — equivalent to 2mm wood layers
  - 6-8oz (2.4-3.2mm): Thick, structural — foundation layers
  - 10oz+ (4mm+): Belt leather, too thick for most mandala work

**Laser Cutting Settings (CO2 40-80W, 4-5oz veg-tan leather):**

| Power | Speed | Air Assist | Result |
|-------|-------|------------|--------|
| 40-60% | 30-50 mm/s | Medium | Clean cut, minimal browning |
| 60-80% | 20-30 mm/s | Medium | Slightly browned edges (rustic look) |
| 30-50% | 100-300 mm/s | Low | Engraving only (does not cut through) |

**Edge Treatment:**
- **Natural (do nothing):** Edges are slightly brown/charred but smooth
- **Edge beveler:** Hand tool that rounds sharp edges for professional finish
- **Edge burnisher:** Rub edges with wood/bone tool + water to create glossy seal
- **Edge paint:** Acrylic leather edge paint (Fiebing's) for polished look

**Where to Buy:**
- **Tandy Leather** (TandyLeather.com): Industry standard, retail stores nationwide
- **Weaver Leather Supply** (WeaverLeatherSupply.com): Wholesale pricing, bulk
- **Springfield Leather** (SpringfieldLeather.com): Premium quality
- **Local leather stores:** Search "leather supply [your city]"

**Price:** $4-8 per sq ft (4-5oz veg-tan)

**Mandala Applications:**

**1. Leather + Wood Hybrid:**
- Foundation: 5mm wood
- Layers 2-4: 3mm wood
- Layer 5: 4-5oz leather (natural tan)
- Layer 6: 2mm wood (stained dark walnut)
- Top layer: 2-3oz leather (tooled/stamped)

Creates alternating hard (wood) and soft (leather) layers—visual and tactile interest.

**2. Full Leather Mandala:**
- All layers: 4-5oz veg-tan leather
- Total 7 layers = ultra-lightweight (half the weight of wood)
- Finish: Oil (darkens to rich brown) or leave natural
- Market: Yoga studios, meditation spaces, bohemian decor

**3. Leather Center Medallion on Wood:**
- Cut wood mandala with circular center gap
- Cut leather disc to fit gap
- Engrave intricate pattern on leather
- Mount flush or raised above wood

**Design Considerations:**
- **Organic patterns work best.** Leather's natural texture complements flowing, organic mandala designs over rigid geometry.
- **Engraving creates high contrast.** Laser-engraved leather turns dark brown/black against tan background—beautiful for adding detail layers.
- **Leather darkens with age and oil.** Factor this into color planning. Oils (neatsfoot, mink oil) darken leather 2-3 shades.
- **Fire watch.** Leather can smolder. Keep fire extinguisher nearby, never leave unattended.

---

### NEVER Laser Cut: Chrome-Tanned Leather

**Chrome-tanned leather** (most commercial leather—shoes, jackets, furniture) uses chromium salts. When laser cut, it releases **hexavalent chromium** — a carcinogen that damages lungs and corrodes your laser.

**How to identify:**
- **Veg-tan:** Light tan color, stiffer, takes tooling/stamping, smells earthy
- **Chrome-tan:** Soft, supple, often dyed bright colors, smells chemically when heated

**When in doubt:** Buy from leather suppliers (Tandy, Weaver) and **ask specifically for vegetable-tanned leather** or "tooling leather."

---

## Part C: FABRIC & FELT IN MANDALAS

### Material #5: Wool Felt (Laser-Friendly)

**What It Is:**
Compressed wool fibers (no weave). Laser cutting felt is **effortless**—clean cuts, sealed edges (no fraying), wide color range.

**Felt Specifications:**
- Thickness: 1mm, 2mm, 3mm, 5mm common
- Density: 100% wool felt (premium, laser-safe) vs wool/synthetic blend (test first)
- Colors: 50+ colors available

**Laser Settings (CO2 40-80W, 3mm wool felt):**

| Power | Speed | Result |
|-------|-------|--------|
| 30-50% | 50-80 mm/s | Clean cut, no char |
| 20-40% | 100-200 mm/s | Engraving (debosses surface) |

**Why Felt Works:**
- **No fraying.** Laser heat fuses edges—no sewing or edge finishing needed.
- **Soft sculpture.** Felt mandalas transition into textile art, fiber art markets.
- **Quiet absorption.** Felt has acoustic dampening properties—appeals to sound-sensitive spaces (recording studios, meditation rooms).
- **Lightweight.** 7-layer felt mandala weighs ounces, not pounds.

**Mandala Applications:**

**1. Felt-Only Mandala (Soft Sculpture):**
- 7 layers of 3mm felt in gradient colors (dark purple → light lavender)
- Mount on stretched canvas or wood panel
- Gallery/textile art market

**2. Felt + Wood Hybrid:**
- Alternate layers: wood → felt → wood → felt
- Creates hard/soft rhythm
- Felt absorbs light, wood reflects—dramatic shadow play

**3. Nursery/Children's Decor:**
- Bright multi-color felt layers
- Safe (no sharp edges), tactile, washable
- Market: Etsy, children's boutiques, Montessori schools

**Where to Buy:**
- **Etsy**: "Wool felt sheets 3mm laser cutting"
- **Kunin Felt** (via Joann Fabrics, Michaels): Craft-grade felt
- **A Child's Dream** (AChildsDream.com): Premium 100% wool felt
- **Magic Cabin** (MagicCabin.com): Eco-friendly wool felt

**Price:** $3-6 per 9"x12" sheet (3mm 100% wool felt)

**Design Considerations:**
- **Felt is forgiving.** Intricate cuts that would break in 2mm wood hold perfectly in felt.
- **Color is the story.** Use felt's color range—create mandalas you'd never achieve with wood stain.
- **Mounting matters.** Felt is floppy—needs rigid backing (wood, foam board, stretched canvas) for wall hanging.

---

### Material #6: Cotton/Linen Fabric (Advanced)

**What It Is:**
Woven natural fabrics (cotton canvas, linen, muslin). Laser cuts them but with **edge fraying** unless treated.

**Laser Settings (CO2 40-80W, cotton canvas):**

| Power | Speed | Air Assist | Result |
|-------|-------|------------|--------|
| 40-60% | 30-60 mm/s | Low | Cut with minimal browning, sealed edges |
| 60-80% | 20-40 mm/s | Low | Browned edges (rustic look) |

**Edge Fraying Solution:**
- **Fabric stiffener (before cutting):** Spray fabric with stiffener, let dry, then laser cut. Edges stay sealed.
- **Fray Check (after cutting):** Brush liquid fray preventer on cut edges.
- **Double-layer technique:** Sandwich fabric between two sheets of transfer tape, cut, peel tape—edges stay crisp.

**Mandala Applications:**

**1. Fabric Mandalas for Quilting/Sewing:**
- Cut mandala pattern from cotton
- Appliqué onto quilt backing
- Cross-market to quilting community

**2. Banner/Flag Mandalas:**
- Cut mandala from canvas
- Mount on dowel rod
- Outdoor/festival decor

**3. Mixed-Media Textile Art:**
- Combine laser-cut fabric, wood, and felt
- Gallery textile art market

**Where to Buy:**
- **Joann Fabrics, Michaels**: Craft cotton, canvas
- **Spoonflower** (Spoonflower.com): Custom-printed fabrics (can laser cut designs printed on fabric)

**Price:** $8-15 per yard (cotton canvas)

---

## Part D: STONE & CERAMIC

### Material #7: Slate Tile (CO2 Laser Engravable)

**What It Is:**
Natural stone, layered sedimentary rock. CO2 lasers **engrave slate beautifully**—create permanent white/light gray marks on dark slate.

**Slate Specifications:**
- Thickness: 5-10mm typical (tile thickness)
- Size: 12"x12" tiles common
- Color: Dark gray, black, blue-gray, purple-gray
- Surface: Natural cleft (rough, rustic) or honed (smooth)

**Laser Settings (CO2 40-80W):**

| Power | Speed | DPI/LPI | Result |
|-------|-------|---------|--------|
| 80-100% | 50-100 mm/s | 300-500 | Light gray marks |
| 100% | 20-50 mm/s | 500-1000 | White, deep marks |
| 100% | 10-30 mm/s | 1000+ | Very deep, frosted white |

**Critical Notes:**
- **You're engraving, not cutting.** CO2 lasers cannot cut stone.
- **Multiple passes deepen marks.** 3-5 passes create dramatic contrast.
- **Focus on surface.** Stone is uneven—adjust focus height carefully.
- **Dust management.** Stone dust is abrasive—clean lens immediately after slate work.

**Mandala Applications:**

**1. Slate Center Medallion:**
- Purchase 6" round slate tile (Amazon, Etsy: "slate coaster blank")
- Laser-engrave mandala
- Mount as center of wood mandala
- Creates earth-toned, grounded aesthetic

**2. Outdoor Memorial Mandalas:**
- Slate is weatherproof
- Engrave mandala + text (memorial, dedication)
- Mount in garden, cemetery, outdoor meditation space

**3. Luxury Mixed-Media:**
- Wood foundation + slate center + brass accent rings
- Gallery-level work, $800-1500 price point

**Where to Buy:**
- **Amazon**: "Slate tile 12x12" or "Slate coaster blanks"
- **Etsy**: "Laser engraving slate blanks"
- **Home Depot/Lowe's**: Slate floor tiles (cut to size with tile saw)

**Price:** $3-8 per 6" round slate coaster blank

---

### Material #8: Ceramic Tile (CO2 Laser Engravable)

**What It Is:**
Glazed or unglazed clay tile. CO2 lasers can engrave **unglazed (bisque) ceramic** and **some glazes**.

**Laser Performance:**
- **Unglazed ceramic (bisque):** Engraves well, creates dark marks
- **White glazed ceramic:** Varies—test first. Some glazes vaporize cleanly (white to gray marks), others crack.
- **Colored glazes:** Usually laser-resistant (laser doesn't penetrate glaze)

**Laser Settings (CO2 40-80W, unglazed ceramic):**

| Power | Speed | Result |
|-------|-------|--------|
| 90-100% | 50-100 mm/s | Light brown marks |
| 100% | 20-50 mm/s | Deep brown/black marks |

**Mandala Applications:**

**1. Custom Tile Inserts:**
- Buy unglazed ceramic tiles (Etsy, pottery supply)
- Engrave mandala
- Install as decorative inserts in wood mandala

**2. Kiln-Fired Laser Mandalas (Advanced):**
- Engrave green (unfired) clay with mandala pattern
- Fire in kiln
- Permanent, glass-hard mandala
- Requires access to ceramic studio

**Where to Buy:**
- **Etsy**: "Unglazed ceramic tiles for laser"
- **Sheffield Pottery** (SheffieldPottery.com): Ceramic supply
- **Local pottery studios**: Often sell or donate bisque tiles

**Price:** $2-5 per 4"x4" unglazed tile

---

## Part E: MIXED-MEDIA MANDALA STRATEGIES

### Design Philosophy: Material as Narrative

Each material tells a story. **Mixed-media mandalas are conversations between materials:**

- **Wood + Leather:** Rustic, grounded, spiritual traditions
- **Wood + Metal:** Modern, industrial, geometric precision
- **Wood + Felt:** Soft/hard contrast, contemporary textile art
- **Wood + Stone:** Permanent, memorial, earth-rooted
- **Leather + Brass:** Bohemian luxury, Moroccan/Middle Eastern aesthetics
- **Felt + Cork:** Eco-conscious, Montessori/Waldorf education markets

**Guiding Question:** "What does this combination say that single-material can't?"

---

### Strategy #1: The Center-Accent Model

**Most Accessible for Beginners:**

1. Cut primary mandala from wood (5-7 layers)
2. Leave center open (circular gap)
3. Insert **one** accent material (brass disc, leather medallion, slate round, anodized aluminum)
4. Laser-engrave or hand-finish the accent

**Why It Works:**
- **Low risk.** Only one accent piece—if it fails, you've lost minimal materials.
- **High impact.** The eye gravitates to the center—accent material draws focus.
- **Easy assembly.** Accent mounts flat or slightly raised with spacers.

**Examples:**
- 11-layer walnut mandala + 4" brass center (CerMark-engraved)
- 7-layer maple mandala + 6" slate center (laser-engraved)
- 9-layer bamboo mandala + 3" leather center (hand-tooled)

---

### Strategy #2: The Alternating-Layer Model

**Intermediate Technique:**

Alternate wood and accent material throughout the stack:

1. Layer 1: 6mm wood (foundation)
2. Layer 2: 3mm wood
3. Layer 3: 2mm leather
4. Layer 4: 3mm wood
5. Layer 5: 3mm felt
6. Layer 6: 2mm wood
7. Layer 7: 1mm brass foil

**Why It Works:**
- **Rhythm.** Hard-soft-hard-soft creates visual and tactile interest.
- **Shadow complexity.** Different materials reflect/absorb light differently—multiplies shadow depth.
- **Story-driven.** "Seven materials representing seven chakras" or "Seven cultures' sacred symbols"

**Design Consideration:**
- **Keep wood dominant.** 50-70% wood layers maintain structural integrity.
- **Test assembly first.** Mixed materials have different expansion rates—test with hot glue before committing to epoxy.

---

### Strategy #3: The Ring-Inlay Model

**Advanced Technique:**

1. Cut wood mandala with circular **channels** (not just gaps—actual recessed rings)
2. Cut metal/leather/felt rings to fit channels
3. Inlay accent rings into wood
4. Creates seamless surface with material transitions

**Tools Needed:**
- CNC router or Dremel tool (to cut recessed channels)
- Calipers (measure channel depth precisely)
- Wood glue or epoxy (secure inlays)

**Why It's Powerful:**
- **Professional finish.** Flush inlays read as intentional design, not added accents.
- **Gallery-level work.** Inlay technique signals mastery, commands premium pricing.
- **Custom commissions.** Offer bespoke material combinations: "Would you like brass, copper, or turquoise inlay rings?"

---

## Part F: Sourcing & Safety

### Material Safety Chart

| Material | CO2 Laser Safe? | Fiber Laser Safe? | Fumes | Notes |
|----------|-----------------|-------------------|-------|-------|
| **Veg-tan leather** | ✅ Yes | ✅ Yes | Mild, earthy | Only veg-tan—never chrome-tan |
| **Wool felt (100%)** | ✅ Yes | ✅ Yes | Mild, hair-like | Test blends first |
| **Cotton/linen** | ✅ Yes | ✅ Yes | Minimal | Edges may fray |
| **Anodized aluminum** | ✅ Yes (engrave only) | ✅ Yes | None | Cannot cut, only mark |
| **Brass foil (thin)** | ✅ Yes | ✅ Yes | Metallic smell, sparks | Fire watch mandatory |
| **Slate** | ✅ Yes (engrave only) | ✅ Yes | Stone dust | Clean lens after |
| **Ceramic (unglazed)** | ✅ Yes (engrave only) | ✅ Yes | Ceramic dust | Test glaze first |
| **Chrome-tan leather** | ❌ NO | ❌ NO | Toxic | Releases chromium—never laser |
| **PVC/Vinyl** | ❌ NO | ❌ NO | Toxic | Releases chlorine gas |
| **Fiberglass** | ❌ NO | ❌ NO | Toxic | Airborne glass particles |

---

### Mixed-Media Supply Kit (Starter)

**For $150-200, build a mixed-media starter kit:**

1. **Metal Accents:**
   - 1x 12"x12" anodized aluminum sheet (black, 0.5mm): $25
   - 1x can CerMark LMM-6000 spray: $55
   - 2x 6" brass discs (Etsy): $15

2. **Leather:**
   - 2x sq ft veg-tan leather (4-5oz, Tandy): $15

3. **Felt:**
   - 10x 9"x12" wool felt sheets (mixed colors, Etsy): $40

4. **Stone:**
   - 5x 6" round slate coasters (Amazon): $20

5. **Foils:**
   - 1x 12"x12" brass shim stock (0.2mm): $18
   - 1x 12"x12" copper foil: $18

**Total: ~$206**

This kit lets you test every technique in Module 4 before committing to bulk orders.

---

## Part G: Market Positioning for Mixed-Media

### Price Tiers

| Material Combination | Target Price | Market |
|---------------------|--------------|--------|
| **Wood-only mandala** | $50-150 | Craft fairs, Etsy, local shops |
| **Wood + CerMark brass center** | $120-250 | Home decor boutiques, gift shops |
| **Wood + leather + felt (7 layers)** | $200-400 | Yoga studios, wellness centers, galleries |
| **Wood + slate + anodized aluminum (9 layers)** | $350-600 | Interior designers, luxury home decor |
| **Wood + brass inlay + slate + leather (11 layers)** | $600-1500 | Art galleries, custom commissions, museums |

### Brand Story Examples

**Bohemian/Spiritual Market:**
"Handcrafted mandala combining sustainably sourced walnut, hand-tooled vegetable-tanned leather, and brass—echoing ancient Tibetan prayer wheels and Native American medicine wheels."

**Modern/Industrial Market:**
"Geometric mandala in laser-cut maple and anodized aluminum—where traditional sacred geometry meets contemporary material innovation."

**Eco/Natural Market:**
"Seven-layer mandala: FSC-certified birch, bamboo, cork, and wool felt—100% renewable, biodegradable materials supporting regenerative design practices."

**Luxury/Custom Market:**
"Museum-grade mandala with reclaimed barn wood foundation, Pennsylvania bluestone center medallion, hand-engraved copper accents—a permanent heirloom piece embodying the layered history of place."

---

## Key Takeaways

1. **Start with the center-accent model.** Lowest risk, highest impact—add one accent material to proven wood designs.

2. **Veg-tan leather is your easiest non-wood material.** It's safe, affordable, laser-friendly, and opens bohemian/spiritual markets.

3. **CerMark on brass discs = instant luxury.** A $3 brass disc + $2 of CerMark spray = $50-80 perceived value when laser-engraved and polished.

4. **Felt is underrated.** It's effortless to laser cut, opens textile art markets, and weighs almost nothing.

5. **Mixed-media justifies 2-3x pricing.** A wood mandala sells for $80; wood + leather + brass sells for $250—same labor, triple the perceived value.

6. **Safety is non-negotiable.** Never laser chrome-tanned leather, PVC, or unknown materials. When in doubt, test outside.

7. **Material sourcing becomes curation.** Once you master mixed-media, you're not just a woodworker—you're a material curator telling stories through thoughtful combinations.

---

**Next Module Preview:** Module 5 will cover **Assembly Techniques** — spacers, adhesives, mounting hardware, and professional finishing for multi-layer mandalas.


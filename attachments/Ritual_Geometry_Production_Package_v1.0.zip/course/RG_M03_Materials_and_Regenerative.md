# MODULE 3: Recommended Materials and Thicknesses for 5-11 Layer Mandalas

## Part A: The Material Hierarchy (Decision Framework)

Multi-layer laser-cut mandalas aren't just "wood stacked on wood." Each material choice creates cascading effects on: structural integrity, visual depth, assembly difficulty, weight, cost, and market positioning.

**The Three-Tier System:**

**Tier 1: Foundation Layer (Backing Plate)** — Structural rigidity, weight distribution  
**Tier 2: Middle Layers (3-9 layers)** — Visual depth, shadow creation, cost efficiency  
**Tier 3: Top Layer (Detail/Protective)** — Finishing aesthetic, durability, premium feel

---

## Part B: The Core Three Materials

### Material #1: Baltic Birch Plywood (The Gold Standard)

**Technical Specifications:**
- Density: 650-700 kg/m³
- Ply Count: 7-13 cross-bonded veneers
- Core: **Void-free** (critical for laser cutting)
- Adhesive: Phenolic or melamine resin
- Moisture Content: 8-12% (stable)
- Flatness Tolerance: ±0.2mm (premium grade)

**Why It Dominates:**

1. **No voids = no failed cuts.** Standard hardware store plywood has hidden air pockets that cause the laser to punch through inconsistently. Baltic Birch's dense, layered core ensures every pass cuts cleanly.

2. **Dimensional stability.** The cross-grain veneer orientation prevents warping under heat. When you stack 7-11 layers, warping becomes cumulative—Baltic Birch's rigidity keeps the mandala flat.

3. **Grain aesthetic.** The subtle, tight grain pattern adds organic texture without competing with the mandala design. It stains beautifully and takes oil finishes like Danish oil or tung oil to create rich, deep contrast.

**Laser Cutting Performance (3mm thickness, 50-80W CO2):**
- Speed: 15-20 mm/s
- Power: 60-70%
- Passes: 2-3 (Module 1 multi-pass protocol)
- Edge Quality: Crisp, minimal charring
- Kerf: 0.10-0.15mm (predictable, easy to compensate)

**Cost Analysis:**
- Price: $25-45 per 12"x24" sheet (3mm thickness)
- Yield: One 12" mandala + 2-3 smaller test pieces per sheet
- Cost per 7-layer mandala: $8-12 in materials

**Where Baltic Birch Wins:**
- Natural wood aesthetic projects
- Structural integrity for 9-11 layer builds
- Oil/stain finishing (grain shows through beautifully)
- Export/resale (FSC certification available)

**Where It Loses:**
- Painted projects (grain texture shows through paint)
- Ultra-intricate detail (grain can obscure fine lines)
- Budget constraints (MDF is cheaper)

---

### Material #2: MDF (Medium-Density Fiberboard) — The Painter's Choice

**Technical Specifications:**
- Density: 700-850 kg/m³ (denser than Baltic Birch)
- Structure: Uniform compressed wood fibers (no grain)
- Core: Completely homogeneous
- Surface: Smooth, matte, porous

**Why Professionals Use It:**

1. **No grain = perfect paint surface.** MDF absorbs paint evenly without the grain pattern telegraphing through. For vibrant, multi-color mandalas, this is essential.

2. **Laser cuts like butter.** The uniform density means no hard/soft spots—the laser travels at constant speed with zero hesitation. This creates **perfectly smooth edges** with no chipping.

3. **Cost-effective for volume production.** MDF is 30-50% cheaper than Baltic Birch, making it ideal when you're producing 10+ mandalas per batch or selling at mid-tier price points.

**Laser Cutting Performance (3mm thickness, 50-80W CO2):**
- Speed: 18-22 mm/s (faster than Baltic Birch!)
- Power: 55-65%
- Passes: 2 passes typically sufficient
- Edge Quality: Exceptionally smooth, minimal sanding needed
- Kerf: 0.12-0.18mm (slightly wider than wood, but predictable)

**Cost Analysis:**
- Price: $15-30 per 12"x24" sheet (3mm thickness)
- Cost per 7-layer mandala: $5-8 in materials

**Where MDF Wins:**
- Painted/dyed finishes (acrylic, spray paint, watercolor washes)
- Budget-conscious production
- Ultra-intricate patterns (no grain interference)
- Uniform laser behavior (repeatability across batches)

**Where It Loses:**
- **Heavy.** 40-50% heavier than Baltic Birch for the same thickness
- **Moisture sensitive.** Swells and warps if exposed to humidity—not suitable for outdoor use
- **Dust hazard.** MDF dust is fine and requires excellent ventilation during cutting
- Natural wood aesthetic (no visible grain for oil finishing)

**Critical Safety Note:** MDF adhesives can release formaldehyde when laser cut. **Always use proper ventilation and check for low-VOC or formaldehyde-free MDF** (often labeled as CARB-2 or NAF—No Added Formaldehyde).

---

### Material #3: Chipboard/Hardboard — The Budget Workhorse

**Technical Specifications:**
- Density: 600-800 kg/m³
- Structure: Compressed wood particles or fibers
- Surface: One smooth side (masonite/hardboard) or rough both sides (chipboard)
- Thickness: Commonly 3mm

**Why Use It:**

1. **Lowest cost.** Often 50-70% cheaper than MDF, ideal for practice runs, prototyping, or budget product lines.

2. **Hardboard has one polished side.** Perfect for single-sided decorative pieces where only the front matters.

3. **Accepts paint and stain.** Similar to MDF in finish versatility, though slightly more textured.

**Laser Cutting Performance (3mm thickness, 50-80W CO2):**
- Speed: 15-18 mm/s
- Power: 60-75%
- Passes: 2-3 (can be inconsistent—always test)
- Edge Quality: Variable—can have slight flaking on chipboard; hardboard is cleaner
- Kerf: 0.15-0.20mm

**Where Chipboard/Hardboard Wins:**
- Prototyping and test runs
- Budget production (craft fair economy tier)
- Single-sided display pieces (hardboard)
- Teaching/workshop settings where material cost matters

**Where It Loses:**
- **Inconsistent quality.** Batch-to-batch variation in density causes laser performance issues
- **Structural weakness.** Not suitable for foundation layers in 9-11 layer builds
- **Aesthetic limitations.** Doesn't have the refinement of Baltic Birch or the smoothness of MDF
- Durability (more prone to chipping at edges)

---

## Part C: Thickness Strategy for 5-11 Layer Mandalas

The thickness of each layer determines the overall depth, shadow cast, and structural integrity of your mandala. Here's the strategic framework:

### The Graduated Thickness Model (Professional Standard)

**Layer 1 (Foundation/Back):** 5-6mm  
*Rationale:* Provides structural base, resists warping under weight of upper layers, creates stability for wall mounting.

**Layers 2-4 (Middle Depth):** 3mm  
*Rationale:* Balances shadow depth with cost. Three 3mm layers = 9mm of visual depth, creating pronounced shadows without excessive weight.

**Layers 5-7 (Detail Layers):** 2mm  
*Rationale:* Allows finer detail work (smaller kerf means intricate cuts hold together), reduces weight on outer layers.

**Layers 8-9 (Fine Detail, Optional):** 1.5mm  
*Rationale:* For ultra-intricate top layers. 1.5mm is the practical minimum for laser cutting without structural fragility.

**Layer 10-11 (Protective/Accent, Optional):** 1mm acrylic or 0.8mm wood veneer  
*Rationale:* Creates a "glazed" protective layer or adds metallic/colored accent without bulk.

### The Uniform Thickness Model (Simplified Production)

**All layers:** 3mm  

*Rationale:* Simplifies material sourcing, creates uniform shadow depth, easier to calculate spacing. This is the default for 5-7 layer builds.

**Pros:**
- Single material order (no need to stock multiple thicknesses)
- Consistent laser settings across all layers
- Predictable assembly (same spacer height throughout)

**Cons:**
- Less visual drama than graduated model
- Heavier overall weight (not ideal for 11-layer builds)
- Foundation layer may need reinforcement (add backing board)

---

## Part D: REGENERATIVE MATERIALS & ECO-SUSTAINABLE OPTIONS

### Why This Matters

The regenerative design philosophy asks: **"Can this product give back more than it takes?"** For laser-cut mandalas, this means:

1. **Material sourcing** that supports ecosystem health (FSC forests, reclaimed sources)
2. **Low-waste production** (nested cuts, scrap utilization)
3. **Durable products** that last decades, not years
4. **End-of-life biodegradability** or recyclability
5. **Local sourcing** to reduce transportation carbon footprint

**Market positioning insight:** Eco-conscious consumers will pay 30-50% premiums for verified sustainable materials. FSC certification, reclaimed wood stories, and carbon-neutral production are powerful brand differentiators.

---

### Regenerative Material #1: FSC-Certified Wood

**What FSC Certification Means:**

The Forest Stewardship Council (FSC) certifies that wood comes from responsibly managed forests where:
- Trees are harvested at sustainable rates (replanting exceeds harvest)
- Wildlife habitats are protected
- Indigenous rights are respected
- Water quality is maintained
- Worker safety standards are enforced

**FSC-Certified Woods Available for Laser Cutting:**

**Baltic Birch (FSC):**
- Availability: Major suppliers (Woodpeckers, Ocooch Hardwoods, Advantage Trim & Lumber)
- Price Premium: +15-25% over non-certified
- Performance: Identical to standard Baltic Birch
- Certification: Look for FSC-C########## mark on packaging

**Maple Plywood (FSC):**
- Characteristics: Lighter color than birch, tighter grain, slightly harder
- Laser Performance: Cuts similar to Baltic Birch but may require +5-10% power
- Aesthetic: Premium "white wood" look, excellent for Scandinavian/minimalist designs

**Cherry Plywood (FSC):**
- Characteristics: Warm reddish-brown tone, ages beautifully (darkens over time)
- Laser Performance: Cuts cleanly at slightly higher power (65-75% vs 60-70%)
- Aesthetic: Premium hardwood appearance, luxury market positioning

**Walnut Plywood (FSC):**
- Characteristics: Rich dark brown, dramatic grain contrast
- Laser Performance: Similar to cherry, may produce more smoke (ventilation critical)
- Aesthetic: Top-tier luxury material, commands 2-3x pricing of Baltic Birch

**How to Market FSC Materials:**

- **Certificate display:** Frame your FSC chain-of-custody certificate, photograph it next to products
- **Product tags:** "Made with FSC-certified wood from responsibly managed forests"
- **Brand story:** "Every mandala plants more trees than it uses"
- **Partnerships:** Donate $1 per sale to Arbor Day Foundation or One Tree Planted

---

### Regenerative Material #2: Reclaimed Wood

**The Philosophy:**

Reclaimed wood gives new life to materials that would otherwise be waste—barn siding, shipping pallets, demolished building lumber, storm-fallen trees, furniture scraps.

**The Challenges:**

1. **Metal contamination:** Old nails, screws, staples embedded in wood will **destroy your laser tube** on contact. Always use:
   - Strong rare-earth magnets to detect metal
   - Metal detector (cheap hardware store models work)
   - Manual inspection with flashlight at angle (metal glints)

2. **Unknown treatments:** Reclaimed wood may have:
   - Lead paint (pre-1978 buildings)
   - Creosote treatment (railroad ties—NEVER laser these)
   - Pressure treatment (CCA-treated lumber releases toxic fumes)
   - Industrial adhesives or sealants

3. **Inconsistent thickness/warping:** Reclaimed boards often have uneven surfaces, cupping, or twist.

**Safe Reclaimed Wood Sources:**

**Shipping Pallets (Heat-Treated Only):**
- Look for "HT" stamp (heat-treated, not chemically treated)
- Avoid "MB" stamp (methyl bromide treatment—toxic)
- Characteristics: Often oak or pine, weathered gray patina
- Preparation: De-nail, plane flat, cut into sheets

**Barn Wood:**
- Source: Architectural salvage yards, Craigslist, farm demolitions
- Characteristics: Weathered gray or red (from barn paint), aged 50-150 years
- Preparation: Metal detect, sand surface, seal with shellac before cutting
- Aesthetic: Rustic, "farmhouse modern," storytelling material ("This wood is from a 1920s Pennsylvania dairy barn")

**Furniture Scraps:**
- Source: Custom furniture shops, cabinet makers, woodworking guilds
- Characteristics: Clean hardwoods (maple, cherry, oak), often 3/4" thick (resaw to 3mm)
- Preparation: Minimal—usually clean and dry
- Aesthetic: Mixed-wood mandalas (5 different species in one piece)

**Storm-Fallen Urban Trees:**
- Source: Municipal tree removal services, arborists
- Characteristics: Fresh-cut local species (varies by region)
- Preparation: Must be kiln-dried or air-dried 6-12 months to 8-12% moisture
- Aesthetic: Hyper-local story ("Made from a maple tree that fell in the 2025 Philadelphia ice storm")

**Preparation Workflow for Reclaimed Wood:**

1. **Metal detection** (magnetic sweep + visual inspection)
2. **Surface cleaning** (wire brush, pressure wash if needed)
3. **Planing/sanding** to consistent thickness
4. **Sealing** with shellac or water-based poly (reduces smoke, improves cut quality)
5. **Test cut** on small section before committing to full design
6. **Ventilation check** (if it smells toxic, STOP—reclaimed wood may have hidden treatments)

**Marketing Reclaimed Wood:**

- **Provenance story:** "Crafted from 100-year-old barn wood salvaged from Lancaster County"
- **Photo documentation:** Show the original structure, then the finished mandala
- **Pricing:** Reclaimed wood justifies 50-100% price premiums due to labor intensity and uniqueness
- **Certifications:** If sourcing from certified salvage yards, mention it

---

### Regenerative Material #3: Bamboo Plywood

**Why Bamboo is Regenerative:**

- **Growth rate:** Bamboo reaches harvest maturity in 3-5 years (vs. 20-80 years for hardwood trees)
- **Self-regenerating:** Harvesting doesn't kill the plant—new shoots grow from the same root system
- **Carbon sequestration:** Bamboo absorbs 35% more CO2 than equivalent hardwood forests
- **No pesticides/fertilizers:** Grows naturally without chemical inputs

**Bamboo Plywood Specifications:**

- Structure: Thin bamboo strips laminated into sheets (similar to plywood construction)
- Density: 650-700 kg/m³ (similar to Baltic Birch)
- Surface: Fine linear grain (parallel bamboo strips visible)
- Color: Natural light tan/blonde
- Thickness availability: 3mm, 5mm, 6mm common

**Laser Cutting Bamboo (3mm, 50-80W CO2):**

- Speed: 12-18 mm/s (slightly slower than wood due to silica content)
- Power: 65-75% (higher than Baltic Birch)
- Passes: 2-3
- Edge Quality: **Excellent**—bamboo produces high-contrast dark brown edges with minimal char
- Kerf: 0.12-0.16mm
- Smoke: **Heavy resin/silica content**—requires robust ventilation and frequent lens cleaning

**Critical Bamboo Considerations:**

1. **Air assist is mandatory.** Bamboo resins vaporize and coat your lens/mirrors rapidly. Run air assist at maximum to blow particles away from optics.

2. **Lens cleaning frequency:** Clean lens every 30-60 minutes of bamboo cutting (vs. every 2-4 hours with wood).

3. **Fire watch:** Bamboo's silica content can cause micro-flare-ups. Never leave bamboo cutting unattended.

4. **Protective paper:** Apply transfer tape or masking to top surface to catch resin splash-back.

**Bamboo Aesthetic:**

- Natural state: Light blonde with dark-brown laser marks (high contrast, crisp detail)
- Staining: Bamboo accepts stains well—can be darkened to walnut tones or bleached lighter
- Oil finish: Danish oil or tung oil deepens the natural color to warm honey
- Combination: Pair bamboo top layer with walnut backing for dramatic two-tone effect

**Where to Source Bamboo Plywood:**

- Specialty suppliers: Bamboo Hardwoods, Ambient Bamboo, Totally Bamboo
- Online: Amazon (check for FSC-equivalent certifications)
- Local: Some eco-focused lumber yards carry it

**Price:** $30-50 per 12"x24" sheet (similar to premium hardwoods)

**Marketing Bamboo:**

- "Made from 100% renewable bamboo—harvested in 3 years, not 30"
- "Carbon-negative materials: This mandala absorbed more CO2 than it produced"
- Partner with eco-certification programs (B Corp, 1% for the Planet)

---

### Regenerative Material #4: Cork

**Why Cork is Regenerative:**

- **No-harvest forestry:** Cork is stripped from the bark of cork oak trees every 9-12 years. The tree isn't cut down and continues growing.
- **Longevity:** Cork oaks live 200+ years, providing 12-20 harvests per tree.
- **Ecosystem:** Cork forests support endangered species (Iberian lynx, Barbary deer). Buying cork incentivizes forest preservation.
- **Carbon storage:** Cork oak forests store 14 million tons of CO2 annually.

**Cork Laser Cutting Characteristics:**

**Specifications:**
- Material: Compressed cork sheets (cork granules bonded with natural resins)
- Thickness: 1-6mm common (3mm is ideal for mandalas)
- Density: ~240 kg/m³ (extremely lightweight)
- Surface: Naturally porous, warm tan/brown color
- Structure: Honeycomb cellular (visible at cut edges)

**Laser Performance (3mm cork, 10-20W diode or 40-60W CO2):**

- Speed: 30-50 mm/s (fast—cork is soft)
- Power: 40-60% (lower than wood)
- Passes: 1-2
- Edge Quality: **Clean, dark brown edges**—high contrast against natural cork color
- Kerf: 0.10-0.12mm (minimal)
- Smoke: Moderate—pleasant woody smell
- Fire risk: Low (cork is flame-resistant by nature)

**Cork for Mandalas:**

**Advantages:**
- **Ultra-lightweight:** Perfect for large wall-hung pieces (12"+ diameter)
- **Soft, tactile texture:** Invites touch, creates warm organic feel
- **Forgiving material:** Easy to laser cut even with lower-power machines
- **Eco-story:** Cork's regenerative story is compelling to eco-conscious buyers

**Limitations:**
- Structural weakness: Not suitable for foundation layers in 7+ layer builds (use wood backing)
- Porous surface: Doesn't accept fine detail as crisply as MDF (best for geometric or organic patterns)
- Limited color range: Natural tan/brown only (can be painted or dyed, but loses natural aesthetic)

**Best Use Case: Hybrid Cork + Wood Mandalas**

- Layers 1-2: 5mm Baltic Birch (foundation)
- Layers 3-5: 3mm Cork (lightweight depth layers)
- Layer 6: 2mm Baltic Birch (detail layer)
- Layer 7: 1mm Cork (soft top layer for texture contrast)

**Marketing Cork:**

- "Harvested without cutting down a single tree"
- "Supports Mediterranean cork forests—home to endangered wildlife"
- "100% biodegradable—returns to earth in 2-3 years"
- Partner with Cork Forest Conservation Alliance

**Price:** $20-35 per 12"x24" sheet (3mm)

---

### Regenerative Material #5: Recycled Acrylic (R-PMMA)

**What R-PMMA Is:**

Recycled acrylic (R-PMMA = Recycled Polymethyl Methacrylate) is made from:
- Post-industrial acrylic scraps (factory offcuts)
- Post-consumer sources (old signage, displays, aquarium panels)
- Reprocessed into virgin-quality cast acrylic sheets

**Leading Brand: GreenCast® Setacryl (by Madreperla, Italy)**

- 100% recycled and fully recyclable
- Same optical clarity and laser performance as virgin acrylic
- Available in transparent, translucent, and opaque colors
- FSC-equivalent sustainability certification

**Laser Cutting Recycled Acrylic (3mm, 50-80W CO2):**

- Performance: **Identical to virgin acrylic**—clean cuts, flame-polished edges
- Speed: 8-12 mm/s
- Power: 50-70%
- Passes: 1-2
- Edge Quality: Glass-smooth, polished
- Kerf: 0.15-0.20mm

**Recycled Acrylic for Mandalas:**

**Use Cases:**
- Top layer: Transparent or colored acrylic over wood creates "glazed" effect
- Color accents: Red, blue, green, amber translucent layers add vibrant color without paint
- Backlit mandalas: Use translucent white R-PMMA with LED backing for glowing effect
- Mixed-media: Alternate wood and acrylic layers for industrial-modern aesthetic

**Aesthetic Advantage:**
- Acrylic laser edges self-polish (flame effect) → no sanding needed
- Transparent layers create shadow multiplication (1 wood layer + 1 clear acrylic = 2 shadow depths)
- Color range: 50+ colors available in recycled form

**Where to Source Recycled Acrylic:**

- **MakerStock** (U.S. supplier for GreenCast)
- **OnlineLaserCutting.com.au** (Australia—ships globally)
- **Direct from Madreperla** (Italy—bulk orders)

**Price:** $35-60 per 12"x24" sheet (3mm)—comparable to virgin acrylic

**Marketing Recycled Acrylic:**

- "Made from 100% recycled acrylic—giving discarded materials new life"
- "Same quality as new, zero virgin plastic"
- Highlight GreenCast certification

---

### Eco-Material Comparison Table

| Material | Regenerative Score | Cost vs Baltic Birch | Laser Difficulty | Aesthetic | Best For |
|----------|-------------------|---------------------|-----------------|-----------|----------|
| **FSC Baltic Birch** | ⭐⭐⭐⭐ (certified sustainable) | +15-25% | Easy | Natural wood grain | All-purpose, premium natural look |
| **Reclaimed Wood** | ⭐⭐⭐⭐⭐ (waste diversion) | Variable (often free) | Hard (metal detection, prep) | Rustic, story-driven | One-of-a-kind luxury pieces |
| **Bamboo Plywood** | ⭐⭐⭐⭐⭐ (fast-growing, self-renewing) | Similar | Medium (resin management) | Modern, high-contrast | Eco-conscious modern designs |
| **Cork** | ⭐⭐⭐⭐⭐ (no-cut harvest, biodegradable) | -20% to +10% | Very Easy | Warm, organic, tactile | Lightweight, soft-texture pieces |
| **Recycled Acrylic** | ⭐⭐⭐⭐ (diverts waste, recyclable) | Similar | Easy | Vibrant color, gloss finish | Mixed-media, backlit, color accent |

---

### Regenerative Design Workflow

**Step 1: Material Assessment**
- What's the design aesthetic? (Natural wood → FSC/reclaimed; Modern color → bamboo/acrylic; Soft/organic → cork)
- What's the budget tier? (Economy → reclaimed/cork; Mid → FSC birch; Luxury → FSC walnut/cherry)
- What's the brand story? (Local → storm-fallen urban trees; Global → bamboo; Industrial → reclaimed pallets)

**Step 2: Sourcing & Verification**
- Request FSC certificates from suppliers
- Document reclaimed wood provenance (photos, location, year)
- Check for sustainability certifications (GreenCast, FSC, PEFC)

**Step 3: Waste Minimization**
- Nested cuts: Use software (e.g., SVGnest, Deepnest) to minimize scrap
- Scrap bank: Save all offcuts >2"x2" for future small projects (earrings, ornaments, test cuts)
- Partner with schools/makers: Donate scrap for student projects

**Step 4: Finishing & Packaging**
- Use water-based finishes (zero-VOC polyurethane, natural oils)
- Packaging: Recycled cardboard, compostable mailers, no plastic
- Include care card: "This mandala is made from [material story]. To care for it: [instructions]. At end of life: [recycling/composting info]"

**Step 5: Carbon Accounting (Optional Advanced)**
- Calculate material footprint using lifecycle analysis tools
- Offset remaining carbon via verified projects (Gold Standard, Verra)
- Market as "carbon-neutral" or "carbon-negative"

---

## Part E: Material Safety & Ventilation

### Materials You Should NEVER Laser Cut

**1. PVC / Vinyl**
- Releases hydrochloric acid and dioxins (carcinogenic, corrosive to lungs and machine)
- Even "laser-safe PVC" is unsafe
- Alternative: Use genuine leather, cork, or acrylic

**2. ABS Plastic**
- Releases cyanide gas
- Common in 3D printing, automotive parts
- Alternative: Acrylic or PETG

**3. Polycarbonate (Lexan)**
- Releases toxic fumes, discolors, doesn't cut cleanly
- Alternative: Acrylic (similar clarity, safe to laser)

**4. Fiberglass**
- Glass particles become airborne, damage lungs
- Resin binders release toxins
- Alternative: Acrylic or wood composites

**5. Coated/Treated Materials (Unless Verified Safe):**
- Pressure-treated lumber (arsenic, chromium)
- Carbon fiber (airborne particles)
- Epoxy-coated woods
- Unknown reclaimed woods

---

### Ventilation Requirements

**Minimum Standard (Hobby/Home):**
- Inline duct fan (200+ CFM) venting **directly outside**
- 4" flexible ducting, shortest path possible
- Window vent or wall penetration
- Never recirculate—always exhaust outdoors

**Professional Standard (Production/Shop):**
- Dedicated laser fume extractor (e.g., Bofa, Purex, Fumex)
- HEPA + activated carbon filtration
- Negative pressure in laser cutting area
- CO2 monitor (keep below 1000 ppm)

**Material-Specific Notes:**
- **Bamboo:** Requires higher CFM due to heavy resin smoke
- **MDF:** Fine dust requires HEPA filtration
- **Leather:** Moderate smoke, distinctive smell (veg-tan safe; chrome-tan avoid)
- **Cork:** Light smoke, pleasant smell
- **Acrylic:** Sweet smell, moderate fumes (safe with proper ventilation)

---

## Part F: Material Sourcing Directory

### FSC-Certified Wood Suppliers (USA)

**Ocooch Hardwoods** (Wisconsin)
- ocoochhardwoods.com
- Baltic Birch, Maple, Cherry FSC plywood
- Ships nationwide
- Bulk discounts available

**Woodpeckers** (Ohio)
- woodpeck.com
- Premium FSC Baltic Birch
- Laser-grade flatness guarantee

**Advantage Trim & Lumber** (California)
- advantagelumber.com
- FSC hardwood plywood
- West Coast shipping

### Bamboo Plywood Suppliers

**Bamboo Hardwoods** (Washington)
- bamboohardwoods.com
- FSC-equivalent bamboo plywood
- 3mm, 5mm, 6mm

**Totally Bamboo** (Consumer Products)
- totallybamboo.com
- Finished bamboo sheets for smaller projects

### Cork Suppliers

**Widgetco** (Bulk Cork)
- widgetco.com
- Cork sheets 1-6mm
- Volume discounts

**Cork Store** (Specialty)
- corkstore.com
- Premium cork for laser cutting

### Recycled Acrylic

**MakerStock** (USA)
- makerstock.com
- GreenCast Setacryl R-PMMA
- Full color range

**TAP Plastics** (West Coast)
- tapplastics.com
- Now stocking recycled acrylic options

### Reclaimed Wood

**Local Sources (Recommended):**
- Architectural salvage yards (search: "architectural salvage [your city]")
- Craigslist/Facebook Marketplace: "barn wood," "reclaimed lumber"
- Municipal tree services (call and ask for storm-fallen logs)
- Custom furniture shops (ask for offcuts)

**Online National:**
- Etsy (search: "reclaimed barn wood" – often pre-cut to laser sizes)
- eBay (pallets, barn siding)

---

## Part G: Recommended Layer Configurations

### 5-Layer Mandala (Entry Level)

**Material:** 3mm Baltic Birch (uniform)

| Layer | Thickness | Function |
|-------|-----------|----------|
| 1 (back) | 3mm | Foundation |
| 2 | 3mm | First depth ring |
| 3 | 3mm | Middle geometric pattern |
| 4 | 3mm | Detail layer |
| 5 (front) | 3mm | Finest detail / top surface |

**Total depth:** 15mm  
**Material cost:** $10-12  
**Best for:** First-time builders, testing designs

---

### 7-Layer Mandala (Standard Professional)

**Material:** Mixed (graduated thickness)

| Layer | Thickness | Material | Function |
|-------|-----------|----------|----------|
| 1 | 5mm | Baltic Birch | Structural foundation |
| 2 | 3mm | Baltic Birch | First depth ring |
| 3 | 3mm | MDF or Cork | Weight reduction / cost savings |
| 4 | 3mm | Baltic Birch | Middle detail |
| 5 | 2mm | Baltic Birch | Fine detail support |
| 6 | 2mm | Bamboo or FSC Maple | Premium aesthetic layer |
| 7 | 1.5mm | Baltic Birch or Cork | Ultra-fine top detail |

**Total depth:** 21.5mm  
**Material cost:** $15-20  
**Best for:** Most commissions, Etsy/market sales

---

### 9-Layer Mandala (Premium/Exhibition)

**Material:** Mixed (luxury species)

| Layer | Thickness | Material | Function |
|-------|-----------|----------|----------|
| 1 | 6mm | FSC Walnut | Dark luxury foundation |
| 2 | 3mm | Bamboo | Light contrast layer |
| 3 | 3mm | Cork | Soft texture transition |
| 4 | 3mm | FSC Maple | Bright white-wood layer |
| 5 | 2mm | Bamboo | Detail layer |
| 6 | 2mm | FSC Walnut | Return to dark |
| 7 | 2mm | Recycled Acrylic (amber) | Color accent |
| 8 | 1.5mm | FSC Maple | Fine detail |
| 9 | 1mm | Recycled Acrylic (clear) | Protective gloss top |

**Total depth:** 25.5mm  
**Material cost:** $45-65  
**Best for:** Gallery pieces, luxury commissions ($300-800 retail)

---

### 11-Layer Mandala (Museum Grade)

**Material:** Maximum depth + mixed media

| Layer | Thickness | Material | Function |
|-------|-----------|----------|----------|
| 1 | 6mm | Reclaimed Barn Wood | Story-driven foundation (document provenance) |
| 2 | 5mm | FSC Walnut | Solid dark layer |
| 3 | 3mm | Cork | Textural surprise |
| 4 | 3mm | Bamboo | Eco-narrative layer |
| 5 | 3mm | FSC Cherry | Warm red-brown |
| 6 | 2mm | Recycled Acrylic (translucent red) | Color pop |
| 7 | 2mm | FSC Maple | Light return |
| 8 | 2mm | Bamboo | Geometric detail |
| 9 | 1.5mm | FSC Birch | Fine detail support |
| 10 | 1mm | Cork | Soft tactile top |
| 11 | 0.8mm | Veneer or ultra-thin acrylic | Protective glaze |

**Total depth:** 31.3mm  
**Material cost:** $75-120  
**Best for:** Commission work ($800-2000+), exhibitions, portfolio pieces

**Marketing narrative:** "Eleven layers, seven sustainable materials, one story: reclaimed barn wood from a 1920s Pennsylvania farm, FSC-certified hardwoods supporting responsible forestry, renewable bamboo harvested in 3 years, and 100% recycled acrylic—all combined into a museum-grade mandala designed to last generations."

---

## Key Takeaways

1. **Start with 3mm Baltic Birch for your first 5-7 layer builds.** Master the process before investing in exotic materials.

2. **Graduated thickness creates drama.** 5-6mm foundation → 3mm middle → 2mm detail → 1-1.5mm top.

3. **MDF is underrated for painted pieces.** Don't dismiss it—embrace its strengths.

4. **FSC certification is worth the 15-25% premium** if you're marketing to eco-conscious buyers. It's a powerful differentiator.

5. **Reclaimed wood tells stories.** The labor of sourcing and preparation justifies 50-100% price premiums.

6. **Bamboo and cork are the fastest paths to "regenerative" branding.** Their growth stories resonate powerfully.

7. **Never skip material testing.** Always run a test cut before committing to full-scale production, especially with reclaimed or new materials.

8. **Ventilation is non-negotiable.** If you can smell it while cutting, you're breathing it. Invest in proper exhaust.


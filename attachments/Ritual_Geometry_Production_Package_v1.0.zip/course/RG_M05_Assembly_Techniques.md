# MODULE 5: Assembly Techniques — Spacers, Adhesives, Mounting & Professional Finishing

## Introduction: The Assembly Difference

A perfectly laser-cut mandala can still fail at assembly. The difference between "craft fair amateur" and "gallery professional" isn't the design—it's the execution of these critical details:

- **Spacer placement strategy** (where you place them determines structural integrity)
- **Adhesive selection** (wrong glue = saggy layers, visible residue, or weak bonds)
- **Alignment techniques** (1mm misalignment ruins the optical effect)
- **Edge finishing** (raw laser edges vs. polished professional finish)
- **Mounting hardware** (keyhole vs. French cleat vs. wire hanger—each sends a price signal)

**The Rule:** Assembly takes 2-3x longer than cutting. Budget your time accordingly. Rushing assembly destroys days of design and cutting work in minutes.

---

## Part A: SPACER SYSTEMS — Creating Depth

Spacers create the **shadow layers** that make multi-layer mandalas dramatic. Without spacers, you just have a stack of flat cutouts—with spacers, you have dimensional art.

### The Spacer Principle

Each layer should "float" above the one below it, creating:
1. **Shadow depth** — Light hits each layer at a different plane, creating stacked shadows
2. **Visual separation** — Negative space between layers makes each design readable
3. **Dimensional pop** — Viewers perceive depth, not flatness

**Spacer Height Guide:**
- **1-2mm spacers:** Subtle depth, suitable for small mandalas (4-6")
- **3-4mm spacers:** Standard depth, most professional work (8-12")
- **5-6mm spacers:** Dramatic depth, large gallery pieces (14"+)

---

### Spacer Type #1: Foam Mounting Squares (Easiest)

**What They Are:**
Pre-cut adhesive foam squares (3M brand is industry standard) — double-sided sticky foam pads.

**Sizes:**
- **Small:** 6mm x 6mm (1/4" x 1/4")
- **Medium:** 12mm x 12mm (1/2" x 1/2")
- **Large:** 25mm x 25mm (1" x 1")

**Thickness:**
- **Thin:** 1mm (0.04") — subtle depth
- **Medium:** 2mm (0.08") — standard
- **Thick:** 3mm (0.12") — dramatic depth
- **Extra Thick:** 6mm (0.24") — gallery/exhibition work

**Where to Buy:**
- **Amazon**: "3M foam mounting squares" or "3D foam squares adhesive"
- **Michaels/Joann Fabrics**: Scrapbooking section
- **Dick Blick Art Materials**: Professional craft foam tape

**Price:** $8-15 per 400-pack (medium size, 2mm thickness)

**Pros:**
- **Fast.** Peel-and-stick, no waiting for glue to dry
- **Clean.** No glue squeeze-out, no mess
- **Forgiving.** Can be repositioned within ~30 seconds of placement
- **Consistent.** Every spacer is exactly the same height

**Cons:**
- **Expensive.** For 7-layer 12" mandala, you'll use $3-5 in foam squares per piece
- **Adhesive creep.** Over months/years, foam can compress slightly (1-2mm)
- **Temperature sensitive.** In hot environments (>90°F), adhesive can soften and layers can shift
- **Not archival.** Foam adhesive yellows over decades (not suitable for museum/heirloom work)

**Strategic Placement:**

❌ **WRONG: Placing spacers randomly or in the center only**
- Causes saggy edges, uneven layers, wobbling

✅ **RIGHT: Strategic placement along load-bearing structures**

**Placement Rules:**
1. **Perimeter support:** Place spacers around the outer edge (every 2-3" along circumference)
2. **Radial support:** Place spacers along radial "spokes" from center to edge
3. **Center support:** Add 1-2 spacers at absolute center (prevents center sag)
4. **Avoid visual gaps:** Never place spacers where negative space (cutouts) will show them from below

**Example: 7-Layer 12" Mandala Foam Spacer Layout**

Layer 1 (foundation): NO spacers (this is the base)

Layer 2 on Layer 1:
- 8 spacers around perimeter (every 45°, ~5" from center)
- 4 spacers at center (clustered in 1" radius)
- Total: 12 spacers

Layer 3 on Layer 2:
- 8 spacers around perimeter
- 4 radial spacers (halfway between center and edge)
- 2 spacers at center
- Total: 14 spacers

Layers 4-7: Same pattern, adjusting for decreasing size
- As layers get smaller, reduce spacer count proportionally
- Minimum: 6 spacers for tiny top layers

**Pro Tip:** Apply spacers to the **underside** of each layer (not the top of the layer below). This hides spacers from view—even when looking at the mandala at an angle, you won't see spacers peeking through cutouts.

---

### Spacer Type #2: Foam Core Board Strips (Professional Standard)

**What It Is:**
Lightweight foam board (3/16" or 5mm thick) cut into small squares or circles, then glued between layers.

**Why Professionals Use It:**
- **Rigid.** Foam core doesn't compress—mandala stays dimensionally stable for decades
- **Archival.** Acid-free foam core is museum-quality
- **Customizable.** Cut spacers to exact sizes needed for each layer
- **Cost-effective.** One $8 sheet of foam core yields spacers for 20-30 mandalas

**Foam Core Specifications:**
- **Thickness:** 3/16" (5mm) standard — use this for most work
- **Surface:** White paper coating over foam center
- **Size:** 20"x30" or 32"x40" sheets
- **Grades:**
  - **Regular foam core:** $5-8 per sheet (Elmer's, Crescent)
  - **Acid-free foam core:** $12-18 per sheet (archival)

**Where to Buy:**
- **Dick Blick, Michaels, Hobby Lobby**: Art supply section
- **Amazon**: "Elmer's foam board 20x30"
- **Office supply stores**: Presentation board section

**How to Cut Foam Core Spacers:**

**Method 1: Laser Cut (Best)**
- Cut 1/4" or 1/2" diameter circles from foam core with your laser
- Settings: Low power (20-40%), slow speed (10-20 mm/s), 1-2 passes
- Result: Clean, uniform spacers ready to glue
- Time: 100 spacers in 5 minutes

**Method 2: Craft Punch (Hand Tool)**
- Use circle craft punches (1/4", 1/2", 1" sizes)
- Punch foam core—yields clean circles
- Time: 100 spacers in 15-20 minutes

**Method 3: Manual Cut with Knife**
- Use utility knife and ruler to cut 1/2" squares
- Less precise but fastest for large spacers
- Time: 50 spacers in 10 minutes

**Adhesive for Foam Core Spacers:**

Use **liquid glue** (not foam mounting adhesive):
- **Best choice:** Aleene's Tacky Glue or Elmer's Craft Bond
- **Application:** Tiny dot of glue in center of foam core spacer
- **Press:** Apply spacer to underside of layer, press firmly for 5 seconds
- **Drying time:** 5-10 minutes before handling, 24 hours for full cure

**Pro Tip:** Pre-apply spacers to all layers, let dry overnight, THEN assemble the stack. This prevents glue squeeze-out between wood layers.

---

### Spacer Type #3: Cardstock/Chipboard (Budget Option)

**What It Is:**
Stack 2-4 layers of thick cardstock or chipboard to create custom-height spacers.

**Thickness per Layer:**
- Cardstock (110lb): ~0.3mm per layer
- Chipboard: ~1mm per layer

**Example:**
- 4 layers of chipboard = 4mm spacer
- 10 layers of cardstock = 3mm spacer

**Pros:**
- **Cheapest option.** $5 of cardstock = spacers for 50+ mandalas
- **Fully customizable.** Stack to exact height needed
- **Archival (if using acid-free cardstock).**

**Cons:**
- **Labor intensive.** Must cut and stack each spacer individually
- **Less rigid.** Can compress over time under weight
- **Glue-heavy.** Requires glue between each cardstock layer + glue to mandala layer

**When to Use:** Prototyping, budget production, or when you need non-standard spacer heights (e.g., 7mm—not available in foam squares).

---

### Spacer Type #4: Wood Dowels/Blocks (Structural for Large Pieces)

**What It Is:**
Small wood dowels (1/4" diameter) or solid wood blocks (5mm x 5mm x 5mm) used as rigid spacers for large (18"+) or heavy mandalas.

**Why Use Wood:**
- **Maximum strength.** Wood spacers won't compress—critical for 11-layer builds or stone/metal accent layers
- **Permanent.** Wood glued to wood is stronger than the wood itself
- **Heavy-duty.** Supports mandalas weighing 5+ lbs

**Dowel Spacer Sizes:**
- **1/4" diameter x 1/4" length** — standard depth spacer
- **1/4" diameter x 1/2" length** — deep spacer for dramatic shadow

**Where to Buy:**
- **Home Depot/Lowe's**: Hardwood dowel rods (cut to length)
- **Amazon**: "Wood dowel pins 1/4 inch"
- **Craft stores**: Pre-cut wood craft cubes

**Price:** $8-12 per 36" dowel rod (yields 100+ spacers)

**How to Cut Dowels:**
- **Best:** Miter saw or chop saw—cut 100 pieces in 5 minutes
- **Alternative:** Hand saw + miter box—cut 20 pieces in 10 minutes
- **Laser option:** Some lasers can cut 1/4" wood dowels (slow, 3-5 passes)

**Adhesive:** Wood glue (Titebond III) or CA glue—see Adhesive section below.

**When to Use:** Gallery pieces, outdoor installations, heavy mixed-media mandalas, heirloom commissions.

---

## Part B: ADHESIVES — The Glue Decision Matrix

Choosing the wrong adhesive is the #1 cause of mandala failure. Layers sag, glue bleeds through cutouts, or bonds fail after 6 months. This section is your cheat sheet.

---

### Adhesive #1: PVA Wood Glue (Titebond III) — The Foundation Standard

**What It Is:**
Polyvinyl acetate—the yellow glue in the squeeze bottle. Industry standard for wood-to-wood bonds.

**Best Brands:**
- **Titebond III Ultimate** (green label) — waterproof, strongest
- **Titebond II Premium** (blue label) — water-resistant, good for indoor
- **Titebond Original** (red label) — interior only, cheapest

**Why It Works:**
1. **Stronger than wood.** Once cured, the glue bond is stronger than the wood fibers—wood will break before glue fails
2. **Long open time.** 5-10 minutes to position layers before it sets
3. **Sands/finishes beautifully.** Squeeze-out can be sanded flush
4. **Archival.** Museum-quality when fully cured

**Application:**
- **Squeeze thin bead** along contact points (spacer tops, perimeter edges)
- **Spread with brush** for even coverage (foam brush or cheap paintbrush)
- **Clamp or weight** — rubber bands, spring clamps, or heavy book on top
- **Wipe excess immediately** with damp cloth

**Drying Time:**
- **Handling strength:** 30 minutes (can remove clamps)
- **Full cure:** 24 hours (don't stress the joint before this)

**Pros:**
- **Archival and permanent.** Lasts 50-100+ years
- **Bonds perfectly to wood.** Penetrates fibers for mechanical lock
- **Inexpensive.** $6 for 8oz bottle (enough for 30-50 mandalas)
- **Easy cleanup.** Water-soluble before drying

**Cons:**
- **Requires clamping.** Must apply pressure while drying
- **Long cure time.** Can't rush assembly—wait 24 hours between layers for full strength
- **Squeeze-out.** Excess glue can seep through cutouts if over-applied
- **Not ideal for porous surfaces.** MDF and chipboard soak up glue (use more glue or seal first)

**When to Use:** Wood-to-wood bonds, foam core spacers to wood, structural foundation layers, outdoor/high-stress applications.

**Pro Tips:**
- **Pre-seal MDF.** Brush thin coat of glue on MDF, let dry, sand smooth. This seals pores so next glue application doesn't soak in.
- **Tape off adjacent areas.** Use painter's tape to mask areas where you DON'T want glue—prevents staining on visible surfaces.
- **Thin with water.** For brushing on large areas, thin Titebond with 10-20% water for easier spreading.

**Price:** $6-10 per 8oz bottle

---

### Adhesive #2: CA Glue (Cyanoacrylate / "Super Glue") — The Speed Standard

**What It Is:**
Fast-curing adhesive that bonds in seconds. Available in thin, medium, and thick viscosities.

**Best Brands for Woodworking:**
- **Starbond EM-2000** (thick) — best for wood, includes micro-applicator tips
- **Bob Smith Industries (BSI) Insta-Cure+** — medium viscosity
- **Gorilla Super Glue Gel** — thick gel, found at hardware stores

**Viscosity Guide:**
- **Thin CA:** Watery—wicks into joints, fastest cure (3-10 seconds), least control
- **Medium CA:** Honey-like—moderate cure (10-30 seconds), good control
- **Thick CA (Gel):** Toothpaste—slow cure (30-60 seconds), fills gaps, maximum control

**For Mandalas, Use:** Thick CA gel

**Why It's Popular:**
1. **FAST.** Bonds in 30-60 seconds—assemble entire mandala in 10-15 minutes
2. **No clamping.** Just hold pieces together for 30 seconds
3. **Precision application.** Use micro-tip applicators to put glue exactly where needed
4. **Strong.** Nearly as strong as wood glue when applied correctly

**Application:**
- **Apply tiny dot** to spacer or joint (size of pinhead)
- **Press pieces together** firmly
- **Hold for 30 seconds** (no movement!)
- Optional: **Spray CA accelerator** (kicker) to cure instantly (5 seconds)

**Pros:**
- **Speed.** Entire 7-layer mandala assembled in 10 minutes
- **No squeeze-out.** Thick gel stays where you put it
- **No clamping required**
- **Works on any material.** Wood, MDF, metal, leather, plastic, stone

**Cons:**
- **EXPENSIVE.** $15-25 per 2oz bottle (20x more expensive than wood glue per ounce)
- **Fumes.** Irritating fumes—work in ventilated area
- **Brittle.** CA cures hard and brittle—can fail under impact or stress
- **Skin hazard.** Bonds skin instantly (debond with acetone or wait 2-3 days for natural separation)
- **Shiny residue.** If glue seeps out, it dries glossy white—visible on dark wood
- **Short shelf life.** Once opened, CA glue degrades in 3-6 months

**When to Use:** Fast production assembly, foam spacers to wood, intricate detail work, last-minute commission deadlines.

**CA Accelerator (Kicker):**
- Spray bottle chemical that causes CA to cure instantly (5 seconds instead of 30-60)
- **Use sparingly:** Accelerated CA is weaker than naturally-cured CA
- **Application:** Spray lightly BEFORE applying glue to one surface, then apply glue to other surface and press together

**Pro Tips:**
- **Use micro-applicator tips.** CA bottles come with wide tips—swap for ultra-fine needle tips for precision
- **Keep glue fresh.** Store in refrigerator (not freezer) to extend shelf life 6-12 months
- **Debonder is essential.** Keep CA debonder (acetone-based) on hand for mistakes and skin bonding
- **Never use thin CA for mandalas.** It soaks into wood too fast, runs everywhere, creates weak bonds

**Price:** $15-25 per 2oz bottle (Starbond EM-2000)

---

### Adhesive #3: Epoxy (2-Part) — The Gap-Filling Structural Adhesive

**What It Is:**
Two-part adhesive (resin + hardener) that cures through chemical reaction. Bonds nearly anything, fills gaps, waterproof when cured.

**Types:**
- **5-Minute Epoxy:** Fast cure, lower strength, good for quick repairs
- **30-Minute Epoxy:** Standard—best balance of working time and strength
- **24-Hour Epoxy (Slow-Cure):** Maximum strength, allows complex assembly before cure

**Best Brands:**
- **West System 105 Resin + 205 Hardener** (marine-grade, ultra-strong)
- **J-B Weld Clear Weld** (hardware store standard)
- **Gorilla 2-Part Epoxy** (5-minute or 1-hour options)

**Why Use Epoxy:**
1. **Gap-filling.** Epoxy fills voids up to 1/8"—ideal for irregular surfaces, reclaimed wood, stone-to-wood bonds
2. **Maximum strength.** Stronger than wood glue or CA in most applications
3. **Waterproof.** Fully cured epoxy is impervious to water—outdoor mandalas
4. **Bonds dissimilar materials.** Wood-to-metal, wood-to-stone, wood-to-acrylic, leather-to-brass

**Application:**
- **Mix equal parts** resin and hardener on disposable surface (plastic lid, cardboard)
- **Mix thoroughly** for 2 minutes (streaks = incomplete cure = weak bond)
- **Apply to both surfaces** with disposable brush or stick
- **Clamp or weight** for full cure time
- **Wipe excess immediately** with paper towel (epoxy is hard to remove once cured)

**Cure Times:**
- **5-Minute Epoxy:** Handling strength in 5 min, full cure in 1 hour
- **30-Minute Epoxy:** Handling strength in 30 min, full cure in 24 hours
- **24-Hour Epoxy:** Handling strength in 6 hours, full cure in 3-7 days

**Pros:**
- **Strongest bond.** Exceeds wood glue and CA in shear strength
- **Fills gaps.** Works even when surfaces don't mate perfectly
- **Waterproof and weatherproof**
- **Bonds anything to anything**

**Cons:**
- **EXPENSIVE.** $12-25 for 8oz (4oz resin + 4oz hardener)
- **Messy.** Sticky, hard to clean up once mixed
- **Long cure time.** Even 5-minute epoxy takes 1 hour for full strength
- **Requires mixing.** Extra step, room for error (wrong ratio = weak bond)
- **Not archival-friendly.** Yellows over 10-20 years

**When to Use:** Mixed-media mandalas (wood + metal + stone), outdoor installations, gap-filling for reclaimed wood, heavy structural layers, when maximum strength is required.

**Pro Tips:**
- **Warm epoxy.** Place bottles in warm water (100-110°F) before mixing—epoxy flows easier, bubbles release
- **Add filler.** Mix wood dust or talcum powder into epoxy to create thicker paste for vertical surfaces
- **Color matching.** Mix sawdust from your mandala wood into epoxy—glue line becomes nearly invisible

**Price:** $12-25 per 8oz kit (West System 105/205)

---

### Adhesive Comparison Chart

| Adhesive | Cure Time | Strength | Cost/Oz | Best For | Avoid For |
|----------|-----------|----------|---------|----------|-----------|
| **Wood Glue (Titebond III)** | 24 hrs | Excellent (wood-to-wood) | $0.75 | Wood layers, foam spacers, structural bonds | Fast production, non-porous materials |
| **CA Glue (Thick Gel)** | 30-60 sec | Very Good | $12 | Speed assembly, foam spacers, detail work | Budget builds, outdoor, structural |
| **Epoxy (30-min)** | 24 hrs | Excellent (all materials) | $3 | Mixed-media, gap-filling, outdoor, stone/metal | Budget, clean work (messy) |
| **Foam Mounting Squares** | Instant | Good | $0.03/square | Easiest, no glue mess, cardstock mandalas | Archival, outdoor, heavy layers |
| **Hot Glue** | 1 min | Poor | $0.10 | ❌ NEVER—weak, ugly, fails quickly | Everything |

**The "Never Use" List:**
- ❌ **Hot glue** — weak, ugly strings, fails in heat
- ❌ **Rubber cement** — temporary bond, yellows, degrades
- ❌ **Spray adhesive (3M 77)** — weak, messy overspray, not archival
- ❌ **Gorilla Glue (polyurethane foam)** — expands and oozes, impossible to control

---

## Part C: ALIGNMENT TECHNIQUES — Precision Assembly

Misalignment ruins the optical effect. When layers shift 1-2mm, the shadows don't stack cleanly and the mandala looks "off." These techniques ensure perfect registration.

---

### Alignment Method #1: Center Dowel Pin (Best for Circular Mandalas)

**How It Works:**
Drill a small hole (3mm) through the exact center of every layer, then thread a 3mm dowel through the stack to align all layers during assembly.

**Steps:**
1. **Mark centers:** Find center of each layer (use printed centering jig or measure)
2. **Drill pilot hole:** 3mm drill bit, straight down through center of each layer
3. **Dry-fit stack:** Thread 3mm dowel through all layers—check alignment
4. **Glue layers:** Apply glue/spacers, re-insert dowel, press together
5. **Remove dowel:** Once glue sets, pull dowel out
6. **Fill center hole:** Glue 3mm wood plug into hole (or leave open if design has center circle)

**Pros:**
- **Foolproof.** Impossible to misalign—dowel forces perfect registration
- **Fast.** No fiddling with visual alignment during glue-up
- **Repeatable.** Same dowel works for multiple mandalas

**Cons:**
- **Requires drilling.** Must drill every layer before assembly
- **Center must be open in design.** If mandala has intricate center detail, dowel hole may show
- **Dowel removal.** Must remove dowel before glue fully cures, or it bonds permanently

**When to Use:** Circular mandalas with open center, production runs (10+ identical mandalas), when perfect alignment is non-negotiable.

---

### Alignment Method #2: Laser-Cut Registration Marks

**How It Works:**
Add small (2mm) circular "tabs" at 3-4 locations around the perimeter of each layer. These tabs nest into each other, creating mechanical alignment.

**Example:**
- Layer 1 (foundation): Has 3 small circular depressions (2mm diameter x 1mm deep)
- Layer 2: Has 3 matching 2mm circular protrusions that fit into Layer 1 depressions
- Result: Layer 2 can only sit in ONE position on Layer 1—perfect alignment

**How to Design:**
1. In your SVG, add 3 small circles (2mm diameter) at 120° intervals around outer edge
2. For foundation layer: Engrave these circles (creates depressions)
3. For all upper layers: Leave these circles as 2mm solid tabs (cut around them, not through them)
4. During assembly: Tabs nest into depressions—instant alignment

**Pros:**
- **No extra tools.** Alignment is built into the design
- **No center hole.** Works for mandalas with intricate center detail
- **Elegant.** Registration marks are tiny and hidden at perimeter

**Cons:**
- **Requires design modification.** Must plan for registration marks during design phase
- **Fragile tabs.** 2mm wood tabs can break if handled roughly
- **Only works for identical-design layers.** Each layer must have matching registration

**When to Use:** Complex center-detail mandalas, when dowel method isn't practical, production efficiency.

---

### Alignment Method #3: Visual Registration (Hand-Eye Method)

**How It Works:**
Carefully place each layer by eye, using visual landmarks (outer edge, radial symmetry) to align.

**Steps:**
1. **Place foundation layer** flat on work surface
2. **Identify alignment references:** Outer edge, radial spokes, symmetry lines
3. **Lower next layer slowly** from above, watching multiple reference points
4. **Adjust position** before glue/spacers contact
5. **Press down gently** once aligned

**Pro Tips:**
- **Work on a turntable (lazy Susan).** Spin mandala 360° to check alignment from all angles before committing
- **Use backlight.** Place mandala on light table or LED tracing pad—light shines through, making alignment errors obvious
- **Align outer edge first.** Get perimeter concentric, then check center
- **Work slowly.** Once glue touches, repositioning is hard/impossible

**Pros:**
- **No special tools.** Just your eyes and hands
- **Flexible.** Works for any design, any layer count
- **No design modification.** Use with any SVG file

**Cons:**
- **Skill-dependent.** Takes practice to get perfect alignment every time
- **Stressful.** One mistake can ruin entire assembly
- **Time-consuming.** Must check alignment carefully for each layer

**When to Use:** One-off pieces, prototypes, when other methods aren't practical.

---

## Part D: EDGE FINISHING — Raw to Refined

Laser-cut edges are slightly brown/charred. For natural wood aesthetics, this is often desirable (adds warmth, depth). For painted finishes or premium commissions, you'll want polished edges.

---

### Finish #1: Natural Char (Embrace the Laser Mark)

**What It Looks Like:**
Light brown to dark brown edge coloring from laser heat. Creates warm contrast against wood face.

**When It Works:**
- Natural wood mandalas (unstained)
- Rustic/organic aesthetic
- Burnt-edge "campfire" vibe
- When paired with oil finish (Danish oil, tung oil)

**How to Enhance:**
- **Do nothing.** Raw laser edges are the finish.
- **Optional: Seal with oil.** Brush light coat of Danish oil on edges—darkens the char, makes it richer

**Pros:**
- **Zero work.** The laser did it for you
- **Authentic.** Clearly handmade, laser-cut aesthetic
- **Time-saving.** No sanding or painting

**Cons:**
- **Visible soot.** Some woods (MDF especially) leave dusty black soot—wipe with damp cloth
- **Inconsistent.** Different woods char differently (pine = light, walnut = dark)

---

### Finish #2: Sanded Edges (Clean Wood Tone)

**What It Looks Like:**
Natural wood color at edges—no char visible.

**Tools:**
- **Fine-grit sandpaper** (220-400 grit)
- **Sanding sponge** (flexible, wraps around curves)
- **Dremel with sanding drum** (for intricate curves)

**Steps:**
1. **Fold sandpaper** into small square
2. **Rub edges gently** along laser-cut edge
3. **Work slowly**—goal is to remove char without rounding over sharp edge
4. **Blow dust** or wipe with tack cloth
5. **Optional: Seal with poly or oil**

**Pros:**
- **Clean, refined look.** Edges match face color
- **Works for any wood**
- **Prepares surface for paint/stain**

**Cons:**
- **TIME-INTENSIVE.** For intricate 7-layer mandala, expect 30-60 minutes of sanding
- **Dust everywhere.** Wear mask, work in ventilated area
- **Risk of over-sanding.** Can round over sharp details if not careful

**When to Use:** Painted mandalas (char shows through paint), light-colored woods (maple, birch), when commissioning client wants "no laser marks."

---

### Finish #3: Edge Paint (Bold Color Pop)

**What It Looks Like:**
Brightly colored edges—black, gold, silver, or accent color—that contrast with wood face.

**Tools:**
- **Small paintbrush** (liner brush, 1/8" width)
- **Acrylic craft paint** (FolkArt, DecoArt)
- **Painter's tape** (mask face to prevent paint bleed)

**Steps:**
1. **Tape face** of each layer (optional but recommended)
2. **Apply paint** to edges with small brush—may need 2 coats
3. **Let dry** 1 hour between coats
4. **Remove tape** before paint fully cures (prevents peeling)
5. **Seal with clear coat** (optional—prevents edge wear)

**Color Ideas:**
- **Black edges** on light wood (maple, birch) — modern, graphic
- **Gold metallic** on walnut — luxury, jewelry-like
- **White edges** on dark wood — high contrast, bold
- **Gradient edges** (dark to light) — artistic, gallery-level

**Pros:**
- **Dramatic visual impact.** Edges become design element, not just functional
- **Hides char completely**
- **Allows brand/style signature.** "All my mandalas have gold edges"

**Cons:**
- **Time-intensive.** 30-60 minutes per mandala for careful painting
- **Paint bleed risk.** If tape isn't perfect, paint bleeds onto face
- **Durability.** Edge paint can chip over time (mitigate with clear topcoat)

**When to Use:** Gallery pieces, custom commissions, when you want a signature look, modern/graphic aesthetic.

---

## Part E: MOUNTING HARDWARE — How It Hangs Determines Price

Mounting hardware is a **price signal.** Keyhole hangers say "$50 craft fair piece." French cleats say "$300 gallery piece."

---

### Mounting Option #1: Keyhole Hanger (Standard Retail)

**What It Is:**
Small metal plate with a keyhole-shaped slot. Screw it to the back of the mandala, then hang on a screw in the wall.

**Types:**
- **Flush keyhole:** Sits on surface, adds 2mm thickness
- **Recessed keyhole:** Routs into back, sits flush (more professional)

**Installation:**
1. **Mark center back** of mandala (top-center, ~2" from edge)
2. **Drill pilot holes** (smaller than screw diameter)
3. **Screw hanger** to back with 2-4 small screws
4. **Hang on wall screw**

**Wall Prep:**
- User puts screw into wall (drywall anchor if needed)
- Mandala keyhole slots onto screw head

**Pros:**
- **Cheapest.** $0.50-2 per hanger
- **Easiest for customer.** One screw, done
- **Compact.** Adds minimal thickness to back

**Cons:**
- **Hard to level.** Keyhole angle makes mandala tilt—user must adjust screw
- **Weight limit.** ~10 lbs maximum (larger mandalas need 2 hangers)
- **Lower perceived value.** Signals "mass-produced craft item"

**Where to Buy:**
- **Amazon**: "Keyhole hanger zinc" (brass or steel)
- **Hardware stores**: Picture hanging section
- **Laser-cut option**: Cut custom keyhole shape into wood backing layer (Module 1 techniques)

**Price:** $0.50-2 per hanger

**When to Use:** Budget mandalas ($30-80 range), craft fair inventory, lightweight pieces (<3 lbs).

---

### Mounting Option #2: Sawtooth Hanger (Rustic Standard)

**What It Is:**
Serrated metal strip that mounts to top-back edge. Hangs on nail or screw.

**Installation:**
1. **Position hanger** centered on top-back edge
2. **Nail or screw** hanger in place (nails often included)
3. **Hang on wall nail**

**Pros:**
- **Very cheap.** $0.30-1 per hanger
- **Easy for customer.** One nail, done
- **Self-centering.** Serrations grip nail—less tilt than keyhole

**Cons:**
- **Visible from side.** Metal edge protrudes slightly above back edge
- **Weight limit.** ~8 lbs maximum
- **Cheapest perceived value.** Signals "budget craft item"

**When to Use:** Economy mandalas, when keyhole isn't available, disposable/gifting inventory.

---

### Mounting Option #3: Wire Hanger (Traditional Frame Standard)

**What It Is:**
Two D-rings or screw eyes on back, connected by picture wire.

**Installation:**
1. **Attach D-rings** to back, ~1/3 down from top, 3-4" apart
2. **Thread wire** through D-rings
3. **Twist wire ends** tightly to secure
4. **Hang on wall hook**

**Pros:**
- **Traditional.** Looks like framed art (higher perceived value)
- **Adjustable.** User can adjust wire tightness to level mandala
- **Weight capacity.** Up to 25 lbs with proper wire gauge

**Cons:**
- **Wire can show.** If too loose, wire arcs above frame edge—visible
- **Two-point install.** User needs picture hook or nail
- **More complex.** 3 parts (2 D-rings + wire) vs. 1 hanger

**Where to Buy:**
- **Hardware stores**: Picture wire, D-rings
- **Amazon**: "Picture hanging wire kit"

**Price:** $2-4 per mandala (wire + 2 D-rings)

**When to Use:** Mid-tier mandalas ($80-180), when customer expects "art" not "craft," pieces 8-14" diameter.

---

### Mounting Option #4: French Cleat (Gallery Professional Standard)

**What It Is:**
Two interlocking 45° beveled strips—one mounts to wall, one mounts to back of mandala. Mandala "hooks" onto wall strip.

**Why It's Professional:**
- **Dead-simple for customer.** Screw wall strip to wall (level it once), then mandala slides on—done
- **Perfectly level every time.** Cleat geometry auto-levels
- **Maximum weight capacity.** Holds 100+ lbs (suitable for 24" mandalas)
- **Easy swap.** User can swap artworks on same wall strip
- **Gallery standard.** Museums use French cleats—signals premium quality

**How to Make:**

**Option 1: Buy Pre-Made (Easiest)**
- **Chromaluxe French Cleat System** (aluminum, powder-coated)
- **OOK Hangman Cleats** (metal, various sizes)
- Price: $8-20 per cleat system (depends on size)

**Option 2: DIY Wood Cleat (Cost-Effective)**
1. Cut 3/4" wood strip to width of mandala (minus 2" on each side)
2. Rip at 45° bevel on table saw (creates two matching beveled strips)
3. Glue one strip to back of mandala (bevel facing down)
4. Give other strip to customer (bevel facing up)—they mount to wall

**Installation (Customer):**
1. Screw wall strip to wall (into studs or with drywall anchors)
2. Level it with level tool
3. Hang mandala by sliding back strip onto wall strip—done

**Pros:**
- **Maximum perceived value.** Customers recognize this as "gallery-quality"
- **Easiest for customer.** Truly one-step hanging
- **Strongest.** Holds heavy/large mandalas safely
- **Professional.** Separates you from craft fair competitors

**Cons:**
- **Most expensive.** $8-20 per system
- **Mandala sits 1-2" off wall.** Cleat adds depth (can be desirable—creates shadow)
- **Requires space on back.** Need 2-3" of flat back surface for cleat strip

**When to Use:** Gallery pieces, premium commissions ($250+), mandalas 12"+, when competing against fine art (not crafts).

**DIY French Cleat Cost:** $1-2 per mandala (wood + screws)

---

### Mounting Comparison Chart

| Hardware | Price | Weight Limit | Install Difficulty | Perceived Value | Best For |
|----------|-------|--------------|-------------------|-----------------|----------|
| **Keyhole Hanger** | $0.50-2 | 10 lbs | Easy | Budget craft | <$100 mandalas |
| **Sawtooth** | $0.30-1 | 8 lbs | Very Easy | Economy | <$60 mandalas |
| **Wire Hanger** | $2-4 | 25 lbs | Moderate | Traditional art | $80-180 mandalas |
| **French Cleat** | $8-20 | 100+ lbs | Easy for user | Gallery professional | $250+ mandalas |

**The Rule:** Mounting hardware should be 1-2% of retail price. $50 mandala → keyhole ($1). $400 mandala → French cleat ($12).

---

## Part F: ASSEMBLY WORKFLOW — Step-by-Step

Here's the professional assembly sequence for a 7-layer 12" mandala (wood + foam spacers + CA glue).

### Pre-Assembly Prep (5 minutes)

1. **Organize layers:** Lay out all 7 layers in order, right-side up
2. **Test-fit:** Stack layers without glue—check for fit, alignment issues
3. **Mark any issues:** Note layers that need sanding or trim
4. **Prepare spacers:** Count spacers needed (12 per layer x 6 layers = 72 spacers)
5. **Prep work surface:** Cover with parchment paper or silicone mat (glue won't stick)

### Foundation Layer (1 minute)

1. **Place Layer 1** (foundation) face-down on work surface
2. **Attach mounting hardware** now (keyhole, wire, or cleat) before assembly

### Layer 2 Assembly (3 minutes)

1. **Turn Layer 2 face-down**
2. **Apply spacers** to underside in strategic pattern (see Spacer section above)
3. **Apply adhesive:** Tiny dot of CA glue on top of each spacer
4. **Flip Layer 2 over** (right-side up)
5. **Align onto Layer 1:** Use alignment method of choice
6. **Press firmly** for 30 seconds
7. **Check alignment** before glue fully cures

### Layers 3-7 Assembly (15 minutes)

Repeat Layer 2 process for each subsequent layer:
- Spacers on underside
- Glue on spacers
- Flip, align, press
- Wait 30 seconds per layer

### Final Steps (5 minutes)

1. **Inspect alignment:** View from all angles, check for tilt or misalignment
2. **Clean excess glue:** Wipe any visible glue residue with damp cloth (wood glue) or debonder (CA glue)
3. **Let cure:** 1 hour minimum before handling (24 hours for wood glue)
4. **Quality check:** Spin on turntable, check for wobble or loose layers

**Total Assembly Time: 30 minutes** (+ cure time)

---

## Part G: TROUBLESHOOTING — Common Assembly Failures

### Problem: Saggy/Drooping Layers

**Cause:** Insufficient spacer support—spacers only in center, edges unsupported

**Fix:**
- Add more spacers around perimeter (every 2-3")
- Use rigid spacers (foam core or wood) instead of soft foam squares

### Problem: Layers Misaligned/Tilted

**Cause:** Glue set before alignment was finalized, or no alignment system used

**Fix:**
- Use alignment method (dowel pin, registration marks, or visual on turntable)
- Work faster with CA glue, or slower with wood glue (longer open time)

### Problem: Glue Visible Through Cutouts

**Cause:** Over-application of glue, or glue squeeze-out

**Fix:**
- Use less glue (tiny dots, not beads)
- Wipe excess immediately before it dries
- Switch to CA glue (less squeeze-out than wood glue)

### Problem: Layers Pop Off After Months

**Cause:** Insufficient glue, or wrong adhesive for material pairing

**Fix:**
- Use proper adhesive for material (wood glue for wood, epoxy for mixed-media)
- Increase glue coverage (more spacers = more glue points)
- Ensure full cure time before shipping

### Problem: Finish Looks "Cheap"

**Cause:** Rough edges, visible glue, low-quality mounting hardware

**Fix:**
- Sand edges or paint them
- Clean up glue squeeze-out meticulously
- Upgrade to French cleat or wire hanger (ditch keyhole for premium work)

---

## Part H: FINISHING TOUCHES — The 5% That Matters

### Touch #1: Signature & Date

**Where:** Bottom-right of back foundation layer

**Method:** Wood-burning pen, laser engrave, or Sharpie

**Format:** "[Your Name] [Year]" or "[Brand] [Month/Year]"

**Why It Matters:** Authenticated art commands higher prices. Unsigned = craft. Signed = art.

### Touch #2: Care Card

**What:** Small printed card with mandala care instructions

**Include:**
- "Wipe with dry cloth. Avoid moisture."
- "Display away from direct sunlight to prevent fading."
- "Handle by edges to avoid fingerprints on layers."
- "[Material] sourced from [FSC/reclaimed/etc.]"

**Why:** Professional presentation. Shows you care about longevity.

### Touch #3: Certificate of Authenticity (High-End Only)

**For:** Commissioned pieces $300+

**Include:**
- Mandala title
- Materials used (Baltic Birch, brass, etc.)
- Number of layers
- Date completed
- Your signature
- Edition info ("1 of 1" or "3 of 10")

**Format:** Printed on cardstock, slip into envelope attached to back

**Why:** Gallery-level provenance. Essential for resale/insurance.

### Touch #4: Packaging

**Budget:** Clear cellophane bag + cardboard backing

**Standard:** Kraft paper wrap + twine + "Handmade" sticker

**Premium:** Custom-branded box + tissue paper + care card

**Why:** Unboxing experience = perceived value. $50 mandala in plastic bag = craft. Same mandala in branded box = art.

---

## Key Takeaways

1. **Spacer placement is structural engineering.** Perimeter + radial + center support. Random spacers = saggy mandala.

2. **Adhesive choice is context-dependent.** Wood-to-wood = Titebond III. Speed = CA glue. Mixed-media = epoxy. There is no "best" adhesive—only "best for this application."

3. **Alignment systems prevent regret.** Spend 5 minutes on alignment jig, save 5 hours of "almost perfect but not quite."

4. **Mounting hardware is a price signal.** French cleat = gallery professional. Keyhole = craft fair. Choose accordingly.

5. **Assembly takes longer than cutting.** Budget 30-60 minutes per mandala, depending on complexity. Rushing kills quality.

6. **Finishing touches are the difference.** Signature, care card, professional mounting, clean edges—these are what separate $80 from $300 mandalas.

7. **Quality control before shipping.** Spin on turntable, check alignment, inspect edges, test mount. Your reputation ships with every piece.

---

**Next Module Preview:** Module 6 will cover **Finishing & Coloring Techniques** — staining, painting, oil finishes, mixed-media color strategies, and achieving museum-grade surface quality.

